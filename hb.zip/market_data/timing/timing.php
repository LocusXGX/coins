<?php
PHP_SAPI!='cli' && exit;
chdir(dirname(__FILE__));

@error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
$pid=pcntl_fork();
if($pid==-1){
	exit('could not fork');
}elseif($pid){
	echo "fork pid=$pid\n";
}else{
	$dir=dirname(__FILE__);
	exec("/usr/bin/php {$dir}/task/get_exchange_info.php");
	$task_list=array(
		array('task/get_exchange_info.php', 600),
		array('task/get_interest_rate.php', 600),
		array('task/get_kline.php', 600),
		array('task/get_kline_quick.php', 1),
		array('task/get_quote_volume.php', 600),
		array('task/get_ticker_price.php', 0.25),
		array('task/update_kline.php', 1),
		array('task/update_rise.php', 1)
	);
	$task_run_time=array_fill(0, count($task_list), 0);
	while(1){
		$microtime=microtime(true);
		foreach($task_list as $k=>$v){
			if($microtime-$task_run_time[$k]>$v[1] || (date('i')>10 && date('H', intval($task_run_time[$k]))!=date('H'))){
				$task_run_time[$k]=$microtime;
				exec("/usr/bin/php {$dir}/{$v[0]} {$v[1]} > /dev/null 2>&1 &");
			}
		}
		usleep(125000);
	}
}




