<?php
PHP_SAPI!='cli' && exit;
include(dirname(__FILE__).'/../../inc/global.php');

$lock_name='get_interest_rate';
wicker::check_lock($lock_name, $argv[1]);
$binance=new binance();

$binance_interest_rate=$binance->get_interest_rate();
if($binance_interest_rate['ret']==1){
	$interest_rate=array();
	foreach($binance_interest_rate['msg'] as $v){
		$symbol=strtolower(str_replace('USDT', '', $v['symbol']));
		if(!in_array($symbol, $c['config']['symbol'])){continue;}
		$interest_rate[$symbol]=array(intval($v['nextFundingTime']/1000), (float)sprintf('%01.5f', $v['lastFundingRate']));
	}
	wicker::update_config('interest_rate', json_encode($interest_rate));
}
wicker::update_config($lock_name, 0);





