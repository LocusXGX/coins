<?php
PHP_SAPI!='cli' && exit;
include(dirname(__FILE__).'/../../inc/global.php');

$lock_name='update_rise';
wicker::check_lock($lock_name, $argv[1]);

$today_time=wicker::get_interval_acctime('1d');
$rise=array();
foreach($c['config']['ticker_price'] as $k=>$v){
	$open_price=db::get_value("{$k}_kline_1d", "AccTime='$today_time'", 'OpenPrice');
	$rise[$k]=(float)sprintf('%01.5f', ($v-$open_price)/$open_price);
}
ksort($rise);
wicker::update_config('rise', json_encode($rise));
wicker::update_config($lock_name, 0);




