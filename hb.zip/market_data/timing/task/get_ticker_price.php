<?php
PHP_SAPI!='cli' && exit;
include(dirname(__FILE__).'/../../inc/global.php');

$lock_name='get_ticker_price';
wicker::check_lock($lock_name, $argv[1]);
$binance=new binance();

$binance_ticker_price=$binance->get_ticker_price();
if($binance_ticker_price['ret']){
	$ticker_price=array();
	foreach($binance_ticker_price['msg'] as $v){
		$symbol=strtolower(str_replace('USDT', '', $v['symbol']));
		if(!in_array($symbol, $c['config']['symbol'])){continue;}
		$ticker_price[$symbol]=(float)$v['price'];
	}
	ksort($ticker_price);
	wicker::update_config('ticker_price', json_encode($ticker_price));
}
wicker::update_config($lock_name, 0);





