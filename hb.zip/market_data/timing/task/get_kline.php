<?php
PHP_SAPI!='cli' && exit;
include(dirname(__FILE__).'/../../inc/global.php');

@set_time_limit(0);
$lock_name='get_kline';
wicker::check_lock($lock_name, $argv[1]);
$binance=new binance();

foreach($c['config']['symbol'] as $symbol){
	if(!isset($c['config']['price_precision'][$symbol])){continue;}
	foreach($c['interval'] as $interval){
		$table="{$symbol}_kline_{$interval}";
		$kline_count=db::get_row_count($table);
		$kline=$binance->get_history_kline($symbol, $interval, $kline_count?5:200);
		if($kline['ret']==1){
			array_multisort(array_column($kline['msg'], 0), SORT_ASC, $kline['msg']);
			!$kline_count && db::lock("$table write");
			foreach($kline['msg'] as $v){
				$acctime=$v[0]/1000;
				$w="AccTime='$acctime'";
				$data=array(
					'OpenPrice'		=>	$v[1],
					'ClosePrice'	=>	$v[4],
					'LowPrice'		=>	$v[3],
					'HightPrice'	=>	$v[2],
					'AccTime'		=>	$acctime,
					'AccTimeFormat'	=>	@date('Y-m-d H:i:s', $acctime)
				);
				db::get_row_count($table, $w)?db::update($table, $w, $data):db::insert($table, $data);
				wicker::update_kline($table, $w, $c['config']['price_precision'][$symbol]);
			}
			!$kline_count && db::unlock();
		}
		if($kline_count>300){
			$kline_row=db::get_limit($table, '1', 'KlineId', 'KlineId desc', 250, 1);
			$kline_row && db::delete($table, "KlineId<{$kline_row[0]['KlineId']}");
		}
		usleep(100000);
	}
}
wicker::update_config($lock_name, 0);



