<?php
PHP_SAPI!='cli' && exit;
include(dirname(__FILE__).'/../../inc/global.php');

$lock_name='update_kline';
wicker::check_lock($lock_name, $argv[1]);

foreach($c['config']['ticker_price'] as $k=>$v){
	wicker::update_kline_price($k, $v, $c['config']['price_precision'][$k]);
}
wicker::update_config($lock_name, 0);




