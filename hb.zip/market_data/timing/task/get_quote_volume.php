<?php
PHP_SAPI!='cli' && exit;
include(dirname(__FILE__).'/../../inc/global.php');

$lock_name='get_quote_volume';
wicker::check_lock($lock_name, $argv[1]);
$binance=new binance();

$binance_quote_volume=$binance->ticker_24hr();
if($binance_quote_volume['ret']==1){
	$quote_volume=array();
	foreach($binance_quote_volume['msg'] as $v){
		$symbol=strtolower(str_replace('USDT', '', $v['symbol']));
		if(!in_array($symbol, $c['config']['symbol'])){continue;}
		$quote_volume[$symbol]=intval($v['quoteVolume']/10000);
	}
	ksort($quote_volume);
	wicker::update_config('quote_volume', json_encode($quote_volume));
}
wicker::update_config($lock_name, 0);





