<?php
PHP_SAPI!='cli' && exit;
include(dirname(__FILE__).'/../../inc/global.php');

$lock_name='get_exchange_info';
wicker::check_lock($lock_name, $argv[1]);
$binance=new binance();

$binance_exchange_info=$binance->exchange_info();
if($binance_exchange_info['ret']==1){
	$table_list=db::get_table_list();
	$symbol=$price_precision=$tick_zize=$quantity_precision=$max_qty=$min_qty=$step_size=$notional=array();
	foreach($binance_exchange_info['msg']['symbols'] as $v){
		$symbol_name=strtolower(str_replace('USDT', '', $v['symbol']));
		if(!substr_count($v['symbol'], 'USDT') || substr_count($v['symbol'], '_') || $v['status']!='TRADING'){continue;}
		$symbol[]=$symbol_name;
		if(is_array($v['filters'])){
			$filters=array_combine(array_column($v['filters'], 'filterType'), $v['filters']);
			if(is_array($filters['PRICE_FILTER'])){
				$price_precision[$symbol_name]='%01.'.($filters['PRICE_FILTER']['tickSize']>=1?0:strlen(rtrim($filters['PRICE_FILTER']['tickSize'], '0'))-2).'f';
				$tick_zize[$symbol_name]=$filters['PRICE_FILTER']['tickSize'];
			}
			if(is_array($filters['LOT_SIZE'])){
				$max_qty[$symbol_name]=(float)$filters['LOT_SIZE']['maxQty'];
				$min_qty[$symbol_name]=(float)$filters['LOT_SIZE']['minQty'];
				$step_size[$symbol_name]=(float)$filters['LOT_SIZE']['stepSize'];
				$quantity_precision[$symbol_name]='%01.'.($filters['LOT_SIZE']['stepSize']>=1?0:strlen(rtrim($filters['LOT_SIZE']['stepSize'], '0'))-2).'f';
			}
			if(is_array($filters['MIN_NOTIONAL'])){
				$notional[$symbol_name]=(float)$filters['MIN_NOTIONAL']['notional'];
			}
		}
		foreach($c['interval'] as $interval){
			!in_array("{$symbol_name}_kline_{$interval}", $table_list) && wicker::create_kline_table($symbol_name, $interval);
		}
	}
	if($symbol){
		foreach($table_list as $v){
			$symbol_ary=explode('_', $v);
			$symbol_name=$symbol_ary[0];
			if($v=='config' || in_array($symbol_name, $symbol)){continue;}
			db::query("DROP TABLE IF EXISTS `{$v}`");
		}
		sort($symbol);
		unset($symbol[array_search('btc', $symbol)], $symbol[array_search('eth', $symbol)]);
		$symbol=array_merge(array('btc','eth'), $symbol);
		ksort($price_precision);
		ksort($tick_zize);
		ksort($quantity_precision);
		ksort($max_qty);
		ksort($min_qty);
		ksort($step_size);
		ksort($notional);
		wicker::update_config('symbol', json_encode($symbol));
		wicker::update_config('price_precision', json_encode($price_precision));
		wicker::update_config('tick_zize', json_encode($tick_zize));
		wicker::update_config('quantity_precision', json_encode($quantity_precision));
		wicker::update_config('max_qty', json_encode($max_qty));
		wicker::update_config('min_qty', json_encode($min_qty));
		wicker::update_config('step_size', json_encode($step_size));
		wicker::update_config('notional', json_encode($notional));
	}
}
wicker::update_config($lock_name, 0);





