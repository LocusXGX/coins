<?php
class wicker{
	public static function get_table_data_to_ary($table, $w, $key, $return_field='', $query_field='', $order=1, $group_by=1, $start_row=0, $row_count=100000){
		$data=array();
		$row=db::get_limit($table, $w, $query_field?$query_field:($return_field?"{$key},{$return_field}":'*'), $order, $start_row, $row_count, $group_by);
		$key=explode('.', $key);
		$key=array_pop($key);
		$return_field=explode('.', $return_field);
		$return_field=array_pop($return_field);
		foreach($row as $v){
			$data[$v[$key]]=$return_field!=''?$v[$return_field]:$v;
		}
		return $data;
	}
	
	public static function check_lock($lock_name, $time=0){
		global $c;
		db::lock('config write');
		$config=wicker::get_table_data_to_ary('config', "Name in('$lock_name', '{$lock_name}_time')", 'Name', 'Value');
		if($config[$lock_name]==1){
			$time=max(30, $time)*1000;
			if($config["{$lock_name}_time"]+$time<$c['microtime']){
				wicker::update_config($lock_name, 0);
				wicker::update_config("{$lock_name}_time", $c['microtime']);
			}
			exit;
		}
		wicker::update_config($lock_name, 1);
		wicker::update_config("{$lock_name}_time", $c['microtime']);
		db::unlock();
	}
	
	public static function get_config(){
		global $c;
		$config=wicker::get_table_data_to_ary('config', '1', 'Name', 'Value');
		foreach($config as $k=>$v){
			json_decode($v)!==null && $config[$k]=json_decode($v, true);
		}
		return $config;
	}
	
	public static function update_config($name, $value){
		db::insert_update('config', "Name='$name'", array(
				'Name'		=>	$name,
				'Value'		=>	$value
			)
		);
	}
	
	public static function get_interval_acctime($interval, $time=0){
		global $c;
		$time==0 && $time=$c['time'];
		if($interval=='5m'){
			$interval_acctime=strtotime(date('Y-m-d H:00:00', $time))+floor(date('i', $time)/5)*5*60;
		}elseif($interval=='15m'){
			$interval_acctime=strtotime(date('Y-m-d H:00:00', $time))+floor(date('i', $time)/15)*15*60;
		}elseif($interval=='30m'){
			$interval_acctime=strtotime(date('Y-m-d H:00:00', $time))+(date('i', $time)>=30?1800:0);
		}elseif($interval=='1h'){
			$interval_acctime=strtotime(date('Y-m-d H:00:00', $time));
		}elseif($interval=='2h'){
			$interval_acctime=strtotime(date('Y-m-d H:00:00', $time))-(date('H', $time)%2)*3600;
		}elseif($interval=='4h'){
			$interval_acctime=strtotime(date('Y-m-d', $time))+floor(date('H', $time)/4)*4*3600;
		}elseif($interval=='6h'){
			if(date('H', $time)<2){
				$interval_acctime=strtotime(date('Y-m-d', $time))-3600*4;
			}elseif(date('H', $time)<8){
				$interval_acctime=strtotime(date('Y-m-d', $time))+3600*2;
			}elseif(date('H', $time)<14){
				$interval_acctime=strtotime(date('Y-m-d', $time))+3600*8;
			}elseif(date('H', $time)<20){
				$interval_acctime=strtotime(date('Y-m-d', $time))+3600*14;
			}else{
				$interval_acctime=strtotime(date('Y-m-d', $time))+3600*20;
			}
		}elseif($interval=='8h'){
			$interval_acctime=strtotime(date('Y-m-d', $time))+floor(date('H', $time)/8)*8*3600;
		}elseif($interval=='12h'){
			if(date('H', $time)<8){
				$interval_acctime=strtotime(date('Y-m-d', $time))-3600*4;
			}elseif(date('H', $time)>=20){
				$interval_acctime=strtotime(date('Y-m-d', $time))+3600*20;
			}else{
				$interval_acctime=strtotime(date('Y-m-d', $time))+3600*8;
			}
		}elseif($interval=='1d'){
			$interval_acctime=strtotime(date('Y-m-d', strtotime(date('Y-m-d', $time))-3600*8))+3600*8+(date('H', $time)>=8?86400:0);
		}elseif($interval=='1w'){
			$interval_acctime=strtotime(date('Y-m-d', $time-((date('w', $time)==0?7:date('w', $time))-1)*86400-((date('w', $time)==1 && date('H', $time)<8)?86400*7:0)))+3600*8;
		}elseif($interval=='1M'){
			$interval_acctime=strtotime(date('Y-m-01', $time-((date('d', $time)==1 && date('H', $time)<8)?86400:0)))+3600*8;
		}
		return (int)$interval_acctime;
	}
	
	public static function update_kline_price($symbol, $price, $price_precision){
		global $c;
		foreach($c['interval'] as $v){
			$table="{$symbol}_kline_{$v}";
			if(!db::get_row_count($table)){continue;}
			$acctime=wicker::get_interval_acctime($v);
			$kline_row=db::get_one($table, "AccTime='$acctime'");
			$rise=(float)sprintf('%01.5f', ($price-$kline_row['OpenPrice'])/$kline_row['OpenPrice']);
			$data=array(
				'ClosePrice'	=>	$price,
				'LowPrice'		=>	min($price, $kline_row['LowPrice']),
				'HightPrice'	=>	max($price, $kline_row['HightPrice']),
				'Rise'			=>	$rise,
				'AccTime'		=>	$acctime,
				'AccTimeFormat'	=>	@date('Y-m-d H:i:s', $acctime)
			);
			if($kline_row){
				db::update($table, "AccTime='$acctime'", $data);
			}else{
				$data['OpenPrice']=$price;
				$data['LowPrice']=$price;
				db::insert($table, $data);
			}
			wicker::update_kline($table, "AccTime='$acctime'", $price_precision);
		}
	}
	
	public static function update_kline($table, $w, $price_precision){
		$update_kline_row=db::get_all($table, $w, '*', 'KlineId asc');
		foreach($update_kline_row as $v){
			$ma5=$ma10=$boll_mb=0;
			$kline_row=db::get_all($table, "KlineId between {$v['KlineId']}-20 and {$v['KlineId']}", '*', 'KlineId desc');
			foreach($kline_row as $k1=>$v1){
				$k1<5 && $ma5+=$v1['ClosePrice'];
				$k1<10 && $ma10+=$v1['ClosePrice'];
				$k1<21 && $boll_mb+=$v1['ClosePrice'];
			}
			$ma5=sprintf($price_precision, $ma5/5);
			$ma10=sprintf($price_precision, $ma10/10);
			$boll_mb=sprintf($price_precision, $boll_mb/21);
			$boll_pow=0;
			foreach($kline_row as $k2=>$v2){
				if($k2>=21){break;}
				$boll_pow+=pow($v2['ClosePrice']-$boll_mb, 2);
			}
			$boll_sqrt=sprintf($price_precision, sqrt($boll_pow/21));
			$boll_ub=sprintf($price_precision, $boll_mb+$boll_sqrt*2);
			$boll_lb=sprintf($price_precision, $boll_mb-$boll_sqrt*2);
			$macd_ema12=sprintf($price_precision, $kline_row[1]['MacdEma12']*11/13+$v['ClosePrice']*2/13);
			$macd_ema26=sprintf($price_precision, $kline_row[1]['MacdEma26']*25/27+$v['ClosePrice']*2/27);
			$macd_diff=sprintf($price_precision, $macd_ema12-$macd_ema26);
			$macd_dea=sprintf($price_precision, $kline_row[1]['MacdDea']*8/10+$macd_diff*2/10);
			$macd=sprintf($price_precision, $macd_diff-$macd_dea);
			$data=array(
				'MA5'		=>	$ma5,
				'MA10'		=>	$ma10,
				'BollUB'	=>	$boll_ub,
				'BollMB'	=>	$boll_mb,
				'BollLB'	=>	$boll_lb,
				'MacdEma12'	=>	$macd_ema12,
				'MacdEma26'	=>	$macd_ema26,
				'MacdDiff'	=>	$macd_diff,
				'MacdDea'	=>	$macd_dea,
				'Macd'		=>	$macd,
				'Rise'		=>	sprintf('%01.5f', ($v['ClosePrice']-$v['OpenPrice'])/$v['OpenPrice']),
				'IsUpdate'	=>	1
			);
			db::update($table, "KlineId='{$v['KlineId']}'", $data);
		}
	}
	
	public static function create_kline_table($symbol, $interval){
		db::query("CREATE TABLE IF NOT EXISTS `{$symbol}_kline_{$interval}` (
		  `KlineId` int(10) NOT NULL AUTO_INCREMENT,
		  `OpenPrice` decimal(15,8) DEFAULT '0.00000000',
		  `ClosePrice` decimal(15,8) DEFAULT '0.00000000',
		  `LowPrice` decimal(15,8) DEFAULT '0.00000000',
		  `HightPrice` decimal(15,8) DEFAULT '0.00000000',
		  `MA5` decimal(15,8) DEFAULT '0.00000000',
		  `MA10` decimal(15,8) DEFAULT '0.00000000',
		  `BollUB` decimal(15,8) DEFAULT '0.00000000',
		  `BollMB` decimal(15,8) DEFAULT '0.00000000',
		  `BollLB` decimal(15,8) DEFAULT '0.00000000',
		  `MacdEma12` decimal(15,8) DEFAULT '0.00000000',
		  `MacdEma26` decimal(15,8) DEFAULT '0.00000000',
		  `MacdDiff` decimal(15,8) DEFAULT '0.00000000',
		  `MacdDea` decimal(15,8) DEFAULT '0.00000000',
		  `Macd` decimal(15,8) DEFAULT '0.00000000',
		  `Rise` decimal(10,5) DEFAULT '0.00000',
		  `IsUpdate` tinyint(1) DEFAULT '0',
		  `AccTime` int(10) DEFAULT '0',
		  `AccTimeFormat` varchar(20) DEFAULT NULL,
		  PRIMARY KEY (`KlineId`),
		  KEY `IsUpdate` (`IsUpdate`),
		  KEY `AccTime` (`AccTime`)
		) ENGINE=MEMORY AUTO_INCREMENT=1 DEFAULT CHARSET=utf8");
	}
}






