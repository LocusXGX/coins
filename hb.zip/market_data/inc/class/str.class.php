<?php
class str{
	public static function str_code($data, $fun='htmlspecialchars', $params=array(), $data_is_first=1){	//文本编码
		if(!is_array($data)){
			return call_user_func_array($fun, $data_is_first?array_merge(array($data), $params):array_merge($params, array($data)));
		}
		$new_data=array();
		foreach((array)$data as $k=>$v){
			if(is_array($v)){
				$new_data[$k]=str::str_code($v, $fun, $params, $data_is_first);
			}else{
				$new_data[$k]=call_user_func_array($fun, $data_is_first?array_merge(array($v), $params):array_merge($params, array($v)));
			}
		}
		return $new_data;
	}
}




