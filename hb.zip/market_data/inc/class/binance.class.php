<?php
class binance{
	private $api='https://fapi.binance.com';
	private $api_method='';
	
	function exchange_info(){
		$this->api_method='/fapi/v1/exchangeInfo';
		return $this->curl($this->api.$this->api_method);
	}
	
	function ticker_24hr(){
		$this->api_method='/fapi/v1/ticker/24hr';
		return $this->curl($this->api.$this->api_method);
	}
	
	function get_history_kline($symbol, $interval, $limit){
		$symbol=strtoupper($symbol);
		$this->api_method="/fapi/v1/klines?symbol={$symbol}USDT&interval=$interval&limit=$limit";
		return $this->curl($this->api.$this->api_method);
	}
	
	function get_interest_rate(){
		$this->api_method='/fapi/v1/premiumIndex';
		return $this->curl($this->api.$this->api_method);
	}
	
	function get_ticker_price(){
		$this->api_method='/fapi/v1/ticker/price';
		return $this->curl($this->api.$this->api_method);
	}
	
	function curl($url){
		$ch=curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 3);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);  
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
		$result=array();
		$result['msg']=@json_decode(curl_exec($ch), true);
		$ch_info=curl_getinfo($ch);
		$result['ret']=((int)$ch_info['http_code']==200 && (int)$result['msg']['code']<1000)?1:0;
		curl_close($ch);
		return $result;
	}
}



