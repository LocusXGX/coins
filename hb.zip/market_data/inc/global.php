<?php
$c=array(
	'root_path'		=>	substr(dirname(__FILE__), 0, -4),
	'time'			=>	time(),
	'microtime'		=>	intval(microtime(true)*1000),
	'interval'		=>	array('30m','1h','2h','4h','12h','1d','1w'),
	'symbol_quick'	=>	array('btc','eth'),
	'db_cfg'		=>	array(
							'host'		=>	'localhost',
							'database'	=>	'xxxxxxxxxxxxxxxxxxxxxxxxxx',
							'username'	=>	'xxxxxxxxxxxxxxxxxxxxxxxxxx',
							'password'	=>	'xxxxxxxxxxxxxxxxxxxxxxxxxx'
						)
);
wicker_system_init::init();
class wicker_system_init{
	public static function init(){
		global $c;
		@error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
		@set_time_limit(60);
		@header('Content-Type: text/html; charset=utf-8');
		self::slashes_gpcf($_GET);
		self::slashes_gpcf($_POST);
		self::slashes_gpcf($_COOKIE);
		self::slashes_gpcf($_FILES);
		date_default_timezone_set('PRC');
		spl_autoload_register('self::class_auto_load');
		$c['config']=wicker::get_config();
		!is_array($c['config']['symbol']) && $c['config']['symbol']=array();
		!is_array($c['config']['price_precision']) && $c['config']['price_precision']=array();
		!is_array($c['config']['ticker_price']) && $c['config']['ticker_price']=array();
	}
	
	private static function class_auto_load($class_name){
		global $c;
		$file=$c['root_path'].'/inc/class/'.$class_name.'.class.php';
		@is_file($file) && include($file);
	}
	
	private static function slashes_gpcf(&$ary){
		foreach($ary as $k=>$v){
			if(is_array($v)){
				self::slashes_gpcf($ary[$k]);
			}else{
				$ary[$k]=trim($ary[$k]);
				!get_magic_quotes_gpc() && $ary[$k]=addslashes($ary[$k]);
			}
		}
	}
}



