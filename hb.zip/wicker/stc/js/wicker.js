var wicker_obj={
	submit_form:function(o, callback, success_callback, error_callback){
		o.submit(function(){return false;});
		o.find('input:button,input:submit').click(function(){
			if($.isFunction(callback) && callback($(this).attr('attr'))===false){return false;};
			o.find('input:submit').attr('disabled', true);
			wicker_obj.ajax_post_tips();
			$.post('?', o.serialize(), function(data){
				$('#ajax_post_tips').remove();
				if(data.ret==1){
					$.isFunction(success_callback)?success_callback(data.msg):window.location='./';
				}else{
					o.find('input:submit').attr('disabled', false);
					wicker_obj.win_alert(data.msg, function(){
						wicker_obj.div_mask();
						$.isFunction(error_callback) && error_callback(data.msg);
					});
				}
			}, 'json');
		});
	},
	
	ajax_post_tips:function(remove, msg){
		var msg=msg?msg:'数据提交中...';
		if(!$('#ajax_post_tips').size()){
			$('body').prepend('<div id="ajax_post_tips">'+msg+'</div>');
			$('#ajax_post_tips').css({position:'fixed', width:$(document).width()<1024?$(document).width()-22:500, height:60, 'line-height':'60px', border:$(document).width()<1024?'none':'1px solid #252a44', top:$(window).height()/2-180, background:'#000', 'text-align':'center', 'z-index':5000});
			$('#ajax_post_tips').css({left:$(window).width()/2-$('#ajax_post_tips').width()/2});
		}
		if(remove==1 && $('#ajax_post_tips').size()){
			$('#ajax_post_tips').html(msg).fadeOut(5000, function(){
				$('#ajax_post_tips').remove();
			});
		}
	},
	
	div_mask:function(remove){
		if(remove==1){
			$('#div_mask').remove();
		}else{
			if(!$('#div_mask').size()){
				$('body').prepend('<div id="div_mask"></div>');
				$('#div_mask').css({width:'100%', height:$(document).height(), overflow:'hidden', position:'absolute', top:0, left:0, background:'#000', opacity:0.4, 'z-index':3000});
			}
		}
	},
	
	win_alert:function(tips, callback, remove_div_mask, type){
		wicker_obj.div_mask();
		$('.win_alert').remove();
		var type=(typeof(arguments[3])=='undefined')?'alert':arguments[3];
		var html='<div class="win_alert">';
			html+='<div class="win_close"><h2 class="close">×</h2></div>';
			html+='<div class="win_tips">'+tips+'</div>';
			html+='<div class="win_btns"><button class="btn btn_sure">确定</button>';
			if(type=='confirm') html+='<button class="btn btn_cancel">取消</button>';
			html+='</div>';
			html+='</div>';
		$('body').prepend(html);
		$('.win_alert').css({left:$(window).width()/2-$('.win_alert').width()/2});
		if(type=='confirm'){
			$('.win_alert').delegate('.close, .btn_cancel', 'click', function(){
				$('.win_alert').remove();
				remove_div_mask!=0 && wicker_obj.div_mask(1);
				$.isFunction(callback) && callback(0);
			}).delegate('.btn_sure', 'click', function(){
				$('.win_alert').remove();
				remove_div_mask!=0 && wicker_obj.div_mask(1);
				$.isFunction(callback) && callback(1);
			});
		}else{
			$('.win_alert').delegate('.close, .btn_sure', 'click', function(){
				$('.win_alert').remove();
				remove_div_mask!=0 && wicker_obj.div_mask(1);
				$.isFunction(callback) && callback(1);
			});
		}
		$('.win_alert').click(function(e){
			e.stopPropagation();
		});
		return false;
	},
	
	echars_kline_option:function(obj){
		return {
			backgroundColor:'#141826',
			color:['#ef05ce', '#1b7cff', '#a300e7', '#f7c00a', '#a300e7'],
			animation:false,
			legend:{show:false},
			title:{
				show:false,
				left:'right',
				textStyle:{fontSize:12, color:'#b0b8db'}
			},
			tooltip:{
				trigger:'axis',
				backgroundColor:'#141826',
				borderWidth:2,
				borderColor:'#252a44',
				padding:10,
				axisPointer:{type:'cross'},
				textStyle:{color:'#b0b8db', fontSize:12, fontWeight:'normal'},
				position:function(pos, params, el, elRect, size){
					if($(document).width()>=1000){
						return {top:Math.min(pos[1]+10, obj.height()-380), left:pos[0]+10};
					}
				},
				valueFormatter:function(value){
					return value!=''?(value*1).toFixed(main_obj.price_precision):''
				}
			},
			axisPointer:{
				link:{xAxisIndex:'all'},
				label:{
					backgroundColor:'#252a44',
					color:'#b0b8db',
					formatter:function(params){
						return params.axisDimension=='x'?params.value:(params.value*1).toFixed(main_obj.price_precision);
					}
				}
			},
			grid:[
				{
					left:70,
					right:10,
					top:20,
					height:obj.height()-200
				},
				{
					left:70,
					right:10,
					bottom:20,
					height:130
				}
			],
			dataZoom:[
				{
					type:'inside',
					xAxisIndex:[0,1],
					start:80,
					end:100
				},
				{
					type:'inside',
					xAxisIndex:[0,1],
					start:80,
					end:100
				}
			],
			xAxis:[
				{
					type:'category',
					scale:true,
					axisTick:{show:false},
					axisLine:{onZero:false, show:true, lineStyle:{color:'#555555'}},
					splitLine:{show:false},
					axisLabel:{show:false, showMinLabel:false},
					min:'dataMin',
					max:'dataMax'
				},
				{
					type:'category',
					gridIndex:1,
					scale:true,
					axisTick:{show:false},
					axisLine:{onZero:false, show:false, lineStyle:{color:'#555555'}},
					splitLine:{show:false},
					axisLabel:{show:false, showMinLabel:false},
					min:'dataMin',
					max:'dataMax'
				}
			],
			yAxis:[
				{
					type:'value',
					scale:true,
					axisLine:{show:true, lineStyle:{color:'#555555'}},
					splitArea:{show:false},
					splitLine:{show:false},
					axisLabel:{
						formatter:function(value){
							return (value*1).toFixed(main_obj.price_precision);
						}
					}
				},
				{
					type:'value',
					scale:true,
					gridIndex:1,
					axisLine:{show:true, lineStyle:{color:'#555555'}},
					splitArea:{show:false},
					splitLine:{show:false},
					axisLabel:{show:false}
				}
			],
			visualMap:[
				{
					show:false,
					seriesIndex:6,
					dimension:2,
					pieces:[{value:0, color:'#12b886'}, {value:1, color:'#fa5252'}]  
				},
				{
					show:false,
					seriesIndex:8,
					dimension:2,
					pieces:[{value:1, color:'#12b886'}, {value:-1, color:'#fa5252'}]
				}
			],
			series:[
				{
					name:'K图',
					type:'candlestick',
					itemStyle:{
						color:'#12b886',
						color0:'#fa5252',
						borderColor:null,
						borderColor0:null
					}
				},
				{
					name:'MA5',
					type:'line',
					showSymbol:false,
					smooth:true,
					lineStyle:{width:0.8},
					emphasis:{lineStyle:{width:0.8}}
				},
				{
					name:'MA10',
					type:'line',
					showSymbol:false,
					smooth:true,
					lineStyle:{width:0.8},
					emphasis:{lineStyle:{width:0.8}}
				},
				{
					name:'上轨',
					type:'line',
					showSymbol:false,
					smooth:true,
					lineStyle:{width:0.8},
					emphasis:{lineStyle:{width:0.8}}
				},
				{
					name:'中轨',
					type:'line',
					showSymbol:false,
					smooth:true,
					lineStyle:{width:0.8},
					emphasis:{lineStyle:{width:0.8}}
				},
				{
					name:'下轨',
					type:'line',
					showSymbol:false,
					smooth:true,
					lineStyle:{width:0.8},
					emphasis:{lineStyle:{width:0.8}}
				},
				{
					name:'DIFF',
					type:'line',
					showSymbol:false,
					smooth:true,
					lineStyle:{width:0.8},
					emphasis:{lineStyle:{width:0.8}},
					xAxisIndex:1,
					yAxisIndex:1,
					tooltip:{show:false}
				},
				{
					name:'DEA',
					type:'line',
					showSymbol:false,
					smooth:true,
					lineStyle:{width:0.8},
					emphasis:{lineStyle:{width:0.8}},
					xAxisIndex:1,
					yAxisIndex:1,
					tooltip:{show:false}
				},
				{
					name:'MACD',
					type:'bar',
					xAxisIndex:1,
					yAxisIndex:1,
					tooltip:{show:false}
				}
			]
		}
	},
	
	echars_profit_option:function(obj){
		return {
			backgroundColor:'#141826',
			color:['#555'],
			legend:{show:false},
			grid:[
				{
					left:55,
					right:20,
					top:10,
					height:obj.height()-20
				}
			],
			xAxis:{type:'value',show:false},
			yAxis:{
				type:'category',
				axisTick:{show:false},
				axisPointer:{show:false}
			},
			series:[
				{
					type:'bar',
					name:'收益',
					cursor:'default',
					barWidth:16,
					label:{show:true, color:'#fff', formatter:function(params){return (params.color=='#12b886'?'':'-')+'$'+params.value;}}
				}
			]
		}
	},
	
	echars_profit_rate_option:function(obj){
		return {
			backgroundColor:'#141826',
			color:['#12b886'],
			animation:false,
			legend:{show:false},
			title:{
				show:false,
				left:'right',
				textStyle:{
					fontSize:12,
					color:'#b0b8db',
				}
			},
			tooltip:{
				trigger:'axis',
				backgroundColor:'#141826',
				borderWidth:2,
				borderColor:'#252a44',
				padding:10,
				textStyle:{color:'#b0b8db', fontSize:12, fontWeight:'normal'}
			},
			grid:[
				{
					left:55,
					right:10,
					top:20,
					height:obj.height()-40
				}
			],
			xAxis:{type:'category',show:false},
			yAxis:{
				type:'value',
				axisLine:{onZero:false, show:true, lineStyle:{color:'#555555'}},
				splitLine:{show:false}
			},
			series:[
				{
					type:'line',
					smooth:true,
					lineStyle:{width:1},
					emphasis:{lineStyle:{width:1}},
					name:'总收益'
				}
			]
		}
	}
}





