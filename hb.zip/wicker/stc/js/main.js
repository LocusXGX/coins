var main_obj={
	plan_list_md5:'',
	plan_list_orders_id:'',
	plan_list_update_time:0,
	quote_volume_md5:'',
	auto_open_md5:'',
	price_precision:0,
	page_init:function(){
		$('input').attr('autocomplete', 'off');
		wicker_obj.submit_form($('.login_form'), '', '', function(){wicker_obj.div_mask(1)});
		wicker_obj.submit_form($('.auto_open_form'), '', function(msg){
			$('.auto_open_form .btn_ok').prop('disabled', false);
			$('.auto_open_form').parent().hide();
			wicker_obj.div_mask(1);
		});
		$('.auto_open_form select[name=auto_open_price_type]').change(function(){
			if($(this).val()=='' || $(this).val()==0){
				$('.auto_open_form .price_type_0').show();
				$('.auto_open_form .price_type_1').hide();
			}else{
				$('.auto_open_form .price_type_0').hide();
				$('.auto_open_form .price_type_1').show();
			}
		}).change();
		wicker_obj.submit_form($('.set_form'), '', function(msg){
			$('.set_form .btn_ok').prop('disabled', false);
			$('.set_form').parent().hide();
			wicker_obj.div_mask(1);
		});
		wicker_obj.submit_form($('.plan_form'), '', function(msg){
			$('.plan_form .btn_ok').prop('disabled', false);
			$('.plan_list').html('');
			main_obj.plan_list_md5='';
			wicker_obj.win_alert(msg, function(){
				wicker_obj.div_mask();
			});
		});
		wicker_obj.submit_form($('.open_form'), function(position_side){
			$('.open_form input[name=position_side]').val(position_side);
		}, function(){
			$('.open_form input:submit').attr('disabled', false);
			$('.open_form input[name=place_price], .open_form input[name=position_side]').val('');
			$('.open_form select[name=volume] option:first').prop('selected', true);
			$('.open_form select[name=stop_win] option:first').prop('selected', true);
		}, function(){wicker_obj.div_mask(1)});
		$('.open_form .position_type li').click(function(){
			$('.open_form input[name=position_side]').val('');
			$('.open_form .position_type li').removeClass('cur');
			$(this).addClass('cur');
			$('.open_form input[name=position_type]').val($(this).attr('rel'));
			$('.open_form .open_btn,.open_form .close_btn').hide();
			$('.open_form .'+$(this).attr('rel')+'_btn').show();
		});
		wicker_obj.submit_form($('.choose_form'), '', function(msg){
			$('.choose_form .btn_ok').prop('disabled', false);
			$('.choose_form .choose_list').html(msg.choose_list);
			$('.choose_form .choose_list a:first').click();
			$('.interval a').removeClass('fc_red');
			$('.interval a[rel='+msg.interval+']').addClass('fc_red');
		}, function(){wicker_obj.div_mask(1)});
		$('.choose_form .t span').click(function(){
			$('.choose_form').hide();
		});
		$('.contents .righter .choose').click(function(){
			if($(document).width()<1024){
				$('.choose_form .choose_list').height($('.nav').outerHeight()+$('.open_form').outerHeight()+$('.orders').outerHeight()-$('.choose_form .t').outerHeight());
			}else{
				$('.choose_form .choose_list').height($('.righter').outerHeight()-$('.nav').outerHeight()-$('.logs').outerHeight()-$('.choose_form .t').outerHeight()-5);
			}
			$('.choose_form').show();
		});
		$(document).on('click', '.orders .cancel_orders', function(){
			$.post('./', $(this).attr('rel'), function(data){
				wicker_obj.win_alert(data.msg);
			}, 'json');
			return false;
		});
		$(document).on('click', '.orders .set_confirm', function(){
			$.post('./', 'do_action=set_confirm&OrdersId='+$(this).attr('rel'), function(data){
				wicker_obj.win_alert(data.msg);
			}, 'json');
			return false;
		});
		$(document).on('click', '.set_form a[rel=set_cost_close]', function(){
			$.post('./', 'do_action=set_cost_close&OrdersId='+$('.set_form input[name=OrdersId]').val(), function(data){
				wicker_obj.win_alert(data.msg, function(){
					wicker_obj.div_mask();
				});
			}, 'json');
			return false;
		});
		$(document).on('click', '.orders .clear_orders', function(){
			var o=$(this);
			wicker_obj.win_alert(o.attr('clear_opt_side')+'您确定要进行此操作吗？', function(ret){
				if(!ret){return;}
				$.post('./', o.attr('rel'), function(data){
					wicker_obj.win_alert(data.msg);
				}, 'json');
			}, 1, 'confirm');
		});
		$(document).on('click', '.auto_open', function(){
			$.post('./', 'do_action=auto_open_config', function(data){
				wicker_obj.div_mask();
				$('.auto_open_form').parent().show();
				$('.auto_open_form .symbol').html(data.msg.symbol);
				$('.auto_open_form select[name=auto_open_amout]').val(data.msg.auto_open_amout);
				$('.auto_open_form select[name=auto_open_stop_win_percent]').val(data.msg.stop_win_percent==0?'':(data.msg.stop_win_percent*1).toFixed(2));
				$('.auto_open_form select[name=auto_open_stop_loss_percent]').val(data.msg.stop_loss_percent==0?'':(data.msg.stop_loss_percent*1).toFixed(2));
			}, 'json');
		});
		$(document).on('click', '.auto_open_del', function(){
			$.post('./', 'do_action=auto_open_del&OpenId='+$(this).attr('rel'), function(data){
				if(data.ret==1){
					$(this).parents('li').remove();
				}else{
					wicker_obj.win_alert(data.msg);
				}
			}, 'json');
		});
		$(document).on('click', '.orders .set', function(){
			$('.set_form input[name=OrdersId]').val($(this).attr('rel'));
			$.post('./', 'do_action=get_config&OrdersId='+$(this).attr('rel'), function(data){
				wicker_obj.div_mask();
				$('.set_form').parent().show();
				$('.set_form .symbol').html(data.msg.base.symbol);
				$('.set_form .position_side').html(data.msg.base.position_side);
				$('.set_form select[name=set_stop_win_percent]').val(data.msg.set_stop_win_percent==0?'':(data.msg.set_stop_win_percent*1).toFixed(2));
				$('.set_form select[name=set_stop_win_price]').val(data.msg.set_stop_win_price==0?'':data.msg.set_stop_win_price*1);
				$('.set_form input[name=set_stop_win_ticker_price]').val(data.msg.set_stop_win_ticker_price);
				$('.set_form select[name=set_float_win_percent]').val(data.msg.set_float_win_percent==0?'':(data.msg.set_float_win_percent*1).toFixed(2));
				$('.set_form select[name=set_float_win_price]').val(data.msg.set_float_win_price==0?'':data.msg.set_float_win_price*1);
				$('.set_form input[name=set_float_win_ticker_price]').val(data.msg.set_float_win_ticker_price);
				$('.set_form select[name=set_stop_loss_percent]').val(data.msg.set_stop_loss_percent==0?'':(data.msg.set_stop_loss_percent*1).toFixed(2));
				$('.set_form select[name=set_stop_loss_price]').val(data.msg.set_stop_loss_price==0?'':data.msg.set_stop_loss_price*1);
				$('.set_form input[name=set_stop_loss_ticker_price]').val(data.msg.set_stop_loss_ticker_price);
				$('.set_form select[name=set_cut_stock]').val(data.msg.set_cut_stock==0?'':data.msg.set_cut_stock);
				$('.set_form input[name=set_reset_plan]').prop('checked', data.msg.set_reset_plan==1?true:false);
			}, 'json');
		});
		$(document).on('click', '.orders .plan', function(){
			wicker_obj.div_mask();
			main_obj.plan_list_md5='';
			main_obj.plan_list_orders_id=$(this).attr('rel');
			$('.plan_form .t .symbol,.plan_form .t .position_side,.plan_list').html('');
			$('.plan_form').parent().show();
			$('.plan_form .r_con_form input[name=OrdersId]').val($(this).attr('rel'));
		});
		$('.plan_form select[name=price_type]').change(function(){
			if($(this).val()=='' || $(this).val()==0){
				$('.plan_form .price_type_0').show();
				$('.plan_form .price_type_1').hide();
			}else{
				$('.plan_form .price_type_0').hide();
				$('.plan_form .price_type_1').show();
			}
		}).change();
		$('.plan_form select[name=close_percent]').change(function(){
			var o=$('.plan_form select[name=is_loop]').parent('div');
			$(this).val()>0?o.show():o.hide();
		}).change();
		$('.plan_form input[name=price], .open_form input[name=place_price]').focus(function(){
			$(this).val('');
		});
		$('.plan_form a[rel=plan_quick_set], .plan_form a[rel=plan_clear]').click(function(){
			var o=$(this);
			wicker_obj.win_alert('【'+$('.plan_form .symbol').html()+'】【'+$('.plan_form .position_side').html()+'】您确定要进行此操作吗？', function(ret){
				if(!ret){return;}
				$.post('./', 'do_action='+o.attr('rel')+'&OrdersId='+$('.plan_form .r_con_form input[name=OrdersId]').val(), function(data){
					if(data.ret==1){
						$('.plan_list').html('');
						main_obj.plan_list_md5='';
					}else{
						wicker_obj.win_alert(data.msg, function(){
							wicker_obj.div_mask();
						});
					}
				}, 'json');
			}, 0, 'confirm');
		});
		$('.plan_form a[rel=1h_BollUB], .plan_form a[rel=1h_BollMB], .plan_form a[rel=1h_BollLB]').click(function(){
			$('.plan_form select[name=price_type]').val(1).change();
			$('.plan_form select[name=price_txt_interval]').val('1h');
			$('.plan_form select[name=price_txt_indicator]').val($(this).attr('rel').replace('1h_', ''));
		});
		$(document).on('click', '.pop_form .plan_del', function(){
			var o=$(this);
			$.post('./', 'do_action=plan_del&PlanId='+o.attr('PlanId'), function(data){
				if(data.ret==1){
					o.parents('tr').remove();
				}else{
					wicker_obj.win_alert(data.msg, function(){
						wicker_obj.div_mask();
					});
				}
			}, 'json');
		});
		$('.profit').click(function(){
			$.post('./', 'do_action=get_profit_data', function(data){
				wicker_obj.div_mask();
				$('.profit_form').parent().show();
				$('#chart_profit').height(data.msg[0][1].length*30);
				var chart_profit=echarts.init(document.getElementById('chart_profit'));
				chart_profit.setOption(wicker_obj.echars_profit_option($('#chart_profit')));
				chart_profit.setOption({
					yAxis:[{data:data.msg[0][0]}],
					series:[{data:data.msg[0][1]}]
				});
				var chart_profit_rate=echarts.init(document.getElementById('chart_profit_rate'));
				chart_profit_rate.setOption(wicker_obj.echars_profit_rate_option($('#chart_profit_rate')));
				chart_profit_rate.setOption({
					xAxis:[{data:data.msg[1][0]}],
					series:[{data:data.msg[1][1]}]
				});
			}, 'json');
		});
		$(document).on('click', '.pop_form .t span', function(){
			wicker_obj.div_mask(1);
			$(this).parents('.pop_form').hide();
		});
		$(document).keyup(function(e){
			if(e.keyCode!=27){return;}
			if($('.win_alert:visible').size()){
				$('.win_alert:visible .btn_cancel:visible').size()?$('.win_alert:visible .btn_cancel').click():$('.win_alert:visible .btn_sure').click();
			}else{
				$('.pop_form:visible .t span').click();
			}
		});
		$(document).on('click', '.orders .get_orders_list', function(){
			$.post('./', 'do_action=get_orders_list&OrdersId='+$(this).parents('tr').attr('OrdersId'), function(data){
				$('.orders_list').parent().remove();
				wicker_obj.div_mask();
				$('body').append(data.msg);
				$('.orders_list').parent().show();
			}, 'json');
			return false;
		});
		$(document).on('click', '.righter .logs .cancel_list_orders,.orders_list .r_con_table .cancel_list_orders', function(){
			var o=$(this);
			var div_mask=$('#div_mask:visible').size();
			$.post('./', 'do_action=cancel_list_orders&ListId='+o.attr('rel'), function(data){
				if(data.ret==1){
					o.parents('tr').remove();
				}else{
					wicker_obj.win_alert(data.msg, function(){
						div_mask?wicker_obj.div_mask():'';
					});
				}
			}, 'json');
			return false;
		});
		if($(document).width()>=1024){
			$('.lefter .nav .coin_list').html('<div class="list list_pc">'+$('.righter .nav .coin_list div').html()+'</div>').addClass('coin_list_pc');
			if($(document).width()>1024){
				$('.lefter .kline_box').css({'padding-left':140});
				$('.lefter .nav .coin_list>div').height($('.contents').height()-18);
			}
			$('.righter .nav').eq(0).prepend('监控').find('.coin_list').remove();
		}
		$(document).on('click', '.coin_list .list a,.orders .set_symbol,.choose_list .set_symbol,.logs .set_symbol', function(){
			var o=$(this);
			$(document).width()<1024 && o.parent('.coin_list .list').hide();
			$.post('./', 'do_action=set_symbol&symbol='+o.attr('rel'), function(data){
				$('.coin_list>font a').html(data.msg[0]);
				$('.coin_list .list a').removeClass('fc_red');
				$('.coin_list .list a[rel='+data.msg[0]+']').addClass('fc_red');
				$('.choose_list a').removeClass('fc_red').addClass('fc_green');
				$('.choose_list a[rel='+data.msg[0]+']').removeClass('fc_green').addClass('fc_red');
				$('.open_form input[name=place_price]').val('');
				$('.open_form select[name=volume] option').not(':first').remove();
				$('.plan_form select[name=volume] option').not(':first').remove();
				$('.set_form select[name=set_cut_stock] option').not(':first').remove();
				$('.auto_open_form select[name=auto_open_amout] option').not(':first').remove();
				$(data.msg[1]).each(function(k, v){
					$('.open_form select[name=volume]').append('<option value="'+v+'">'+v+'</option>');
					$('.plan_form select[name=volume]').append('<option value="'+v+'">'+v+'</option>');
					$('.set_form select[name=set_cut_stock]').append('<option value="'+v+'">'+v+'</option>');
					$('.auto_open_form select[name=auto_open_amout]').append('<option value="'+v+'">'+v+'</option>');
				});
			}, 'json');
			return false;
		});
		$('.contents .righter .logs').click(function(){
			$.post('./', 'do_action=set_click_price&price=0');
		});
		$('.coin_list a').filter('.fc_red').click();
		$(document).on('click', '.turn_page a', function(){
			var o=$(this);
			$.post('./', 'do_action=set_page&page='+o.attr('page'), function(){
				$('.turn_page .page_item').removeClass('page_item_current');
				$('.turn_page .page_item[page='+data.msg+']').addClass('page_item_current');
			}, 'json');
			return false;
		});
		$(document).on('click', '.interval a', function(){
			var o=$(this);
			$.post('./', 'do_action=set_interval&interval='+o.attr('rel'), function(data){
				$('.interval a').removeClass('fc_red');
				$('.interval a[rel='+o.attr('rel')+']').addClass('fc_red');
			}, 'json');
			return false;
		});
		$(document).on('touchstart mouseover', '.contents .nav .menu', function(e){
			e.stopPropagation();
			$(this).find('.list').show();
		});
		if($(document).width()<1024){
			$(document).on('touchstart', 'body', function(){
				$('.contents .menu .list').hide();
			});
		}
		if($('.page').size()){
			kline=echarts.init(document.getElementById('kline'));
			kline.setOption(wicker_obj.echars_kline_option($('#kline')));
			kline.getZr().on('click', function(params){
				var op=kline.getOption();
				var pointInPixel=[params.offsetX, params.offsetY];
				if(kline.containPixel('grid', pointInPixel)){
					var price=kline.convertFromPixel({seriesIndex:0}, pointInPixel)[1];
					price=price.toFixed(main_obj.price_precision);
					$('.open_form input[name=place_price]').val(price);
					$.post('./', 'do_action=set_click_price&price='+price);
				}
			});
			main_obj.get_data();
		}
	},
	
	get_data:function(){
		$.ajax({
			type:'get',
			url:'?do_action=get_data&plan_list_orders_id='+main_obj.plan_list_orders_id+'&screen_width='+$(document).width()+(query_string!=''?'&'+query_string:''),
			dataType:'json',
			async:true,
			timeout:5000,
			success:function(data){
				if(data.ret!=1){
					if(data.ret==2){
						window.location='/';
					}else{
						setTimeout(function(){main_obj.get_data()}, 500);
					}
					return;
				}
				main_obj.price_precision=data.msg.price_precision;
				var title=data.msg.price+'【'+data.msg.symbol+'】';
				$('title').html('+'+title);
				setTimeout(function(){$('title').html(title);}, 500);
				kline.setOption({
					title:{text:data.msg.kline.name},
					xAxis:[{data:data.msg.kline.time},{data:data.msg.kline.time}],
					series:[
						{
							data:data.msg.kline.kline,
							markLine:{
								silent:true,
								precision:main_obj.price_precision,
								symbol:['none','none'],
								lineStyle:{
									width:1,
									opacity:0.7
								},
								label:{
									position:'insideStartTop',
									distance:[10,-14],
									padding:[8,10],
									color:'#fff'
								},
								data:data.msg.kline.orders
							}
						},
						{data:data.msg.kline.ma5},
						{data:data.msg.kline.ma10},
						{data:data.msg.kline.boll_ub},
						{data:data.msg.kline.boll_mb},
						{data:data.msg.kline.boll_lb},
						{data:data.msg.kline.macd_diff},
						{data:data.msg.kline.macd_dea},
						{data:data.msg.kline.macd_bar}
					]
				});
				$('.righter .logs .logs_l').html(data.msg.info+data.msg.logs);
				if(main_obj.auto_open_md5!=data.msg.auto_open_md5){
					$('.righter .logs .logs_r').html(data.msg.auto_open);
					main_obj.auto_open_md5=data.msg.auto_open_md5;
					data.msg.auto_open==''?$('.contents .righter .item.logs').addClass('auto_open_null'):$('.contents .righter .item.logs').removeClass('auto_open_null');
				}
				if(data.msg.logs.indexOf('无持仓')!=-1){
					$('.righter .logs').addClass('min_height');
				}else{
					$('.righter .logs').removeClass('min_height');
				}
				if($(data.msg.orders).find('.r_con_table tbody tr').size()!=$('.orders tbody tr').size() || $('.orders').html()==''){
					$('.orders').html(data.msg.orders);
				}else{
					$('.orders tbody tr').each(function(k){
						var orders=$(data.msg.orders).find('.r_con_table tbody tr:eq('+k+')');
						if($(this).attr('OrderSign')==orders.attr('OrderSign') || $(this).find('input').size()){return;}
						$(this).attr('OrderSign', orders.attr('OrderSign'));
						$(this).attr('OrdersId', orders.attr('OrdersId'));
						$(this).find('td').each(function(k1){
							var html=orders.find('td:eq('+k1+')').html();
							$(this).html()!=html && $(this).html(html).stop().animate({left:6}, 50).animate({left:0}, 50);
						});
					});
				}
				($('.turn_page').attr('total_page')!=$(data.msg.orders).find('.turn_page').attr('total_page') || $('.turn_page .page_item:first').attr('page')!=$(data.msg.orders).find('.turn_page .page_item:first').attr('page')) && $('.turn_page').html($(data.msg.orders).find('.turn_page').html()).attr('total_page', $(data.msg.orders).find('.turn_page').attr('total_page'));
				$('.turn_page .page_item').removeClass('page_item_current');
				$('.turn_page .page_item[page='+data.msg.orders_page+']').addClass('page_item_current');
				if(main_obj.quote_volume_md5!=data.msg.quote_volume_md5){
					$('.coin_list .list a font.dot').hide();
					$.each(data.msg.quote_volume, function(k, v){
						$('.coin_list .list a[rel='+v+'] font.dot').css({display:'inline-block'});
					});
					main_obj.quote_volume_md5=data.msg.quote_volume_md5;
				}
				$.each(data.msg.rise, function(k, v){
					var o=$('.lefter .nav .coin_list div a[rel='+k+'] span, .righter .nav .coin_list div a[rel='+k+'] span');
					o.html((v>=0?'+':'')+(v*100).toFixed(2)+'%');
					o.removeClass('green red').addClass(v>=0?'green':'red');
				});
				if($('.plan_list').is(':visible')){
					$('.plan_form .t .symbol').html(data.msg.plan_list[1]);
					$('.plan_form .t .position_side').html(data.msg.plan_list[2]);
					if(main_obj.plan_list_md5!=data.msg.plan_list_md5){
						main_obj.plan_list_md5=data.msg.plan_list_md5;
						if($(data.msg.plan_list[0]).find('.r_con_table tbody tr').size()>100){
							if(main_obj.plan_list_update_time+5<data.msg.time || $('.plan_list').html()==''){
								main_obj.plan_list_update_time=data.msg.time;
								$('.plan_list').html(data.msg.plan_list[0]);
							}
						}else{
							if($(data.msg.plan_list[0]).find('.r_con_table tbody tr').size()!=$('.plan_list tbody tr').size() || $('.plan_list').html()==''){
								$('.plan_list').html(data.msg.plan_list[0]);
							}else{
								$('.plan_list tbody tr').each(function(k){
									var plan_list=$(data.msg.plan_list[0]).find('.r_con_table tbody tr:eq('+k+')');
									if($(this).attr('PlanSign')==plan_list.attr('PlanSign')){return;}
									$(this).attr('PlanSign', plan_list.attr('PlanSign'));
									$(this).find('td').removeClass('fc_gory').addClass(plan_list.attr('class'));
									$(this).find('td').each(function(k1){
										var html=plan_list.find('td:eq('+k1+')').html();
										$(this).html()!=html && $(this).html(html).stop().animate({left:6}, 50).animate({left:0}, 50);
									});
								});
							}
						}
					}
				}
				setTimeout(function(){main_obj.get_data()}, 500);
			},
			error:function(){
				setTimeout(function(){main_obj.get_data()}, 500);
			}
		});
	}
}






