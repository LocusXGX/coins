<?php
!isset($c) && exit;
$c['binance']=array(
	'symbol'			=>	array(),
	'main_symbol'		=>	array('btc','eth'),
	'kline_interval'	=>	array('1h','2h','4h','12h','1d','1w'),
	'percent_list'		=>	array(0.01,0.05,0.1,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5),
	'price_list'		=>	array(125,250,500,750,1000,1250,1500,2000,2500,3000),
	'price_pending'		=>	0.5,
	'price_modulo'		=>	100,
	'close_out'			=>	3000,
	'trade_fee'			=>	array(0.0002,0.0004),
	'api_limit'			=>	50,
	'is_debug'			=>	0,
	'default_set'		=>	array(
								'volume_operation'	=>	array(1250,2500,5000),
								'win_loss_percent'	=>	array(5,10),
								'float_win_set'		=>	array(0,0),
								'win_percent_reset'	=>	array(0,0),
								'open_set'			=>	array(
															'cut_stock'		=>	0,
															'reset_plan'	=>	0,
															'set_plan'		=>	0
														),
								'plan'				=>	array(
															'count'			=>	array(200,50),
															'type'			=>	array(0,1),
															'volume'		=>	array(1/50,1/50),
															'open_percent'	=>	array(0.25,0.25),
															'close_percent'	=>	array(0.25,0.25),
															'first_offset'	=>	array(0),
															'pending_multi'	=>	3
														)
							),
	'default_set_main'	=>	array(
								'volume_operation'	=>	array(12500,25000,50000),
								'win_loss_percent'	=>	array(2,4),
								'float_win_set'		=>	array(0,0),
								'win_percent_reset'	=>	array(0,0),
								'open_set'			=>	array(
															'cut_stock'		=>	0,
															'reset_plan'	=>	0,
															'set_plan'		=>	0
														),
								'plan'				=>	array(
															'count'			=>	array(0),
															'type'			=>	array(0),
															'volume'		=>	array(1/10),
															'open_percent'	=>	array(0.125),
															'close_percent'	=>	array(0.125),
															'first_offset'	=>	array(0),
															'pending_multi'	=>	1
														)
							)
);




