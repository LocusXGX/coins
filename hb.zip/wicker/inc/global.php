<?php
$c=array(
	'root_path'			=>	substr(dirname(__FILE__), 0, -4),
	'time'				=>	time(),
	'microtime'			=>	intval(microtime(true)*1000),
	'today'				=>	strtotime('today'),
	'time_format'		=>	date('Y-m-d H:i:s'),
	'login_user'		=>	array('xxxxxxxxxxxxxxxxxxxxxxxxxx', 'xxxxxxxxxxxxxxxxxxxxxxxxxx'),
	'binance_api'			=>	array(
								'AccessKey'	=>	'xxxxxxxxxxxxxxxxxxxxxxxxxx',
								'SecretKey'	=>	'xxxxxxxxxxxxxxxxxxxxxxxxxx'
							),
	'db_cfg'			=>	array(
								'host'		=>	'localhost',
								'market_db'	=>	'xxxxxxxxxxxxxxxxxxxxxxxxxx',
								'database'	=>	'xxxxxxxxxxxxxxxxxxxxxxxxxx',
								'username'	=>	'xxxxxxxxxxxxxxxxxxxxxxxxxx',
								'password'	=>	'xxxxxxxxxxxxxxxxxxxxxxxxxx'
							),
	'mail_smtp'			=>	array(
								'Host'		=>	'xxxxxxxxxxxxxxxxxxxxxxxxxx',
								'UserName'	=>	'xxxxxxxxxxxxxxxxxxxxxxxxxx',
								'Password'	=>	'xxxxxxxxxxxxxxxxxxxxxxxxxx'
							),
	'mail_to'			=>	'xxxxxxxxxxxxxxxxxxxxxxxxxx',
	'n_a'				=>	'<font class="fc_gory">N.A</font>',
	'n_y'				=>	array('否', '是'),
	'kline_indicator'	=>	array(
								'MA5'		=>	'MA5',
								'MA10'		=>	'MA10',
								'BollUB'	=>	'上轨',
								'BollMB'	=>	'中轨',
								'BollLB'	=>	'下轨'
							),
	'choose_reference'	=>	array('距离MA5', '距离MA10', '距离上轨', '距离中轨', '距离下轨', '涨幅', '跌幅', '上涨趋势', '下跌趋势'),
	'choose_sort'		=>	array('升序', '降序'),
	'plan_type'			=>	array('加仓', '减仓'),
	'plan_price_type'	=>	array('≥', '≤'),
	'plan_status'		=>	array(
								array('未执行', '挂单中', '待减仓', '已执行'),
								array('未执行', '挂单中', '待加仓', '已执行')
							),
	'id_format'			=>	array(
								'order'		=>	'C%03d',
								'order_list'=>	'L%04d',
								'plan'		=>	'P%04d'
							),
	'order_status'		=>	array('进行中', '已完成', '已取消'),
	'order_position_side'=>	array(
								'LONG'		=>	'做多',
								'SHORT'		=>	'做空',
								'LONG-BUY'	=>	'开多',
								'SHORT-SELL'=>	'开空',
								'SHORT-BUY'	=>	'平空',
								'LONG-SELL'	=>	'平多'
							),
	'order_list_status'	=>	array(
								0	=>	'新订单',
								4	=>	'部分成交',
								5	=>	'全部成交',
								6	=>	'部分成交已撤单',
								7	=>	'已撤单',
								8	=>	'过期订单'
							),
	'opt_condition'		=>	array(
								0	=>	'资金费',
								1	=>	'强平',
								2	=>	'止损',
								3	=>	'浮盈',
								4	=>	'减仓',
								5	=>	'止盈',
								6	=>	'计划',
								7	=>	'自动',
								10	=>	'手动'
							)
);
wicker_system_init::init();
class wicker_system_init{
	public static function init(){
		global $c,$argv;
		@error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
		@set_time_limit(60);
		@header('Content-Type: text/html; charset=utf-8');
		self::slashes_gpcf($_GET);
		self::slashes_gpcf($_POST);
		self::slashes_gpcf($_COOKIE);
		self::slashes_gpcf($_FILES);
		phpversion()<'5.3.0' && set_magic_quotes_runtime(0);
		date_default_timezone_set('PRC');
		spl_autoload_register('self::class_auto_load');
		include($c['root_path'].'/inc/config.php');
		!$c['binance'] && exit;
		if(PHP_SAPI!='cli'){
			@ini_set('session.name', 'PHPSESSID_'.$c['login_user'][0]);
			@session_start();
		}
		$c['config']=wicker::get_config();
		$c['market']=wicker::get_market();
		$c['binance']['symbol'] && $c['market']['symbol']=$c['binance']['symbol'];
		!@in_array($_SESSION['Binance']['Symbol'], $c['market']['symbol']) && $_SESSION['Binance']['Symbol']=$c['market']['symbol'][0];
		!@in_array($_SESSION['Binance']['Interval'], $c['binance']['kline_interval']) && $_SESSION['Binance']['Interval']=$c['binance']['kline_interval'][0];
	}
	
	private static function class_auto_load($class_name){
		global $c;
		$file=$c['root_path'].'/inc/class/'.$class_name.'.class.php';
		@is_file($file) && include($file);
	}
	
	private static function slashes_gpcf(&$ary){
		foreach($ary as $k=>$v){
			if(is_array($v)){
				self::slashes_gpcf($ary[$k]);
			}else{
				$ary[$k]=trim($ary[$k]);
				!get_magic_quotes_gpc() && $ary[$k]=addslashes($ary[$k]);
			}
		}
	}
}



