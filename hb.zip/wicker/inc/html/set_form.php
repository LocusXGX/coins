<?php !isset($c) && exit;?>
<div class="pop_form">
	<form class="set_form">
		<div class="t">设置【<font class="symbol"></font>】【<font class="position_side"></font>】<span>X</span></div>
		<div class="r_con_form">
			<div class="form_contents">
				<div class="rows">
					<label>止盈设置</label>
					<div class="input">
						<div class="item"><?=wicker::form_select(str::str_code($c['binance']['percent_list'], 'sprintf', array('%01.2f'), 0), 'set_stop_win_percent', '', 1, '--止盈%--', '', '', '', '', 0, '', '%');?></div>
						<div class="item"><?=wicker::form_select($c['binance']['price_list'], 'set_stop_win_price', '', 1, '--止盈U--', '', '', '', '', 0, '', 'U');?></div>
						<div class="item"><input type="text" name="set_stop_win_ticker_price" value="" placeholder="止盈价格" /></div>
						<div><a href="javascript:void(0);" rel="set_cost_close">保本平仓</a></div>
					</div>
					<div class="clear"></div>
				</div>
				<div class="rows">
					<label>浮盈设置</label>
					<div class="input">
						<div class="item"><?=wicker::form_select(str::str_code($c['binance']['percent_list'], 'sprintf', array('%01.2f'), 0), 'set_float_win_percent', '', 1, '--浮盈%--', '', '', '', '', 0, '', '%');?></div>
						<div class="item"><?=wicker::form_select($c['binance']['price_list'], 'set_float_win_price', '', 1, '--浮盈U--', '', '', '', '', 0, '', 'U');?></div>
						<div class="item"><input type="text" name="set_float_win_ticker_price" value="" placeholder="浮盈价格" /></div>
					</div>
					<div class="clear"></div>
				</div>
				<div class="rows">
					<label>止损设置</label>
					<div class="input">
						<div class="item"><?=wicker::form_select(str::str_code($c['binance']['percent_list'], 'sprintf', array('%01.2f'), 0), 'set_stop_loss_percent', '', 1, '--止损%--', '', '', '', '', 0, '', '%');?></div>
						<div class="item"><?=wicker::form_select($c['binance']['price_list'], 'set_stop_loss_price', '', 1, '--止损U--', '', '', '', '', 0, '', 'U');?></div>
						<div class="item"><input type="text" name="set_stop_loss_ticker_price" value="" placeholder="止损价格" /></div>
					</div>
					<div class="clear"></div>
				</div>
				<div class="rows">
					<label>保本持仓</label>
					<div class="input">
						<div class="item"><?=wicker::form_select($c['binance']['default_set_main']['volume_operation'], 'set_cut_stock', '', 1, '--金额--', '', '', '', '', 0, '', 'U');?></div>
						<div class="item"><input type="checkbox" name="set_reset_plan" id="set_reset_plan" value="1" /> <label for="set_reset_plan">计划重置</label></div>
					</div>
					<div class="clear"></div>
				</div>
			</div>
			<div class="rows">
				<label></label>
				<div class="input"><input type="submit" class="btn_ok" name="submit_button" value="保 存" /></div>
				<div class="clear"></div>
			</div>
		</div>
		<input type="hidden" name="OrdersId" value="" />
		<input type="hidden" name="do_action" value="set_config" />
	</form>
</div>