<?php
!isset($c) && exit;
ob_start();
?>
<table width="100%" align="center" border="0" cellpadding="5" cellspacing="0" class="r_con_table">
	<thead>
		<tr>
			<td width="12%" nowrap="nowrap">币种</td>
			<td width="15%" nowrap="nowrap">价格</td>
			<td width="20%" nowrap="nowrap"><?=$c['choose_reference'][$p_reference];?></td>
		</tr>
	</thead>
	<tbody>
		<?php
		$data=array();
		foreach($c['market']['symbol'] as $v){
			$price=sprintf($c['market']['price_precision'][$v], $c['market']['ticker_price'][$v]);
			if($price<=0){continue;}
			if(in_array($p_reference, array(0,1,2,3,4))){
				$kline_row=db::get_one("{$c['db_cfg']['market_db']}.{$v}_kline_{$_SESSION['Binance']['Interval']}", 'IsUpdate=1', '*', 'KlineId desc');
				if(($p_reference==2 && $price<$kline_row['BollMB']) || ($p_reference==4 && $price>$kline_row['BollMB'])){continue;}
				if(in_array($kline_reference, array('MA5','MA10','BollMB'))){
					$rate=$sort=abs($kline_row[$kline_reference]-$price)/$kline_row[$kline_reference];
				}elseif($kline_reference=='BollUB'){
					$rate=($kline_row['BollUB']-$price)/$kline_row['BollUB'];
					$sort=$rate<0?abs($rate)+1000:$rate;
				}else{
					$rate=($price-$kline_row['BollLB'])/$kline_row['BollLB'];
					$sort=$rate<0?abs($rate)+1000:$rate;
				}
				$data[$v]=array(
					'price'	=>	$price,
					'value'	=>	sprintf('%01.3f', $rate*100),
					'sort'	=>	$sort
				);
			}elseif(in_array($p_reference, array(5,6))){
				$kline_row=db::get_limit("{$c['db_cfg']['market_db']}.{$v}_kline_{$_SESSION['Binance']['Interval']}", 'IsUpdate=1', '*', 'KlineId desc', 0, 2);
				if(($p_reference==5 && $kline_row[0]['Rise']+$kline_row[1]['Rise']<=0) || ($p_reference==6 && $kline_row[0]['Rise']+$kline_row[1]['Rise']>=0)){continue;}
				$rise=$kline_row[0]['Rise']+$kline_row[1]['Rise'];
				$data[$v]=array(
					'price'	=>	$price,
					'value'	=>	sprintf('%01.2f', $rise*100),
					'sort'	=>	abs($rise)
				);
			}elseif(in_array($p_reference, array(7,8))){
				$kline_row=db::get_limit("{$c['db_cfg']['market_db']}.{$v}_kline_{$_SESSION['Binance']['Interval']}", 'IsUpdate=1', '*', 'KlineId desc', 0, 100);
				$kline_count=0;
				foreach($kline_row as $k1=>$v1){
					if(($p_reference==7 && $v1['MA5']<$v1['MA10']) || ($p_reference==8 && $v1['MA5']>$v1['MA10'])){break;}
					$kline_count++;
				}
				if($kline_count==0 || $kline_count>12){continue;}
				$data[$v]=array(
					'price'	=>	$price,
					'value'	=>	"（{$kline_count}）".sprintf('%01.3f', abs($kline_row[0]['MA5']-$price)/$kline_row[0]['MA5']*100),
					'sort'	=>	abs($kline_row[0]['MA5']-$price)/$kline_row[0]['MA5']
				);
			}
		}
		array_multisort(array_column($data, 'sort'), $p_sort==0?SORT_ASC:SORT_DESC, $data);
		$data=array_slice($data, 0, 50);
		foreach($data as $k=>$v){	
		?>
			<tr>
				<td nowrap="nowrap"><a href="javascript:void(0);" rel="<?=$k;?>" class="<?=$_SESSION['Binance']['Symbol']==$v?'fc_red':'fc_green';?> set_symbol"><?=strtoupper($k);?></a></td>
				<td nowrap="nowrap"><?=$v['price'];?></td>
				<td nowrap="nowrap"><?=$v['value'];?>%</td>
			</tr>
		<?php }?>
	</tbody>
</table>
<?php
$choose_list=ob_get_contents();
ob_end_clean();
return $choose_list;
?>