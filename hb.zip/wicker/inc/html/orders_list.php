<?php
!isset($c) && exit;
ob_start();
$orders_row=db::get_one('orders', "OrdersId='$p_OrdersId'");
?>
<div class="pop_form min_top">
	<div class="orders_list">
		<div class="t">订单明细【<?=strtoupper($orders_row['Symbol']);?>】【<?=$c['order_position_side'][$orders_row['PositionSide']];?>】<span>X</span></div>
		<div class="table">
			<table width="100%" align="center" border="0" cellpadding="5" cellspacing="0" class="r_con_table">
				<thead>
					<tr>
						<td width="5%" nowrap="nowrap">序号</td>
						<td width="8%" nowrap="nowrap">单号</td>
						<td width="8%" nowrap="nowrap">方向</td>
						<td width="10%" nowrap="nowrap">价格</td>
						<td width="10%" nowrap="nowrap">距离现价</td>
						<td width="10%" nowrap="nowrap">金额</td>
						<td width="10%" nowrap="nowrap">盈亏</td>
						<td width="10%" nowrap="nowrap">手续费</td>
						<td width="15%" nowrap="nowrap">类型</td>
						<td width="15%" nowrap="nowrap">状态</td>
						<td width="15%" nowrap="nowrap">时间</td>
					</tr>
				</thead>
				<tbody>
					<?php
					$symbol_config=json_decode($orders_row['SymbolConfig'], true);
					$table=$orders_row['OrderStatus']==0?'orders_list':'orders_list_history';
					$order_by='CompletedTime desc,ListId desc';
					$w=array(
						"OrdersId='$p_OrdersId' and OrderStatus<5",
						"OrdersId='$p_OrdersId' and OrderStatus in(5,6) and not (OptCondition=6 and PlanIsBatAdd=1)",
						"OrdersId='$p_OrdersId' and OrderStatus in(5,6) and OptCondition=6 and PlanIsBatAdd=1"
					);
					$orders_list_tmp_row=array(
						db::get_all($table, $w[0], '*', 'PendingPrice desc,'.$order_by),
						db::get_all($table, $w[1], '*', $order_by),
						db::get_limit($table, $w[2], '*', $order_by, 0, 200)
					);
					$orders_list_row=array();
					foreach($orders_list_tmp_row as $v){
						$v && $orders_list_row[]=$v;
					}
					foreach($orders_list_row as $k=>$v){
						foreach($v as $k1=>$v1){
							$trade_price=$v1['OrderStatus']>=5?$v1['TradePrice']:$v1['PendingPrice'];
							$distance=@floatval(($c['market']['ticker_price'][$orders_row['Symbol']]-$trade_price)/$trade_price*100);
							$is_open_order=($v1['PositionSide']=='LONG' && $v1['Side']=='BUY') || ($v1['PositionSide']=='SHORT' && $v1['Side']=='SELL');
							$z_PlanId=$z_PlanPrice='';
							if($v1['PlanId']){
								$z_PlanId=sprintf("（{$c['id_format']['plan']}）", $v1['PlanId']);
								if($v1['PlanPriceTxt']==''){
									$z_PlanPrice=$c['plan_price_type'][$v1['PlanPriceType']].sprintf($symbol_config['price_precision'], $v1['PlanPrice']);
								}else{
									$z_PlanPrice=str_replace('_', '', str_replace(array_keys($c['kline_indicator']), array_values($c['kline_indicator']), $v1['PlanPriceTxt']));
								}
								$z_PlanPrice="（{$z_PlanPrice}）";
							}
							$orders_list_row[$k][$k1]=array_merge($orders_list_row[$k][$k1], array(
									'z_ListId'			=>	sprintf($c['id_format']['order_list'], $v1['ListId']),
									'z_PositionSide'	=>	str::str_color($c['order_position_side'][$v1['PositionSide'].'-'.$v1['Side']], $is_open_order?0:1),
									'z_TradePrice'		=>	sprintf($symbol_config['price_precision'], $trade_price),
									'z_Distance'		=>	str::str_color(($distance>=0?'+':'').sprintf('%01.2f', $distance).'%', $distance>=0?1:0),
									'z_PendingTotal'	=>	round(($v1['OrderStatus']>=5?$v1['TradePrice']:$v1['PendingPrice'])*$v1['Volume']/$c['binance']['price_modulo'])*$c['binance']['price_modulo'],
									'z_TradeTurnover'	=>	$v1['TradeTurnover']>0?intval($v1['TradeTurnover']):$c['n_a'],
									'z_Profit'			=>	(!$is_open_order && in_array($v1['OrderStatus'], array(5,6)))?str::str_color(sprintf('%01.5f', $v1['Profit']), $v1['Profit']>=0?1:0):$c['n_a'],
									'z_Fee'				=>	$v1['Fee']!=0?str::str_color(sprintf('%01.5f', $v1['Fee']), $v1['Fee']>0?1:0):$c['n_a'],
									'z_OptCondition'	=>	str::str_color($c['opt_condition'][$v1['OptCondition']], $v1['OptCondition']),
									'z_OrderStatus'		=>	str::str_color($c['order_list_status'][$v1['OrderStatus']], $v1['OrderStatus']),
									'z_PlanId'			=>	$z_PlanId,
									'z_PlanPrice'		=>	$z_PlanPrice,
									'z_PlanFrom'		=>	$v1['PlanFromPlanId']?sprintf("（{$c['id_format']['plan']}）", $v1['PlanFromPlanId']):($v1['PlanFromListId']?sprintf("（{$c['id_format']['plan']}）", $v1['PlanFromListId']):''),
									'z_CompletedTime'	=>	date('m-d H:i:s', $v1['CompletedTime'])
								)
							);
							$v1['OptCondition']==0 && $orders_list_row[$k][$k1]=array_merge($orders_list_row[$k][$k1], array(
									'z_PositionSide'	=>	$c['n_a'],
									'z_TradePrice'		=>	$c['n_a'],
									'z_Distance'		=>	$c['n_a'],
									'z_PendingTotal'	=>	$c['n_a'],
									'z_TradeTurnover'	=>	$c['n_a'],
									'z_Profit'			=>	str::str_color(sprintf('%01.5f', $v1['Profit']), $v1['Profit']>=0?1:0),
									'z_Fee'				=>	$c['n_a'],
									'z_OrderStatus'		=>	$c['n_a'],
									'z_PlanId'			=>	'',
									'z_PlanPrice'		=>	'',
									'z_PlanFrom'		=>	''
								)
							);
						}
					}
					$group=0;
					$number=1;
					foreach($orders_list_row as $k=>$v){
						foreach($v as $k1=>$v1){
							if($group!=$k && $number>1){
								$class='orders_list_group';
								$group=$k;
							}else{
								$class='';
							}
						?>
						<tr class="<?=$class;?>">
							<td nowrap="nowrap"><?=$number++;?></td>
							<td nowrap="nowrap"><?=$v1['z_ListId'];?></td>
							<td nowrap="nowrap"><?=$v1['z_PositionSide'];?></td>
							<td nowrap="nowrap"><?=$v1['z_TradePrice'];?></td>
							<td nowrap="nowrap"><?=$v1['z_Distance'];?></td>
							<td nowrap="nowrap"><?=$v1['z_PendingTotal'].(($v1['TradeVolume']>0 && sprintf('%01.5f', $v1['Volume'])!=sprintf('%01.5f', $v1['TradeVolume']))?"（{$v1['z_TradeTurnover']}）":'');?></td>
							<td nowrap="nowrap"><?=$v1['z_Profit'];?></td>
							<td nowrap="nowrap"><?=$v1['z_Fee'];?></td>
							<td nowrap="nowrap"><?=$v1['z_OptCondition'].$v1['z_PlanId'].$v1['z_PlanFrom'].$v1['z_PlanPrice'];?></td>
							<td nowrap="nowrap"><?=$v1['z_OrderStatus'];?><?php if($v1['OrderStatus']<5){?>（<a href="javascript:void(0);" class="cancel_list_orders" rel="<?=$v1['ListId'];?>">撤单</a>）<?php }?></td>
							<td nowrap="nowrap"><?=$v1['z_CompletedTime'];?></td>
						</tr>
						<?php
						}
					}
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php
$orders_list=ob_get_contents();
ob_end_clean();
return $orders_list;
?>