<?php !isset($c) && exit;?>
<form class="choose_form">
	<div class="t">
		<div class="choose_item">
			<div><?=wicker::form_select($c['binance']['kline_interval'], 'interval', '0', 1, '--周期--');?></div>
			<div><?=wicker::form_select($c['choose_reference'], 'reference', '0', 1, '--指标--');?></div>
			<div><?=wicker::form_select($c['choose_sort'], 'sort', '0', 1, '--排序--');?></div>
			<div><input type="submit" class="btn_ok" name="submit_button" value="筛选" /></div>
		</div>
		<span>X</span>
	</div>
	<div class="choose_list">
		<table width="100%" align="center" border="0" cellpadding="5" cellspacing="0" class="r_con_table">
			<thead>
				<tr>
					<td width="15%" nowrap="nowrap">币种</td>
					<td width="20%" nowrap="nowrap">当前价格</td>
					<td width="25%" nowrap="nowrap">指标价格</td>
					<td width="20%" nowrap="nowrap">距离</td>
					<td width="20%" nowrap="nowrap">涨跌幅</td>
				</tr>
			</thead>
		</table>
	</div>
	<input type="hidden" name="do_action" value="choose_list" />
</form>