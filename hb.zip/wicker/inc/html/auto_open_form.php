<?php !isset($c) && exit;?>
<div class="pop_form">
	<form class="auto_open_form">
		<div class="t">自动开仓【<font class="symbol"></font>】<span>X</span></div>
		<div class="r_con_form">
			<div class="form_contents">
				<div class="rows">
					<label>开仓设置</label>
					<div class="input">
						<div class="item"><?=wicker::form_select(array_slice($c['order_position_side'], 0, 2, true), 'auto_open_position_side', '', 1, '--方向--');?></div>
						<div class="item"><?=wicker::form_select($c['binance']['default_set_main']['volume_operation'], 'auto_open_amout', '', 1, '--金额--', '', '', '', '', 0, '', 'U');?></div>
					</div>
					<div class="clear"></div>
				</div>
				<div class="rows">
					<label>开仓价格</label>
					<div class="input">
						<div class="item"><?=wicker::form_select(array('自定义', '按指标'), 'auto_open_price_type', '1', 1, '--价格--');?></div>
						<div class="item price_type_0"><input type="text" name="auto_open_price" value="" placeholder="价格" /></div>
						<div class="item price_type_1"><?=wicker::form_select($c['binance']['kline_interval'], 'auto_open_kline_interval', $c['binance']['kline_interval'][0], 1, '--周期--', '', '', '', '', 0);?></div>
						<div class="item price_type_1"><?=wicker::form_select($c['kline_indicator'], 'auto_open_kline_indicator', 'MA5', 1, '--指标--');?></div>
						<div class="item price_type_1"><?=wicker::form_select(wicker::percent_list_reverse(), 'auto_open_kline_price_offset', '', 1, '--价格偏移--', '', '', '', '', 1, '', '%');?></div>
					</div>
					<div class="clear"></div>
				</div>
				<div class="rows">
					<label>止盈止损</label>
					<div class="input">
						<div class="item"><?=wicker::form_select(str::str_code($c['binance']['percent_list'], 'sprintf', array('%01.2f'), 0), 'auto_open_stop_win_percent', '', 1, '--止盈%--', '', '', '', '', 0, '', '%');?></div>
						<div class="item"><?=wicker::form_select(str::str_code($c['binance']['percent_list'], 'sprintf', array('%01.2f'), 0), 'auto_open_stop_loss_percent', '', 1, '--止损%--', '', '', '', '', 0, '', '%');?></div>
					</div>
					<div class="clear"></div>
				</div>
				<div class="rows">
					<label>其他选项</label>
					<div class="input">
						<div class="item"><input type="checkbox" name="auto_open_set_plan" id="auto_open_set_plan" value="1" /> <label for="auto_open_set_plan">设置计划</label></div>
						<div class="item"><input type="checkbox" name="auto_open_is_loop" id="auto_open_is_loop" value="1" /> <label for="auto_open_is_loop">重复执行</label></div>
					</div>
					<div class="clear"></div>
				</div>
			</div>
			<div class="rows">
				<label></label>
				<div class="input"><input type="submit" class="btn_ok" name="submit_button" value="保 存" /></div>
				<div class="clear"></div>
			</div>
		</div>
		<input type="hidden" name="do_action" value="auto_open" />
	</form>
</div>