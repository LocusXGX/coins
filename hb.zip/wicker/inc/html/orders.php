<?php
!isset($c) && exit;
ob_start();
?>
<div>
	<div class="table">
		<table width="100%" align="center" border="0" cellpadding="5" cellspacing="0" class="r_con_table">
			<thead>
				<tr>
					<td width="10%" nowrap="nowrap">单号</td>
					<td width="10%" nowrap="nowrap">币种</td>
					<?php if($p_screen_width<1024){?>
						<td width="20%" nowrap="nowrap">盈亏</td>
						<td width="10%" nowrap="nowrap">金额</td>
						<td width="10%" nowrap="nowrap">保本价</td>
					<?php }else{?>
						<td width="10%" nowrap="nowrap">金额</td>
						<td width="10%" nowrap="nowrap">保本价</td>
						<td width="20%" nowrap="nowrap">盈亏</td>
					<?php }?>
					<td width="15%" nowrap="nowrap">止盈止损</td>
					<td width="15%" nowrap="nowrap">状态</td>
					<td width="15%" nowrap="nowrap">操作</td>
					<td width="15%" nowrap="nowrap">时间</td>
				</tr>
			</thead>
			<tbody>
				<?php
				$orders_row=db::get_limit_page('orders', "OrderStatus<=1 or (OrderStatus=2 and AccTime+300>{$c['time']})", '*', 'if(OrderStatus=0, 100000, OrdersId) desc,if(OpenVolume=0, 0, 1) desc,OrdersId desc', $_SESSION['Binance']['page'], $p_screen_width<1000?5:8);
				$_SESSION['Binance']['page']>$orders_row[3] && $_SESSION['Binance']['page']=1;
				foreach($orders_row[0] as $k=>$v){
					$profit_rate=$profit_usdt=$c['n_a'];
					$symbol_config=json_decode($v['SymbolConfig'], true);
					$set_config=json_decode($v['SetConfig'], true);
					$win_config=$loss_config=array();
					$set_config['set_stop_win_percent']>0 && $win_config[]=$set_config['set_stop_win_percent'].'%';
					$set_config['set_stop_win_price']>0 && $win_config[]=$set_config['set_stop_win_price'].'U';
					$set_config['set_stop_win_ticker_price']>0 && $win_config[]='$'.$set_config['set_stop_win_ticker_price'];
					$set_config['set_stop_loss_percent']>0 && $loss_config[]=$set_config['set_stop_loss_percent'].'%';
					$set_config['set_stop_loss_price']>0 && $loss_config[]=$set_config['set_stop_loss_price'].'U';
					$set_config['set_stop_loss_ticker_price']>0 && $loss_config[]='$'.$set_config['set_stop_loss_ticker_price'];
					$config=implode('<font class="fc_green">/</font>', array_filter(array($win_config?implode('-', $win_config):$c['n_a'], $loss_config?implode('-', $loss_config):$c['n_a'])));
					$operation='';
					if($v['OrderStatus']==0){
						$profit_usdt=sprintf('%01.2f', $v['FloatProfit']);
						$orders_volume=abs($v['OpenVolume']-$v['CloseVolume']);
						$share_price=str::number_format(@sprintf('%01.10f', ($v['Profit']+$v['Fee'])/$orders_volume));
						$cost_price=str::number_format(sprintf($symbol_config['price_precision'], $v['PositionSide']=='LONG'?$v['OpenPrice']-$share_price:$v['OpenPrice']+$share_price));
						$profit_rate=@sprintf('%01.2f', ($v['PositionSide']=='LONG'?($c['market']['ticker_price'][$v['Symbol']]-$cost_price):($cost_price-$c['market']['ticker_price'][$v['Symbol']]))/$cost_price*100);
						$clear_opt_side='【'.strtoupper($v['Symbol']).'】【'.$c['order_position_side'][$v['PositionSide']].'】';
						$operation="
							<a href='javascript:void(0);' rel='{$v['OrdersId']}' class='set'>设</a>
							<a href='javascript:void(0);' rel='{$v['OrdersId']}' class='plan'>计</a>
							<a href='javascript:void(0);' rel='do_action=cancel_orders&OrdersId={$v['OrdersId']}' class='cancel_orders'>撤</a>
							<a href='javascript:void(0);' rel='do_action=open_close_position&position_type=close&volume=10000000&OrdersId={$v['OrdersId']}' class='clear_orders' clear_opt_side='$clear_opt_side'>清</a>
							<a href='javascript:void(0);' rel='{$v['OrdersId']}' class='set_confirm'>确</a>
						";
						$p_screen_width<1024 && $operation=str_replace(array('设','计','撤','清','确'), array('设置','计划','撤单','清仓','确认'), $operation);
					}elseif($v['OrderStatus']==1){
						$profit_usdt=sprintf('%01.2f', $v['FloatProfit']);
						$profit_rate=@sprintf('%01.2f', $profit_usdt/($v['CostPrice']*$v['OpenVolume'])*100);
					}
					$cost_price_class=($v['OrderStatus']==0 && ($set_config['set_float_win_percent']>0 || $set_config['set_float_win_price']>0))?'fc_green':'';
					$orders_row[0][$k]=array_merge($orders_row[0][$k], array(
							'z_OrdersId'	=>	sprintf('<a href="javascript:void(0);" class="fc_green get_orders_list">%s</a>', sprintf($c['id_format']['order'], $v['OrdersId'])),
							'z_Symbol'		=>	sprintf('<a href="javascript:void(0);" rel="%s" class="%s set_symbol">%s</a>', $v['Symbol'], $v['PositionSide']=='LONG'?'fc_green':'fc_red', strtoupper($v['Symbol'])),
							'z_Volume'		=>	str::number_format(($v['OrderStatus']==0?abs($v['OpenVolume']-$v['CloseVolume']):$v['OpenVolume'])),
							'z_Amount'		=>	round(($v['OrderStatus']==0?abs($v['OpenVolume']-$v['CloseVolume']):$v['OpenVolume'])*$v['CostPrice']/$c['binance']['price_modulo'])*$c['binance']['price_modulo'],
							'z_CostPrice'	=>	"<font class='$cost_price_class'>".str::number_format(sprintf($symbol_config['price_precision'], $v['CostPrice'])).'</font>',
							'z_Profit'		=>	($v['OpenVolume']>0 || $v['CloseVolume']>0)?str::str_color("{$profit_usdt}（{$profit_rate}%）", $profit_usdt>=0?1:0):$c['n_a'],
							'z_Config'		=>	$config,
							'z_OrderStatus'	=>	str::str_color($c['order_status'][$v['OrderStatus']], $v['OrderStatus']),
							'z_PlanRunCount'=>	$v['PlanRunCountAdd']+$v['PlanRunCountCut'],
							'z_Operation'	=>	$operation,
							'z_AccTime'		=>	date('m-d H:i:s', $v['AccTime'])
						)
					);
				}
				foreach($orders_row[0] as $v){
				?>
					<tr OrderSign="<?=md5(implode($v));?>" OrdersId="<?=$v['OrdersId'];?>">
						<td nowrap="nowrap"><?=$v['z_OrdersId'];?></td>
						<td nowrap="nowrap"><?=$v['z_Symbol'];?></td>
						<?php if($p_screen_width<1024){?>
							<td nowrap="nowrap"><?=$v['z_Profit'];?></td>
							<td nowrap="nowrap"><?=$v['z_Amount'];?></td>
							<td nowrap="nowrap"><?=$v['z_CostPrice'].($v['z_PlanRunCount']?"（{$v['z_PlanRunCount']}）":'');?></td>
						<?php }else{?>
							<td nowrap="nowrap"><?=$v['z_Amount'];?></td>
							<td nowrap="nowrap"><?=$v['z_CostPrice'].($v['z_PlanRunCount']?"（{$v['z_PlanRunCount']}）":'');?></td>
							<td nowrap="nowrap"><?=$v['z_Profit'];?></td>
						<?php }?>
						<td nowrap="nowrap"><?=$v['z_Config'];?></td>
						<td nowrap="nowrap"><?=$v['z_OrderStatus'];?></td>
						<td nowrap="nowrap"><?=$v['z_Operation'];?></td>
						<td nowrap="nowrap"><?=$v['z_AccTime'];?></td>
					</tr>
				<?php }?>
			</tbody>
		</table>
	</div>
	<div class="turn_page" total_page="<?=$orders_row[3];?>"><?=wicker::turn_page($orders_row[1], $orders_row[2], $orders_row[3], '<<', '>>');?></div>
</div>
<?php
$orders=ob_get_contents();
ob_end_clean();
return $orders;
?>