<?php
!isset($c) && exit;
ob_start();
?>
<div>
	<table width="100%" align="center" border="0" cellpadding="5" cellspacing="0" class="r_con_table">
		<thead>
			<tr>
				<td width="5%" nowrap="nowrap" class="center">操作</td>
				<td width="9%" nowrap="nowrap">计划</td>
				<td width="9%" nowrap="nowrap">类型</td>
				<td width="12%" nowrap="nowrap">价格</td>
				<td width="12%" nowrap="nowrap">金额</td>
				<td width="9%" nowrap="nowrap">重复执行</td>
				<td width="9%" nowrap="nowrap">执行次数</td>
				<td width="9%" nowrap="nowrap">状态</td>
				<td width="15%" nowrap="nowrap">时间</td>
			</tr>
		</thead>
		<tbody>
			<?php
			$plan_row=array();
			$p_plan_list_orders_id=(int)$p_plan_list_orders_id;
			$orders_row=db::get_one('orders', "OrdersId='$p_plan_list_orders_id' and OrderStatus=0", '*', 'OrdersId desc');
			if($orders_row){
				$symbol_config=json_decode($orders_row['SymbolConfig'], true);
				$order_by=$orders_row['PositionSide']=='LONG'?'Price desc':'Price asc';
				$plan_row=db::get_all('plan', "OrdersId='{$orders_row['OrdersId']}' and not (Status=3 and IsBatAdd=1)", '*', "if(FromPlanId=0, IsLoop, 1) asc,PlanType desc,$order_by,PlanId asc");
			}
			foreach($plan_row as $k=>$v){
				if($v['VolumeType']==0){
					$volume=(round($v['Volume']/$c['binance']['price_modulo'])*$c['binance']['price_modulo']).'U';
				}elseif($v['VolumeType']==1){
					$volume=(round($v['Volume']*$v['Price']/$c['binance']['price_modulo'])*$c['binance']['price_modulo']).'U';
				}else{
					$volume=str::number_format($v['Volume']*100).'%';
				}
				if($v['PriceTxt']==''){
					$price=$c['plan_price_type'][$v['PriceType']].sprintf($symbol_config['price_precision'], $v['Price']);
				}else{
					$price=str_replace('_', '', str_replace(array_keys($c['kline_indicator']), array_values($c['kline_indicator']), $v['PriceTxt']));
				}
			?>
				<tr class="<?=$v['Status']==3?'fc_gory':'';?>" PlanSign="<?=md5(implode($v));?>">
					<td nowrap="nowrap" class="center"><a href="javascript:void(0);" class="plan_del" PlanId="<?=$v['PlanId'];?>">X</a></td>
					<td nowrap="nowrap"><?=sprintf($c['id_format']['plan'], $v['PlanId']);?></td>
					<td nowrap="nowrap"><?=str::str_color($c['plan_type'][$v['PlanType']], $v['PlanType']);?><?=$v['FromPlanId']>0?'（'.sprintf('P%04d', $v['FromPlanId']).'）':'';?><?=$v['FromListId']>0?'（'.sprintf('L%04d', $v['FromListId']).'）':'';?></td>
					<td nowrap="nowrap"><?=$price;?></td>
					<td nowrap="nowrap"><?=$volume;?><?php if($v['ClosePercent']>0){;?>（<?=$v['ClosePercent']>0?str::number_format($v['ClosePercent']).'%':'--';?>）<?php }?></td>
					<td nowrap="nowrap"><?=$v['FromPlanId']==0?str::str_color($c['n_y'][$v['IsLoop']], $v['IsLoop']):$c['n_a'];?></td>
					<td nowrap="nowrap"><?=$v['IsLoop']?$v['RunCount'].'次':$c['n_a'];?></td>
					<td nowrap="nowrap"><?=str::str_color($c['plan_status'][$v['PlanType']][$v['Status']], $v['Status']);?></td>
					<td nowrap="nowrap"><?=date('m-d H:i:s', $v['Status']==3?$v['CompletedTime']:$v['AccTime']);?></td>
				</tr>
			<?php }?>
		</tbody>
	</table>
</div>
<?php
$plan_list=ob_get_contents();
ob_end_clean();
return array($plan_list, strtoupper($orders_row['Symbol']), $c['order_position_side'][$orders_row['PositionSide']]);
?>