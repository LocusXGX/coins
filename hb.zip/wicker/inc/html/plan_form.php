<?php !isset($c) && exit;?>
<div class="pop_form min_top">
	<form class="plan_form w_1200">
		<div class="t">计划【<font class="symbol"></font>】【<font class="position_side"></font>】<span>X</span></div>
		<div class="r_con_form">
			<div class="rows">
				<div class="input plan_item">
					<div><?=wicker::form_select($c['plan_type'], 'plan_type', '', 1, '--类型--');?></div>
					<div><?=wicker::form_select(array('自定义', '按指标'), 'price_type', '', 1, '--价格--');?></div>
					<div class="price_type_0"><input name="price" type="text" class="form_input" value="" placeholder="价格" /></div>
					<div class="price_type_1"><?=wicker::form_select($c['binance']['kline_interval'], 'price_txt_interval', '', 1, '--周期--', '', '', '', '', 0);?></div>
					<div class="price_type_1"><?=wicker::form_select($c['kline_indicator'], 'price_txt_indicator', '', 1, '--指标--');?></div>
					<div><?=wicker::form_select(wicker::percent_list_reverse(), 'price_offset', '', 1, '--价格偏移--', '', '', '', '', 1, '', '%');?></div>
					<div><?=wicker::form_select($c['binance']['default_set_main']['volume_operation'], 'volume', '', 1, '--金额--', '', '', '', '', 0, '', 'U');?></div>
					<div><?=wicker::form_select(str::str_code($c['binance']['percent_list'], 'sprintf', array('%01.2f'), 0), 'close_percent', '', 1, '--赚差价--', '', '', '', '', 0, '', '%');?></div>
					<div><?=wicker::form_select($c['n_y'], 'is_loop', '', 1, '--重复执行--');?></div>
					<div><input type="submit" class="btn_ok" name="submit_button" value="保 存" /></div>
					<div class="quick"><a href="javascript:void(0);" rel="plan_quick_set">设置</a><a href="javascript:void(0);" rel="plan_clear">清空</a><a href="javascript:void(0);" rel="1h_BollUB">1h上轨</a><a href="javascript:void(0);" rel="1h_BollMB">1h中轨</a><a href="javascript:void(0);" rel="1h_BollLB">1h下轨</a></div>
					<input type="hidden" name="OrdersId" value="" />
					<input type="hidden" name="do_action" value="plan_add" />
				</div>
				<div class="clear"></div>
			</div>
		</div>
		<div class="plan_list"></div>
	</form>
</div>