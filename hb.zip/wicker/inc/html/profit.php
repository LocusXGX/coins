<?php !isset($c) && exit;?>
<div class="pop_form min_top">
	<form class="profit_form w_1200">
		<div class="t">收益统计<span>X</span></div>
		<div class="profit_chart_box">
			<div><div id="chart_profit"></div></div>
			<div><div id="chart_profit_rate"></div></div>
		</div>
	</form>
</div>