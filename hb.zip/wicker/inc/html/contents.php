<?php !isset($c) && exit;?>
<div class="contents">
	<div class="righter">
		<?php include($c['root_path'].'/inc/html/choose_form.php');?>
		<h1 class="nav">
			<div class="menu coin_list">
				<font><a href="javascript:void(0);"><?=strtoupper($_SESSION['Binance']['Symbol']);?></a></font>
				<div class="list">
					<?php
					foreach((array)$c['market']['symbol'] as $v){
						printf('<a href="javascript:void(0);" rel="%s" class="%s"><font class="dot"></font><font class="symbol_item">%s</font><span class="rise"></span></a>', $v, $_SESSION['Binance']['Symbol']==$v?'fc_red':'', strtoupper($v));
					}
					?>
				</div>
			</div>
			<span>(强平：<?=$c['binance']['close_out']>0?'$'.$c['binance']['close_out']:'∞';?>)</span>
			<div class="link">
				<a href="javascript:void(0);" class="auto_open">自动</a>
				<a href="javascript:void(0);" class="profit">收益</a>
				<a href="?do_action=logout" class="logout">退出</a>
			</div>
		</h1>
		<div class="item logs">
			<div class="logs_l"></div>
			<div class="logs_r"></div>
		</div>
		<h1 class="nav border_top">开仓<a href="javascript:void(0);" class="fr choose">筛选</a></h1>
		<form class="item open_form">
			<div class="r_con_form">
				<div class="rows">
					<span class="input">
						<div class="item">
							<ul class="position_type">
								<li rel="open" class="cur">开</li>
								<li rel="close">平</li>
							</ul>
						</div>
						<div class="item"><?=wicker::form_select($c['binance']['default_set_main']['volume_operation'], 'volume', 0, 1, '--金额--', '', '', '', '', 0, '', 'U');?></div>
						<div class="item"><input type="text" name="place_price" value="" placeholder="价格" /></div>
						<div class="item stop_win"><?=wicker::form_select(str::str_code(array_filter($c['binance']['percent_list'], function($v){return $v>=0.25 && $v<=5;}), 'sprintf', array('%01.2f'), 0), 'stop_win', '', 1, '--赚差价--', '', '', '', '', 0, '', '%');?></div>
						<div class="open_btn">
							<div class="item btn"><input type="button" class="btn_ok long" name="submit_button" value="开多" attr="LONG" /></div>
							<div class="item btn"><input type="button" class="btn_ok short" name="submit_button" value="开空" attr="SHORT" /></div>
						</div>
						<div class="close_btn">
							<div class="item btn"><input type="button" class="btn_ok long" name="submit_button" value="平多" attr="LONG" /></div>
							<div class="item btn"><input type="button" class="btn_ok short" name="submit_button" value="平空" attr="SHORT" /></div>
						</div>
						<div class="clear"></div>
					</span>
					<div class="clear"></div>
				</div>
			</div>
			<input type="hidden" name="position_type" value="open" />
			<input type="hidden" name="position_side" value="" />
			<input type="hidden" name="do_action" value="open_close_position" />
		</form>
		<div class="item orders"></div>
	</div>
	<div class="lefter">
		<h1 class="nav">
			<div class="menu coin_list">
				<font><a href="javascript:void(0);"><?=strtoupper($_SESSION['Binance']['Symbol']);?></a></font>
				<div class="list">
					<?php
					foreach($c['market']['symbol'] as $v){
						printf('<a href="javascript:void(0);" rel="%s" class="%s"><font class="dot"></font><font class="symbol_item">%s</font><span class="rise"></span></a>', $v, $_SESSION['Binance']['Symbol']==$v?'fc_red':'', strtoupper($v));
					}
					?>
				</div>
			</div>
			<div class="interval">
				<?php
				foreach($c['binance']['kline_interval'] as $v){
					printf('<a href="javascript:void(0);" rel="%s" class="%s">%s</a>', $v, $v==$_SESSION['Binance']['Interval']?'fc_red':'', $v);
				}
				?>
			</div>
		</h1>
		<div class="kline_box"><div id="kline"></div></div>
	</div>
	<div class="clear"></div>
</div>