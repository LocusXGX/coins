<?php !isset($c) && exit;?>
<form class="login_form">
	<span class="input"><input name="account" type="text" value="" placeholder="用户名" /></span>
	<span class="input"><input name="password" type="password" value="" placeholder="密码" /></span>
	<span class="submit"><input type="submit" value="" /></span>
	<input type="hidden" name="do_action" value="login" />
</form>