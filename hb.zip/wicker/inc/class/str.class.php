<?php
class str{
	public static function str_code($data, $fun='htmlspecialchars', $params=array(), $data_is_first=1){	//文本编码
		if(!is_array($data)){
			return call_user_func_array($fun, $data_is_first?array_merge(array($data), $params):array_merge($params, array($data)));
		}
		$new_data=array();
		foreach((array)$data as $k=>$v){
			if(is_array($v)){
				$new_data[$k]=str::str_code($v, $fun, $params, $data_is_first);
			}else{
				$new_data[$k]=call_user_func_array($fun, $data_is_first?array_merge(array($v), $params):array_merge($params, array($v)));
			}
		}
		return $new_data;
	}
	
	public static function number_format($number, $format='%01.8f'){
		$number=sprintf($format, $number);
		$number=floor($number)==$number?(int)$number:rtrim($number, '0');
		return $number;
	}
	
	public static function str_color($str='', $key=0, $return_type=0){
		$key>15 && $key=$key%15;
		return $return_type==0?"<font class='fc_$key'>$str</font>":"fc_$key";
	}
	
	public static function query_string($un='', $query_string=''){	//组织url参数
		$un=(array)$un;
		$query_string=='' && $query_string=$_SERVER['QUERY_STRING'];
		if($query_string==''){return;}
		$q=@explode('&', $query_string);
		$v='';
		for($i=0; $i<count($q); $i++){
			$t=@explode('=', $q[$i]);
			if(in_array($t[0], $un)){continue;}
			$t[1]!='' && $v.=$t[0].'='.$t[1].'&';
		}
		$v=substr($v, 0, -1);
		$v=='=' && $v='';
		return $v;
	}
}




