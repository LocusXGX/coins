<?php
class do_action{
	public static function login(){
		global $c;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		if($p_account==$c['login_user'][0] && $p_password==$c['login_user'][1]){
			$_SESSION['Binance']=array(
				'UserId'	=>	1,
				'Account'	=>	$p_account,
				'Password'	=>	$p_password,
				'Symbol'	=>	$c['market']['symbol'][0],
				'Interval'	=>	$_SESSION['Binance']['Interval']=$c['binance']['kline_interval'][0]
			);
			wicker::e_json('', 1);
		}else{
			wicker::e_json('登录失败，错误的用户名或密码');
		}
	}
	
	public static function logout(){
		unset($_SESSION['Binance']);
		header('Location: /');
		exit;
	}
	
	public static function set_symbol(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		unset($_SESSION['Binance']['ClickPrice']);
		in_array($p_symbol, $c['market']['symbol']) && $_SESSION['Binance']['Symbol']=$p_symbol;
		$default_set=in_array($_SESSION['Binance']['Symbol'], $c['binance']['main_symbol'])?$c['binance']['default_set_main']:$c['binance']['default_set'];
		wicker::e_json(array($_SESSION['Binance']['Symbol'], $default_set['volume_operation']), 1);
	}
	
	public static function set_click_price(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		$_SESSION['Binance']['ClickPrice']=sprintf($c['market']['price_precision'][$_SESSION['Binance']['Symbol']], $p_price);
		$_SESSION['Binance']['ClickPriceTime']=$c['time'];
		wicker::e_json('', 1);
	}
	
	public static function set_interval(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		in_array($p_interval, $c['binance']['kline_interval']) && $_SESSION['Binance']['Interval']=$p_interval;
		wicker::e_json('', 1);
	}
	
	public static function set_confirm(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		$p_OrdersId=(int)$p_OrdersId;
		$orders_row=db::get_one('orders', "OrdersId='$p_OrdersId' and OrderStatus=0");
		!$orders_row && wicker::e_json('订单不存在');
		wicker::update_orders_config($orders_row['OrdersId'], 'set_update_time', 0);
		wicker::e_json(sprintf('【%s】【%s】确认设置成功', strtoupper($orders_row['Symbol']), $c['order_position_side'][$orders_row['PositionSide']]), 1);
	}
	
	public static function set_cost_close(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		$p_OrdersId=(int)$p_OrdersId;
		$orders_row=db::get_one('orders', "OrdersId='$p_OrdersId' and OrderStatus=0");
		!$orders_row && wicker::e_json('订单不存在');
		wicker::update_orders_config($orders_row['OrdersId'], 'set_stop_win_percent', $c['binance']['percent_list'][0]);
		wicker::update_orders_config($orders_row['OrdersId'], 'set_stop_win_price', 0);
		wicker::update_orders_config($orders_row['OrdersId'], 'set_stop_win_ticker_price', '');
		wicker::update_orders_config($orders_row['OrdersId'], 'set_update_time', 0);
		wicker::e_json(sprintf('【%s】【%s】设置保本平仓成功', strtoupper($orders_row['Symbol']), $c['order_position_side'][$orders_row['PositionSide']]), 1);
	}
	
	public static function get_config(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		$p_OrdersId=(int)$p_OrdersId;
		$orders_row=db::get_one('orders', "OrdersId='$p_OrdersId' and OrderStatus=0");
		!$orders_row && wicker::e_json('订单不存在');
		$set_config=json_decode($orders_row['SetConfig'], true);
		$set_config['base']['symbol']=strtoupper($orders_row['Symbol']);
		$set_config['base']['position_side']=$c['order_position_side'][$orders_row['PositionSide']];
		wicker::e_json($set_config, 1);
	}
	
	public static function set_config(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		$p_OrdersId=(int)$p_OrdersId;
		$orders_row=db::get_one('orders', "OrdersId='$p_OrdersId' and OrderStatus=0");
		!$orders_row && wicker::e_json('订单不存在');
		$p_set_stop_win_ticker_price=$p_set_stop_win_ticker_price>0?str::number_format(sprintf($c['market']['price_precision'][$orders_row['Symbol']], $p_set_stop_win_ticker_price)):'';
		$p_set_float_win_ticker_price=$p_set_float_win_ticker_price>0?str::number_format(sprintf($c['market']['price_precision'][$orders_row['Symbol']], $p_set_float_win_ticker_price)):'';
		$p_set_stop_loss_ticker_price=$p_set_stop_loss_ticker_price>0?str::number_format(sprintf($c['market']['price_precision'][$orders_row['Symbol']], $p_set_stop_loss_ticker_price)):'';
		$set_config=array(
			'set_stop_win_percent'		=>	(float)$p_set_stop_win_percent,
			'set_stop_win_price'		=>	(float)$p_set_stop_win_price,
			'set_stop_win_ticker_price'	=>	$p_set_stop_win_ticker_price,
			'set_float_win_percent'		=>	(float)$p_set_float_win_percent,
			'set_float_win_price'		=>	(float)$p_set_float_win_price,
			'set_float_win_ticker_price'=>	$p_set_float_win_ticker_price,
			'set_stop_loss_percent'		=>	(float)$p_set_stop_loss_percent,
			'set_stop_loss_price'		=>	(float)$p_set_stop_loss_price,
			'set_stop_loss_ticker_price'=>	$p_set_stop_loss_ticker_price,
			'set_cut_stock'				=>	(float)$p_set_cut_stock,
			'set_reset_plan'			=>	(int)$p_set_reset_plan,
			'set_update_time'			=>	(int)$c['time']
		);
		db::update('orders', "OrdersId='{$orders_row['OrdersId']}'", array('SetConfig'=>json_encode($set_config)));
		wicker::e_json('', 1);
	}
	
	public static function auto_open_config(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		$default_set=in_array($_SESSION['Binance']['Symbol'], $c['binance']['main_symbol'])?$c['binance']['default_set_main']:$c['binance']['default_set'];
		$data=array(
			'symbol'			=>	strtoupper($_SESSION['Binance']['Symbol']),
			'auto_open_amout'	=>	$default_set['volume_operation'][1],
			'stop_win_percent'	=>	$default_set['win_loss_percent'][0],
			'stop_loss_percent'	=>	$default_set['win_loss_percent'][1]
		);
		wicker::e_json($data, 1);
	}
	
	public static function auto_open(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		$p_auto_open_amout=(int)$p_auto_open_amout;
		$p_auto_open_price_type=(int)$p_auto_open_price_type;
		$p_auto_open_kline_price_offset=(float)$p_auto_open_kline_price_offset;
		$p_auto_open_stop_win_percent=(float)$p_auto_open_stop_win_percent;
		$p_auto_open_stop_loss_percent=(float)$p_auto_open_stop_loss_percent;
		$p_auto_open_position_side=='' && wicker::e_json('请正确设置开仓方向');
		$p_auto_open_amout<=0 && wicker::e_json('请正确设置开仓金额');
		$p_auto_open_set_plan=(int)$p_auto_open_set_plan;
		$p_auto_open_is_loop=(int)$p_auto_open_is_loop;
		if($p_auto_open_price_type==0){
			$p_auto_open_price=(float)$p_auto_open_price;
			$p_auto_open_price<=0 && wicker::e_json('请正确填写开仓价格');
			$p_auto_open_kline_interval=$p_auto_open_kline_indicator=$p_auto_open_kline_price_offset='';
			$identification=$p_auto_open_position_side.'_'.str::number_format($p_auto_open_price);
			$check_price=$p_auto_open_price;
		}else{
			$p_auto_open_kline_interval=='' && wicker::e_json('请正确设置开仓价格周期');
			$p_auto_open_kline_indicator=='' && wicker::e_json('请正确设置开仓价格指标');
			$identification="{$p_auto_open_position_side}_{$p_auto_open_kline_interval}_{$p_auto_open_kline_indicator}";
			$p_auto_open_kline_price_offset!=0 && $identification.=($p_auto_open_kline_price_offset>0?'+':'').$p_auto_open_kline_price_offset.'%';
			$check_price=wicker::get_reference_price($_SESSION['Binance']['Symbol'], str_replace("{$p_auto_open_position_side}_", '', $identification));
		}
		if(
			$p_auto_open_is_loop==0 && (
				($p_auto_open_position_side=='LONG' && $check_price>=$c['market']['ticker_price'][$_SESSION['Binance']['Symbol']]) || 
				($p_auto_open_position_side=='SHORT' && $check_price<=$c['market']['ticker_price'][$_SESSION['Binance']['Symbol']])
			)
		){
			wicker::e_json('此设置将会直接开仓，请直接下单开仓');
		}
		$data=array(
			'Symbol'		=>	$_SESSION['Binance']['Symbol'],
			'Identification'=>	$identification,
			'OpenConfig'	=>	json_encode(array(
										'auto_open_position_side'		=>	$p_auto_open_position_side,
										'auto_open_amout'				=>	$p_auto_open_amout,
										'auto_open_price_type'			=>	$p_auto_open_price_type,
										'auto_open_price'				=>	$p_auto_open_price,
										'auto_open_kline_interval'		=>	$p_auto_open_kline_interval,
										'auto_open_kline_indicator'		=>	$p_auto_open_kline_indicator,
										'auto_open_kline_price_offset'	=>	$p_auto_open_kline_price_offset,
										'auto_open_stop_win_percent'	=>	$p_auto_open_stop_win_percent,
										'auto_open_stop_loss_percent'	=>	$p_auto_open_stop_loss_percent,
										'auto_open_set_plan'			=>	$p_auto_open_set_plan,
										'auto_open_is_loop'				=>	$p_auto_open_is_loop
									)
								),
			'AccTime'		=>	$c['time'],
			'AccTimeFormat'	=>	$c['time_format']
		);
		db::insert_update('orders_auto_open', "Symbol='{$data['Symbol']}' and Identification='{$data['Identification']}' and OpenStatus=0", $data);
		wicker::e_json('', 1);
	}
	
	public static function auto_open_del(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		$p_OpenId=(int)$p_OpenId;
		db::delete('orders_auto_open', "OpenId='$p_OpenId'");
		wicker::e_json('', 1);
	}
	
	public static function cancel_orders(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		$p_OrdersId=(int)$p_OrdersId;
		$orders_row=db::get_one('orders', "OrdersId='$p_OrdersId' and OrderStatus=0");
		!$orders_row && wicker::e_json('订单不存在');
		$orders_cancelall=wicker::orders_cancelall($orders_row['OrdersId']);
		$orders_cancelall['ret']==1 && wicker::update_orders_config($orders_row['OrdersId'], 'set_update_time', (int)$c['time']);
		$msg=array('撤单失败：'.$orders_cancelall['msg']['msg'], '挂单撤消成功', '当前无挂单');
		wicker::e_json(sprintf('【%s】【%s】', strtoupper($orders_row['Symbol']), $c['order_position_side'][$orders_row['PositionSide']]).$msg[(int)$orders_cancelall['ret']], 1);
	}
	
	public static function cancel_list_orders(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		$p_ListId=(int)$p_ListId;
		$list_row=db::get_one('orders_list', "ListId='$p_ListId'");
		$list_row['OrderStatus']>=5 && wicker::e_json('当前订单状态无法撤单！');
		$binance=new binance();
		$swap_cancel=$binance->swap_cancel($list_row['Symbol'], $list_row['BinanceOrdersId']);
		$swap_cancel['ret']!=1 && wicker::e_json('撤单失败：'.$swap_cancel['msg']['msg']);
		db::update('orders_list', "Symbol='{$list_row['Symbol']}' and ListId='$p_ListId'", array('IsCanceling'=>1));
		wicker::update_orders_config($list_row['OrdersId'], 'set_update_time', (int)$c['time']);
		wicker::e_json('', 1);
	}
	
	public static function set_page(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		$_SESSION['Binance']['page']=(int)$p_page;
		wicker::e_json('', 1);
	}
	
	public static function plan_add(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		$p_OrdersId=(int)$p_OrdersId;
		$orders_row=db::get_one('orders', "OrdersId='$p_OrdersId' and OrderStatus=0", '*', 'OrdersId desc');
		!$orders_row && wicker::e_json('当前没有进行中的订单');
		$p_plan_type=='' && wicker::e_json('请正确选择计划类型');
		$p_volume=='' && wicker::e_json('请正确选择金额');
		$p_plan_type=(int)$p_plan_type;
		$p_price_type=(int)$p_price_type;
		$p_price_offset=(float)$p_price_offset;
		$p_volume=(int)$p_volume;
		$p_close_percent=(float)$p_close_percent;
		$p_is_loop=$p_close_percent==0?0:(int)$p_is_loop;
		if($p_price_type==0){
			$p_price=(float)$p_price;
			$p_price<=0 && $p_price=$c['market']['ticker_price'][$orders_row['Symbol']];
			$p_price_offset!=0 && $p_price*=(1+$p_price_offset/100);
			abs($c['market']['ticker_price'][$orders_row['Symbol']]-$p_price)/$p_price>=0.2 && wicker::e_json('请正确填写价格');
			if($orders_row['PositionSide']=='LONG'){
				$price_type=$p_plan_type==0?(($p_price<$c['market']['ticker_price'][$orders_row['Symbol']] || $p_is_loop)?1:0):(($p_price>=$c['market']['ticker_price'][$orders_row['Symbol']] || $p_is_loop)?0:1);
			}else{
				$price_type=$p_plan_type==0?(($p_price>=$c['market']['ticker_price'][$orders_row['Symbol']] || $p_is_loop)?0:1):(($p_price<$c['market']['ticker_price'][$orders_row['Symbol']] || $p_is_loop)?1:0);
			}
			$p_price=sprintf($c['market']['price_precision'][$orders_row['Symbol']], $p_price);
			$price_txt='';
		}else{
			$p_price_txt_interval=='' && wicker::e_json('请正确设置价格周期');
			$p_price_txt_indicator=='' && wicker::e_json('请正确设置价格指标');
			$p_price=0;
			$price_type=0;
			$price_txt="{$p_price_txt_interval}_{$p_price_txt_indicator}";
			$p_price_offset!=0 && $price_txt.=($p_price_offset>0?'+':'').$p_price_offset.'%';
		}
		db::insert('plan', array(
				'Symbol'				=>	$orders_row['Symbol'],
				'OrdersId'				=>	$orders_row['OrdersId'],
				'PlanType'				=>	$p_plan_type,
				'Price'					=>	$p_price,
				'PriceTxt'				=>	$price_txt,
				'PriceType'				=>	$price_type,
				'Volume'				=>	$p_volume,
				'VolumeType'			=>	0,
				'Amount'				=>	$p_volume,
				'ClosePercent'			=>	$p_close_percent,
				'IsLoop'				=>	$p_is_loop,
				'AccTime'				=>	$c['time'],
				'AccTimeFormat'			=>	$c['time_format'],
				'CompletedTime'			=>	$c['time'],
				'CompletedTimeFormat'	=>	$c['time_format']
			)
		);
		wicker::update_orders_config($orders_row['OrdersId'], 'set_update_time', (int)$c['time']);
		wicker::e_json('设置成功', 1);
	}
	
	public static function plan_quick_set(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		$p_OrdersId=(int)$p_OrdersId;
		$orders_row=db::get_one('orders', "OrdersId='$p_OrdersId' and OrderStatus=0", '*', 'OrdersId desc');
		!$orders_row && wicker::e_json('当前没有进行中的订单');
		wicker::plan_quick_set($orders_row['OrdersId']);
		wicker::update_orders_config($orders_row['OrdersId'], 'set_update_time', 0);
		wicker::e_json('设置成功', 1);
	}
	
	public static function plan_del(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		$p_PlanId=(int)$p_PlanId;
		db::delete('plan', "PlanId='$p_PlanId'");
		wicker::e_json('', 1);
	}
	
	public static function plan_clear(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		$p_OrdersId=(int)$p_OrdersId;
		db::delete('plan', "OrdersId='$p_OrdersId'");
		wicker::e_json('', 1);
	}
	
	public static function choose_list(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		$p_interval=(int)$p_interval;
		$p_reference=(int)$p_reference;
		$p_sort=(int)$p_sort;
		$_SESSION['Binance']['Interval']=$c['binance']['kline_interval'][$p_interval];
		$kline_reference_ary=array('MA5','MA10','BollUB','BollMB','BollLB');
		$kline_reference=$kline_reference_ary[$p_reference];
		$data=array(
			'interval'		=>	$_SESSION['Binance']['Interval'],
			'choose_list'	=>	include($c['root_path'].'/inc/html/choose_list.php')
		);
		wicker::e_json($data, 1);
	}
	
	public static function open_close_position(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		$p_volume=$volume=(int)$p_volume;
		$p_place_price=$place_price=(float)$p_place_price;
		$p_stop_win=(float)$p_stop_win;
		$p_volume<=0 && wicker::e_json('请正确选择金额');
		$p_OrdersId=(int)$p_OrdersId;
		if($p_OrdersId){
			$orders_row=db::get_one('orders', "OrdersId='$p_OrdersId' and OrderStatus=0", '*', 'OrdersId desc');
			!$orders_row && wicker::e_json('订单不存在');
			$symbol=$orders_row['Symbol'];
		}else{
			$orders_row=db::get_one('orders', "Symbol='{$_SESSION['Binance']['Symbol']}' and OrderStatus=0 and PositionSide='$p_position_side'", '*', 'OrdersId desc');
			$symbol=$_SESSION['Binance']['Symbol'];
		}
		if($p_place_price==0){
			if(($p_position_side=='LONG' && $p_position_type=='open') || ($orders_row['PositionSide']=='SHORT' && $p_position_type=='close')){
				$p_place_price=$c['market']['ticker_price'][$symbol]*1.01;
			}else{
				$p_place_price=$c['market']['ticker_price'][$symbol]*0.99;
			}
		}
		$p_place_price=wicker::place_order_price($p_place_price, $symbol);
		$p_place_price<=0 && wicker::e_json('请正确填写价格');
		$side=(($p_position_type=='open' && $p_position_side=='LONG') || ($p_position_type=='close' && $orders_row['PositionSide']=='SHORT'))?'BUY':'SELL';
		$cost_price=($place_price<=0 || ($side=='BUY' && $place_price>$c['market']['ticker_price'][$symbol]) || ($side=='SELL' && $place_price<$c['market']['ticker_price'][$symbol]))?$c['market']['ticker_price'][$symbol]:$place_price;
		$binance=new binance();
		if($p_position_type=='open'){
			$p_volume=wicker::place_order_volume($p_volume/$cost_price, $symbol);
			$swap_order=$binance->swap_order($symbol, $p_place_price, $p_volume, $side, $p_position_side);
			$swap_order['ret']!=1 && wicker::e_json('开仓下单失败：'.$swap_order['msg']['msg']);
			if(!$orders_row){
				$default_set=in_array($symbol, $c['binance']['main_symbol'])?$c['binance']['default_set_main']:$c['binance']['default_set'];
				if($p_stop_win>0){
					$set_stop_win_percent=$set_stop_loss_percent=$p_stop_win;
					$set_stop_win_price=intval($volume*$p_stop_win/100);
					$set_stop_loss_price=max(intval($volume*$p_stop_win*2/100), $c['binance']['price_list'][0]);
					$p_stop_win=0;
				}else{
					$set_stop_win_percent=$default_set['win_loss_percent'][0];
					$set_stop_loss_percent=$default_set['win_loss_percent'][1];
					$set_stop_win_price=intval($volume*$default_set['win_loss_percent'][0]/100);
					$set_stop_loss_price=max(intval($volume*$default_set['win_loss_percent'][1]/100), $c['binance']['price_list'][0]);
				}
				in_array($set_stop_win_price, $c['binance']['price_list'])?$set_stop_win_percent=0:$set_stop_win_price=0;
				in_array($set_stop_loss_price, $c['binance']['price_list'])?$set_stop_loss_percent=0:$set_stop_loss_price=0;
				$symbol_config=array(
					'price_precision'		=>	$c['market']['price_precision'][$symbol],
					'quantity_precision'	=>	$c['market']['quantity_precision'][$symbol]
				);
				$set_config=array(
					'set_stop_win_percent'		=>	$set_stop_win_percent,
					'set_stop_win_price'		=>	$set_stop_win_price,
					'set_stop_win_ticker_price'	=>	'',
					'set_float_win_percent'		=>	0,
					'set_float_win_price'		=>	0,
					'set_float_win_ticker_price'=>	'',
					'set_stop_loss_percent'		=>	$set_stop_loss_percent,
					'set_stop_loss_price'		=>	$set_stop_loss_price,
					'set_stop_loss_ticker_price'=>	'',
					'set_cut_stock'				=>	(int)$default_set['open_set']['cut_stock']?$volume:0,
					'set_reset_plan'			=>	(int)$default_set['open_set']['reset_plan'],
					'set_update_time'			=>	0
				);
				db::insert('orders', array(
						'Symbol'				=>	$symbol,
						'SymbolConfig'			=>	json_encode($symbol_config),
						'SetConfig'				=>	json_encode($set_config),
						'OpenPrice'				=>	$cost_price,
						'OpenAmount'			=>	$volume,
						'CostPrice'				=>	$cost_price,
						'PositionSide'			=>	$p_position_side,
						'Side'					=>	$side,
						'AccTime'				=>	$c['time'],
						'AccTimeFormat'			=>	$c['time_format'],
						'CompletedTime'			=>	$c['time'],
						'CompletedTimeFormat'	=>	$c['time_format']
					)
				);
				$OrdersId=db::get_insert_id();
				(int)$default_set['open_set']['set_plan'] && wicker::plan_quick_set($OrdersId);
			}else{
				$OrdersId=$orders_row['OrdersId'];
				wicker::update_orders_config($orders_row['OrdersId'], 'set_update_time', $c['time']);
			}
			db::insert('orders_list', array(
					'Symbol'				=>	$symbol,
					'OrdersId'				=>	$OrdersId,
					'PlanPriceTxt'			=>	'',
					'BinanceOrdersId'		=>	$swap_order['msg']['orderId'],
					'TriggerPrice'			=>	$c['market']['ticker_price'][$symbol],
					'PendingPrice'			=>	$p_place_price,
					'PendingRealPrice'		=>	$p_place_price,
					'Volume'				=>	$p_volume,
					'Amount'				=>	$volume,
					'StopWin'				=>	$p_stop_win,
					'Side'					=>	$side,
					'PositionSide'			=>	$p_position_side,
					'OptCondition'			=>	10,
					'AccTime'				=>	$c['time'],
					'AccTimeFormat'			=>	$c['time_format'],
					'CompletedTime'			=>	$c['time'],
					'CompletedTimeFormat'	=>	$c['time_format']
				)
			);
		}else{
			(!$orders_row || $orders_row['OpenVolume']-$orders_row['CloseVolume']<=0) && wicker::e_json('当前无持仓');
			if($volume==10000000){
				$operation_type='清仓';
				$orders_cancelall=wicker::orders_cancelall($orders_row['OrdersId']);
				!$orders_cancelall['ret'] && wicker::e_json('撤单失败：'.$orders_cancelall['msg']['msg']);
				$p_volume=wicker::place_order_volume($orders_row['OpenVolume']-$orders_row['CloseVolume'], $symbol);
				$volume=round($c['market']['ticker_price'][$symbol]*$p_volume/$c['binance']['price_modulo'])*$c['binance']['price_modulo'];
			}else{
				$operation_type='减仓';
				$pending_close_volume=db::get_sum('orders_list', "OrdersId='{$orders_row['OrdersId']}' and OrderStatus<5 and ((PositionSide='LONG' and Side='SELL') or (PositionSide='SHORT' and Side='BUY'))", 'Volume');
				$pending_close_volume=sprintf($c['market']['quantity_precision'][$symbol], $pending_close_volume);
				$left_close_voume=sprintf($c['market']['quantity_precision'][$symbol], $orders_row['OpenVolume']-$orders_row['CloseVolume']-$c['market']['step_size'][$symbol])-$pending_close_volume;
				$left_close_voume<=0 && wicker::e_json('减仓下单失败：可减仓数量不足');
				$p_volume=wicker::place_order_volume($p_volume/$cost_price, $symbol);
				$p_volume=wicker::place_order_volume(min($p_volume, $left_close_voume), $symbol);
			}
			$swap_order=$binance->swap_order($symbol, $p_place_price, $p_volume, $side, $orders_row['PositionSide']);
			$swap_order['ret']!=1 && wicker::e_json($operation_type.'下单失败：'.$swap_order['msg']['msg']);
			db::insert('orders_list', array(
					'Symbol'				=>	$symbol,
					'OrdersId'				=>	$orders_row['OrdersId'],
					'PlanPriceTxt'			=>	'',
					'BinanceOrdersId'		=>	$swap_order['msg']['orderId'],
					'TriggerPrice'			=>	$c['market']['ticker_price'][$symbol],
					'PendingPrice'			=>	$p_place_price,
					'PendingRealPrice'		=>	$p_place_price,
					'Volume'				=>	$p_volume,
					'Amount'				=>	$volume,
					'StopWin'				=>	$p_stop_win,
					'Side'					=>	$side,
					'PositionSide'			=>	$orders_row['PositionSide'],
					'OptCondition'			=>	10,
					'AccTime'				=>	$c['time'],
					'AccTimeFormat'			=>	$c['time_format'],
					'CompletedTime'			=>	$c['time'],
					'CompletedTimeFormat'	=>	$c['time_format']
				)
			);
			wicker::update_orders_config($orders_row['OrdersId'], 'set_update_time', (int)$c['time']);
		}
		wicker::e_json('下单成功', 1);
	}
	
	public static function get_orders_list(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		@extract($_POST, EXTR_PREFIX_ALL, 'p');
		$p_OrdersId=(int)$p_OrdersId;
		$orders_list=include($c['root_path'].'/inc/html/orders_list.php');
		wicker::e_json($orders_list, 1);
	}
	
	public static function get_profit_data(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && exit;
		wicker::update_profit();
		$data=array();
		$profit_row=db::get_all('profit_logs', "AccTime>={$c['time']}-86400*30", '*', 'LogsId asc');
		foreach($profit_row as $v){
			$data[0][0][]=$data[1][0][]=date('m-d', $v['AccTime']);
			$data[0][1][]=array(
				'value'		=>	abs($v['FloatProfit']),
				'itemStyle'	=>	array('color'=>$v['FloatProfit']>=0?'#12b886':'#fa5252')
			);
			$data[1][1][]=intval($v['Profit']);
		}
		wicker::e_json($data, 1);
	}
	
	public static function get_data(){
		global $c;
		!(int)$_SESSION['Binance']['UserId'] && wicker::e_json('', 2);
		@extract($_GET, EXTR_PREFIX_ALL, 'p');
		!$c['market']['symbol'] && wicker::e_json();
		$price_precision=$c['market']['price_precision'][$_SESSION['Binance']['Symbol']];
		$p_screen_width=(int)$p_screen_width;
		$w="Symbol='{$_SESSION['Binance']['Symbol']}' and OrderStatus=0";
		if(!db::get_row_count('orders', $w)){
			$logs='【'.strtoupper($_SESSION['Binance']['Symbol']).'：当前无持仓】';
		}else{
			$file=$c['root_path'].'/logs/'.$_SESSION['Binance']['Symbol'];
			$logs_ary=array(
				db::get_row_count('orders', "$w and PositionSide='LONG'")?nl2br(trim(@file_get_contents($file.'_LONG.txt'))):'',
				db::get_row_count('orders', "$w and PositionSide='SHORT'")?nl2br(trim(@file_get_contents($file.'_SHORT.txt'))):''
			);
			$logs_ary=array_filter($logs_ary);
			$logs=implode('<div class="line"></div>', $logs_ary);
		}
		$data=array(
			'symbol'			=>	strtoupper($_SESSION['Binance']['Symbol']),
			'orders'			=>	include($c['root_path'].'/inc/html/orders.php'),
			'orders_page'		=>	max(1, $_SESSION['Binance']['page']),
			'plan_list'			=>	include($c['root_path'].'/inc/html/plan_list.php'),
			'quote_volume'		=>	@array_keys(array_filter($c['market']['quote_volume'], function($v){return $v>=5000;})),
			'price'				=>	$c['market']['get_ticker_price_time']+60*1000>$c['microtime']?sprintf($price_precision, $c['market']['ticker_price'][$_SESSION['Binance']['Symbol']]):'*****',
			'logs'				=>	$logs,
			'kline'				=>	array('name'=>$_SESSION['Binance']['Interval']),
			'rise'				=>	$c['market']['rise'],
			'price_precision'	=>	$c['market']['tick_zize'][$_SESSION['Binance']['Symbol']]<1?strlen(rtrim($c['market']['tick_zize'][$_SESSION['Binance']['Symbol']], '0'))-2:0,
			'time'				=>	$c['time']
		);
		$data['plan_list_md5']=md5(implode($data['plan_list']));
		$data['quote_volume_md5']=md5(@implode(',', $data['quote_volume']));
		$kline_row=db::get_limit("{$c['db_cfg']['market_db']}.{$_SESSION['Binance']['Symbol']}_kline_{$_SESSION['Binance']['Interval']}", 'IsUpdate=1', '*', 'AccTime desc,KlineId desc', 0, $p_screen_width<=1000?100:($p_screen_width<=1400?120:180));
		$kline_row && $kline_row[0]['ClosePrice']=$c['market']['ticker_price'][$_SESSION['Binance']['Symbol']];
		$kline_row=array_reverse($kline_row);
		foreach($kline_row as $k=>$v){
			$data['kline']['time'][]=date('m-d H:i', $v['AccTime']);
			$data['kline']['kline'][]=array((float)$v['OpenPrice'], (float)$v['ClosePrice'], (float)$v['LowPrice'], (float)$v['HightPrice']);
			$data['kline']['ma5'][]=(float)$v['MA5'];
			$data['kline']['ma10'][]=(float)$v['MA10'];
			$data['kline']['boll_ub'][]=(float)$v['BollUB'];
			$data['kline']['boll_mb'][]=(float)$v['BollMB'];
			$data['kline']['boll_lb'][]=(float)$v['BollLB'];
			$data['kline']['macd_bar'][]=array($k, (float)sprintf($price_precision, $v['Macd']), $v['Macd']>=0?1:-1);
			$data['kline']['macd_diff'][]=(float)sprintf($price_precision, $v['MacdDiff']);
			$data['kline']['macd_dea'][]=(float)sprintf($price_precision, $v['MacdDea']);
		}
		$data['kline']['orders']=array();
		($_SESSION['Binance']['ClickPrice']>0 && $_SESSION['Binance']['ClickPriceTime']+60>$c['time']) && $data['kline']['orders'][]=array(
			'yAxis'		=>	(float)sprintf($price_precision, $_SESSION['Binance']['ClickPrice']),
			'lineStyle'	=>	array('color'=>'#ff6600'),
			'label'		=>	array('backgroundColor'=>'#ff6600', 'formatter'=>sprintf($price_precision, $_SESSION['Binance']['ClickPrice']).'，'.sprintf('%01.2f', abs($_SESSION['Binance']['ClickPrice']-$c['market']['ticker_price'][$_SESSION['Binance']['Symbol']])/$_SESSION['Binance']['ClickPrice']*100).'%')
		);
		$orders_row=db::get_all('orders', "Symbol='{$_SESSION['Binance']['Symbol']}' and OrderStatus=0");
		foreach($orders_row as $v){
			$config=json_decode($v['SetConfig'], true);
			$color=$v['PositionSide']=='LONG'?'#12b886':'#fa5252';
			$data['kline']['orders'][]=array(
				'yAxis'		=>	(float)sprintf($price_precision, $v['CostPrice']),
				'lineStyle'	=>	array('color'=>$color),
				'label'		=>	array('backgroundColor'=>$color, 'formatter'=>$c['order_position_side'][$v['PositionSide']].'：'.sprintf($price_precision, $v['CostPrice']))
			);
			$orders_list_row=db::get_all('orders_list', "OrdersId='{$v['OrdersId']}' and OrderStatus<5");
			foreach($orders_list_row as $v1){
				if($v1['PlanIsBatAdd']==1 || sprintf($price_precision, $v1['PendingPrice'])==sprintf($price_precision, $v['CostPrice'])){continue;}
				$data['kline']['orders'][]=array(
					'yAxis'		=>	(float)sprintf($price_precision, $v1['PendingPrice']),
					'lineStyle'	=>	array('color'=>$color, 'opacity'=>0.35),
					'label'		=>	array('backgroundColor'=>$color, 'formatter'=>$c['order_position_side'][$v1['PositionSide'].'-'.$v1['Side']].'：'.sprintf($price_precision, $v1['PendingPrice']))
				);
			}
			$orders_volume=sprintf($c['market']['quantity_precision'][$v['Symbol']], $v['OpenVolume']-$v['CloseVolume']);
			if($orders_volume>0){
				$share_price=@sprintf('%01.10f', ($v['Profit']+$v['Fee'])/$orders_volume);
				$cost_price=sprintf($price_precision, $v['PositionSide']=='LONG'?$v['OpenPrice']-$share_price:$v['OpenPrice']+$share_price);
				if($config['set_stop_win_percent']>0 || $config['set_stop_win_price']>0 || $config['set_stop_win_ticker_price']>0){
					$stop_win_price_ary=array(
						$config['set_stop_win_percent']>0?($v['PositionSide']=='LONG'?$cost_price*(1+$config['set_stop_win_percent']/100):$cost_price*(1-$config['set_stop_win_percent']/100)):0,
						$config['set_stop_win_price']>0?($v['PositionSide']=='LONG'?$cost_price+$config['set_stop_win_price']/$orders_volume:$cost_price-$config['set_stop_win_price']/$orders_volume):0,
						$config['set_stop_win_ticker_price']
					);
					$stop_win_price_ary=array_filter($stop_win_price_ary);
					$stop_win_price=$v['PositionSide']=='LONG'?min($stop_win_price_ary):max($stop_win_price_ary);
					array_search($stop_win_price, $stop_win_price_ary)<=1 && $stop_win_price*=$v['PositionSide']=='LONG'?1+$c['binance']['trade_fee'][0]:1-$c['binance']['trade_fee'][0];	//不是直接指定价格的
					$stop_win_price=sprintf($price_precision, $stop_win_price);
					$data['kline']['orders'][]=array(
						'yAxis'		=>	(float)$stop_win_price,
						'lineStyle'	=>	array('color'=>$color, 'opacity'=>0.25),
						'label'		=>	array('backgroundColor'=>$color, 'formatter'=>'止盈：{c}')
					);
				}
				if($config['set_stop_loss_percent']>0 || $config['set_stop_loss_price']>0 || $config['set_stop_loss_ticker_price']>0){
					$stop_loss_price_ary=array(
						$config['set_stop_loss_percent']>0?($v['PositionSide']=='LONG'?$cost_price*(1-$config['set_stop_loss_percent']/100):$cost_price*(1+$config['set_stop_loss_percent']/100)):0,
						$config['set_stop_loss_price']>0?($v['PositionSide']=='LONG'?$cost_price-$config['set_stop_loss_price']/$orders_volume:$cost_price+$config['set_stop_loss_price']/$orders_volume):0,
						$config['set_stop_loss_ticker_price']
					);
					$stop_loss_price_ary=array_filter($stop_loss_price_ary);
					$stop_loss_price=sprintf($price_precision, $v['PositionSide']=='LONG'?max($stop_loss_price_ary):min($stop_loss_price_ary));
					$data['kline']['orders'][]=array(
						'yAxis'		=>	(float)$stop_loss_price,
						'lineStyle'	=>	array('color'=>$color, 'opacity'=>0.25),
						'label'		=>	array('backgroundColor'=>$color, 'formatter'=>'止损：{c}')
					);
				}
			}
		}
		$kline_row=array_reverse($kline_row);
		$quote_volume=$c['market']['quote_volume'][$_SESSION['Binance']['Symbol']];
		if($quote_volume>=10000){
			$quote_volume=(floor($quote_volume/10000)*10000/10000).'亿';
		}else{
			$quote_volume=$quote_volume.'万';
		}
		$data['info']=sprintf(str::str_color("<div class='info_list'>【%s：%s，%s.%s】【%s，%s%%】</div>", 2),
			strtoupper($_SESSION['Binance']['Symbol']),
			sprintf($price_precision, $c['market']['ticker_price'][$_SESSION['Binance']['Symbol']]),
			date('H:i:s', $c['time']),
			intval(($c['microtime']-$c['time']*1000)/100),
			$_SESSION['Binance']['Interval'],
			sprintf('%01.2f', $kline_row[0]['Rise']*100),
			$c['binance']['is_debug']==1?'【调试模式】':''
		);
		$data['info'].=sprintf(str::str_color("<div class='info_list'>【资金费：%s，<font class='%s'>%s%s%%</font>】【24H：%s】</div>", 2),
			date('H:i:s', $c['market']['interest_rate'][$_SESSION['Binance']['Symbol']][0]),
			abs($c['market']['interest_rate'][$_SESSION['Binance']['Symbol']][1])>0.01?'fc_red fb':'',
			$c['market']['interest_rate'][$_SESSION['Binance']['Symbol']][1]>0?'做多支付':'做空支付',
			abs($c['market']['interest_rate'][$_SESSION['Binance']['Symbol']][1]*100),
			$quote_volume
		);
		$data['info'].=sprintf("<div class='info_list'>【%s，%s%%】【%s，%s%%】【%s，%s%%】</div>",
			sprintf($price_precision, $kline_row[0]['BollUB']),
			@sprintf('%01.2f', ($kline_row[0]['BollUB']-$c['market']['ticker_price'][$_SESSION['Binance']['Symbol']])/$kline_row[0]['BollUB']*100),
			sprintf($price_precision, $kline_row[0]['BollMB']),
			@sprintf('%01.2f', abs($kline_row[0]['BollMB']-$c['market']['ticker_price'][$_SESSION['Binance']['Symbol']])/$kline_row[0]['BollMB']*100),
			sprintf($price_precision, $kline_row[0]['BollLB']),
			@sprintf('%01.2f', ($c['market']['ticker_price'][$_SESSION['Binance']['Symbol']]-$kline_row[0]['BollLB'])/$kline_row[0]['BollLB']*100)
		);
		$data['info'].=sprintf("<div class='info_list'>【MA5：%s，%s%%】【MA10：%s，%s%%】</div>",
			sprintf($price_precision, $kline_row[0]['MA5']),
			@sprintf('%01.2f', abs($kline_row[0]['MA5']-$c['market']['ticker_price'][$_SESSION['Binance']['Symbol']])/$kline_row[0]['MA5']*100),
			sprintf($price_precision, $kline_row[0]['MA10']),
			@sprintf('%01.2f', abs($kline_row[0]['MA10']-$c['market']['ticker_price'][$_SESSION['Binance']['Symbol']])/$kline_row[0]['MA10']*100)
		);
		$data['info']=nl2br($data['info']).'<div class="line"></div>';
		$auto_open_row=db::get_all('orders_auto_open', 'OpenStatus=0', '*', 'OpenId asc');
		$data['auto_open']='<ul>';
		foreach($auto_open_row as $v){
			$default_set=in_array($v['Symbol'], $c['binance']['main_symbol'])?$c['binance']['default_set_main']:$c['binance']['default_set'];
			$open_config=json_decode($v['OpenConfig'], true);
			if($open_config['auto_open_price_type']==0){
				$auto_open_price=sprintf($c['market']['price_precision'][$v['Symbol']], $open_config['auto_open_price']);
			}else{
				$auto_open_price=$open_config['auto_open_kline_interval'].$c['kline_indicator'][$open_config['auto_open_kline_indicator']];
				$open_config['auto_open_kline_price_offset']!=0 && $auto_open_price.=($open_config['auto_open_kline_price_offset']>0?'+':'').$open_config['auto_open_kline_price_offset'].'%';
			}
			$data['auto_open'].=sprintf('<li class="%s"><a href="javascript:void(0);" rel="%s" class="set_symbol">%s</a>，%s，%sU<br>盈损：%s%%/%s%%%s%s <a href="javascript:void(0);" class="auto_open_del" rel="%s">X</a>', $open_config['auto_open_position_side']=='LONG'?'fc_green':'fc_red', $v['Symbol'], strtoupper($v['Symbol']), $auto_open_price, $open_config['auto_open_amout'], $open_config['auto_open_stop_win_percent']?$open_config['auto_open_stop_win_percent']:$default_set['win_loss_percent'][0], $open_config['auto_open_stop_loss_percent']?$open_config['auto_open_stop_loss_percent']:$default_set['win_loss_percent'][1], $open_config['auto_open_set_plan']?'，计划':'', $open_config['auto_open_is_loop']?'，重复':'', $v['OpenId']);
		}
		$data['auto_open'].='</ul>';
		$data['auto_open']=='<ul></ul>' && $data['auto_open']='';
		$data['auto_open_md5']=md5($data['auto_open']);
		wicker::e_json($data, 1);
	}
}





