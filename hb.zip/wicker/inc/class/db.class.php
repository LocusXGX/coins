<?php
class db{
	private static $link_id=0;
	private static $query_id=0;
	private static $record=array();
	private static $errno=0;
	private static $error='';
	
	public static function connect(){	//连接数据库
		global $c;
		self::$link_id=@mysql_connect($c['db_cfg']['host'].':'.$c['db_cfg']['port'], $c['db_cfg']['username'], $c['db_cfg']['password']);
		self::$link_id || self::halt_msg('无法链接数据库，请检查数据库链接配置文件！');
		@mysql_select_db($c['db_cfg']['database']) || self::halt_msg('无法选择数据库，请检查数据库名称是否正确！');
	}
	
	private static function halt_msg($msg){	//消息提示
		global $c;
		self::$errno=@mysql_errno(self::$link_id);
		self::$error=@mysql_error(self::$link_id);
		@file_put_contents($c['root_path'].'/logs/mysql.txt', date('【Y-m-d H:i:s】')."\n".$_SERVER['PHP_SELF']."\n".$msg."\n".self::$error."\n\n", FILE_APPEND);
		exit;
	}
	
	private static function next_record(){	//返回记录集
		self::$record=@mysql_fetch_assoc(self::$query_id);
		return is_array(self::$record);
	}
	
	private static function result($two_dim=1, $field='', $key=''){
		if($two_dim){
			$result=array();
			while(self::next_record()){
				$data=$field==''?self::$record:self::$record[$field];
				$key?$result[self::$record[$key]]=$data:$result[]=$data;
			}
			return $result;
		}else{
			self::next_record();
			return $field==''?self::$record:self::$record[$field];
		}
	}
	
	public static function ping(){
		if(@mysql_ping(self::$link_id)){return;}
		self::close();
		self::connect();
	}
	
	public static function query($sql){	//直接执行SQL语句
		self::ping();
		$sql=str_replace(array('order by 1', 'group by 1'), '', str_replace('where 1 group', 'group', $sql));
		self::$query_id=@mysql_query($sql, self::$link_id);
		!self::$query_id && self::halt_msg($sql);
		return self::$query_id;
	}
	
	//-------------------------------------------------------------------------------------------------------------------------------------------------------------
	
	public static function get_all($table, $where=1, $field='*', $order=1, $group_by=1){	//返回整个数据表
		self::query("select $field from $table where $where group by $group_by order by $order");
		return self::result();
	}
	
	public static function get_limit($table, $where=1, $field='*', $order=1, $start_row=0, $row_count=20, $group_by=1){	//返回分页记录
		self::query("select $field from $table where $where group by $group_by order by $order limit $start_row, $row_count");
		return self::result();
	}
	
	public static function get_limit_page($table, $where=1, $field='*', $order=1, $page=1, $page_count=20, $group_by=1){	//返回高级形式分页记录
		$row_count=self::get_row_count($table, $where, $group_by, 1);
		$total_pages=ceil($row_count/$page_count);
		($page<1 || $page>$total_pages) && $page=1;
		$start_row=($page-1)*$page_count;
		return array(self::get_limit($table, $where, $field, $order, $start_row, $page_count, $group_by), $row_count, $page, $total_pages, $start_row);
	}
	
	public static function get_one($table, $where=1, $field='*', $order=1, $group_by=1){	//返回一条记录
		self::query("select $field from $table where $where group by $group_by order by $order".($group_by!=1?'':' limit 1'));
		return self::result($group_by!=1);
	}
	
	public static function get_rand($table, $where=1, $field='*', $id_field, $row_count=1, $group_by=1){	//返回随机N条记录
		$field=='*' && $field='t1.*';
		self::query("select $field from $table as t1 join(select round(rand()*((select max($id_field) from $table where $where)-(select min($id_field) from $table where $where))+(select min($id_field) from $table where $where)) as $id_field) as t2 where t1.$id_field>=t2.$id_field and $where group by $group_by order by t1.$id_field asc limit $row_count");
		return self::result();
	}
	
	public static function get_value($table, $where=1, $field, $order=1, $group_by=1){	//返回一个字段值
		self::query("select $field from $table where $where group by $group_by order by $order".($group_by!=1?'':' limit 1'));
		return self::result($group_by!=1, $field);
	}
	
	public static function get_row_count($table, $where=1, $group_by=1, $join=0){	//返回总记录数
		$f=($join==0 && $group_by!=1)?"$group_by,":'';
		self::query("select {$f}count(*) as row_count from $table where $where group by $group_by");
		return $group_by==1?self::result(0, 'row_count'):($join?mysql_num_rows(self::$query_id):self::result(1, 'row_count', $group_by));
	}
	
	public static function get_sum($table, $where=1, $field, $group_by=1, $join=1){	//返回合计值
		$f=($join==0 && $group_by!=1)?"$group_by,":'';
		self::query("select {$f}sum($field) as sum_count from $table where $where group by $group_by");
		return ($group_by==1 || $join==1)?array_sum(self::result(1, 'sum_count')):self::result(1, 'sum_count', $group_by);
	}
	
	public static function get_max($table, $where=1, $field, $group_by=1, $join=0){	//返回最大的值
		$f=($join==0 && $group_by!=1)?"$group_by,":'';
		self::query("select {$f}max($field) as max_value from $table where $where group by $group_by");
		return ($group_by==1 || $join==1)?max(self::result(1, 'max_value')):self::result(1, 'max_value', $group_by);
	}
	
	public static function get_union($sql, $params=array(), $fun='get_all', $method=0){	//以上所有get开头的方法联表查询
		$sql_ary=array();
		foreach($sql as $v){
			$table=$v[0];
			$where=$v[1]!=''?$v[1]:'1';
			$field=$v[2]!=''?$v[2]:'*';
			$order=$v[3]!=''?$v[3]:'1';
			$group_by=$v[4]!=''?$v[4]:'1';
			$sql_ary[]="(select $field from $table where $where group by $group_by order by $order)";	//table,where,field,order,group by
		}
		$params[0]='('.implode($method==0?' union all ':' union ', $sql_ary).') jt '.$params[0];
		return call_user_func_array(array('self', $fun), $params);
	}
	
	public static function get_table_fields($table, $only_return_field_name=0){	//返回数据表字段
		self::query("show columns from $table");
		return self::result(1, $only_return_field_name?'Field':'');
	}
	
	public static function get_insert_id(){	//最后一次操作关联ID号
		return mysql_insert_id(self::$link_id);
	}
	
	public static function insert($table, $data){	//插入记录
		foreach($data as $k=>$v){
			$fields.="$k,";
			$values.="'$v',";
		}
		$fields=substr($fields, 0, -1);
		$values=substr($values, 0, -1);
		self::query("insert into $table($fields) values($values)");
	}
	
	public static function insert_bat($table, $data){	//批量插入记录
		$field=implode(',', array_keys($data[0]));
		$value=array();
		foreach($data as $v){
			$value[]="'".implode("','", $v)."'";
		}
		$value=implode('),(', $value);
		self::query("insert into $table($field) values($value)");
	}
	
	public static function update($table, $where=0, $data){	//更新数据表
		foreach($data as $k=>$v){
			$upd_data.="$k='$v',";
		}
		$upd_data=substr($upd_data, 0, -1);
		self::query("update $table set $upd_data where $where");
	}
	
	public static function update_bat($table, $data, $field){	//批量更新数据表
		$sql='';
		$keys=array_keys($data[0]);
		foreach($keys as $v){
			if($v==$field){continue;}
			$sql.="$v=case $field";
			foreach($data as $v2){
				$sql.=" when '{$v2[$field]}' then '{$v2[$v]}'";
			}
			$sql.=' end,';
		}
		$sql=substr($sql, 0, -1);
		self::query("update $table set $sql where $field in(".implode(',', array_column($data, $field)).')');
	}
	
	public static function insert_update($table, $where, $data){
		self::get_row_count($table, $where)?self::update($table, $where, $data):self::insert($table, $data);
	}
	
	public static function delete($table, $where=0){	//删除数据
		self::query("delete from $table where $where");
	}
	
	public static function lock($table){	//锁定表
		$table=(array)$table;
		$table=implode(',', $table);
		self::query("lock tables $table");
	}
	
	public static function unlock(){	//解除锁定表
		self::query('unlock tables');
	}
	
	public static function close(){	//关闭数据库连接
		@mysql_close(self::$link_id);
	}
}




