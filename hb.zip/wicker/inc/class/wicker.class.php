<?php
class wicker{
	public static function e_json($msg='', $ret=0, $exit=1){
		is_bool($ret) && $ret=$ret?1:0;
		echo json_encode(array(
				'msg'	=>	$msg,
				'ret'	=>	$ret
			)
		);
		$exit && exit;
	}
	
	public static function do_action(){
		global $c;
		$do_action=isset($_POST['do_action'])?$_POST['do_action']:$_GET['do_action'];
		if($do_action==''){return;}
		method_exists('do_action', $do_action) && eval("do_action::$do_action();");
		exit;
	}
	
	public static function api_limit($weight){
		global $c;
		$c['binance']['api_limit'] && usleep($weight/$c['binance']['api_limit']*1000000);
	}
	
	public static function deep_in_array($need, $array){
		foreach((array)$need as $v){
			if(in_array($v, $array)){return true;}
		}
		return false;
	}
	
	public static function get_table_data_to_ary($table, $w, $key, $return_field='', $query_field='', $order=1, $group_by=1, $start_row=0, $row_count=100000){
		$data=array();
		$row=db::get_limit($table, $w, $query_field?$query_field:($return_field?"{$key},{$return_field}":'*'), $order, $start_row, $row_count, $group_by);
		$key=explode('.', $key);
		$key=array_pop($key);
		$return_field=explode('.', $return_field);
		$return_field=array_pop($return_field);
		foreach($row as $v){
			$data[$v[$key]]=$return_field!=''?$v[$return_field]:$v;
		}
		return $data;
	}
	
	public static function get_reference_price($symbol, $price_txt){
		global $c;
		$price_txt=explode('_', str_replace('%', '', $price_txt));
		$kline_row=db::get_one("{$c['db_cfg']['market_db']}.{$symbol}_kline_{$price_txt[0]}", 'IsUpdate=1', '*', 'KlineId desc');
		if(substr_count($price_txt[1], '+')){
			$price_txt=explode('+', $price_txt[1]);
			$price=$kline_row[$price_txt[0]]*(1+$price_txt[1]/100);
		}elseif(substr_count($price_txt[1], '-')){
			$price_txt=explode('-', $price_txt[1]);
			$price=$kline_row[$price_txt[0]]*(1-$price_txt[1]/100);
		}else{
			$price=$kline_row[$price_txt[1]];
		}
		return sprintf($c['market']['price_precision'][$symbol], $price);
	}
	
	public static function get_interval_acctime($interval, $time=0){
		global $c;
		$time==0 && $time=$c['time'];
		if($interval=='5m'){
			$interval_acctime=strtotime(date('Y-m-d H:00:00', $time))+floor(date('i', $time)/5)*5*60;
		}elseif($interval=='15m'){
			$interval_acctime=strtotime(date('Y-m-d H:00:00', $time))+floor(date('i', $time)/15)*15*900;
		}elseif($interval=='30m'){
			$interval_acctime=strtotime(date('Y-m-d H:00:00', $time))+(date('i', $time)>=30?1800:0);
		}elseif($interval=='1h'){
			$interval_acctime=strtotime(date('Y-m-d H:00:00', $time));
		}elseif($interval=='2h'){
			$interval_acctime=strtotime(date('Y-m-d H:00:00', $time))-(date('H', $time)%2)*3600;
		}elseif($interval=='4h'){
			$interval_acctime=strtotime(date('Y-m-d', $time))+floor(date('H', $time)/4)*4*3600;
		}elseif($interval=='6h'){
			if(date('H', $time)<2){
				$interval_acctime=strtotime(date('Y-m-d', $time))-3600*4;
			}elseif(date('H', $time)<8){
				$interval_acctime=strtotime(date('Y-m-d', $time))+3600*2;
			}elseif(date('H', $time)<14){
				$interval_acctime=strtotime(date('Y-m-d', $time))+3600*8;
			}elseif(date('H', $time)<20){
				$interval_acctime=strtotime(date('Y-m-d', $time))+3600*14;
			}else{
				$interval_acctime=strtotime(date('Y-m-d', $time))+3600*20;
			}
		}elseif($interval=='8h'){
			$interval_acctime=strtotime(date('Y-m-d', $time))+floor(date('H', $time)/8)*8*3600;
		}elseif($interval=='12h'){
			if(date('H', $time)<8){
				$interval_acctime=strtotime(date('Y-m-d', $time))-3600*4;
			}elseif(date('H', $time)>=20){
				$interval_acctime=strtotime(date('Y-m-d', $time))+3600*20;
			}else{
				$interval_acctime=strtotime(date('Y-m-d', $time))+3600*8;
			}
		}elseif($interval=='1d'){
			$interval_acctime=strtotime(date('Y-m-d', strtotime(date('Y-m-d', $time))-3600*8))+3600*8+(date('H', $time)>=8?86400:0);
		}elseif($interval=='1w'){
			$interval_acctime=strtotime(date('Y-m-d', $time-((date('w', $time)==0?7:date('w', $time))-1)*86400-((date('w', $time)==1 && date('H', $time)<8)?86400*7:0)))+3600*8;
		}elseif($interval=='1M'){
			$interval_acctime=strtotime(date('Y-m-01', $time-((date('d', $time)==1 && date('H', $time)<8)?86400:0)))+3600*8;
		}
		return (int)$interval_acctime;
	}
	
	public static function place_order_volume($volume, $symbol, $price=0){
		global $c;
		$volume=sprintf($c['market']['quantity_precision'][$symbol], $volume);
		$volume<$c['market']['min_qty'][$symbol] && $volume=$c['market']['min_qty'][$symbol];
		$price==0 && $price=$c['market']['ticker_price'][$symbol];
		while(($c['market']['step_size'][$symbol]>0 && $volume*$price<$c['market']['notional'][$symbol]*1.1) && $run_count++<1000){
			$volume+=$c['market']['step_size'][$symbol];
		}
		$volume>$c['market']['max_qty'][$symbol] && $volume=$c['market']['max_qty'][$symbol];
		return sprintf($c['market']['quantity_precision'][$symbol], $volume);
	}
	
	public static function place_order_price($price, $symbol, $side=''){
		global $c;
		if($side=='BUY' && $price>$c['market']['ticker_price'][$symbol]*1.025){
			$price=$c['market']['ticker_price'][$symbol]*1.025;
		}elseif($side=='SELL' && $price<$c['market']['ticker_price'][$symbol]*0.975){
			$price=$c['market']['ticker_price'][$symbol]*0.975;
		}
		return sprintf($c['market']['price_precision'][$symbol], $price);
	}
	
	public static function place_order_maker_price($price, $symbol, $side){
		global $c;
		if($side=='BUY' && $price>=$c['market']['ticker_price'][$symbol]){
			$price=$c['market']['ticker_price'][$symbol]-$c['market']['tick_zize'][$symbol];
		}elseif($side=='SELL' && $price<=$c['market']['ticker_price'][$symbol]){
			$price=$c['market']['ticker_price'][$symbol]+$c['market']['tick_zize'][$symbol];
		}
		return sprintf($c['market']['price_precision'][$symbol], $price);
	}
	
	public static function plan_quick_set($OrdersId){
		global $c;
		$orders_row=db::get_one('orders', "OrdersId='$OrdersId' and OrderStatus=0", '*', 'OrdersId desc');
		if(!$orders_row){return;}
		$symbol_config=json_decode($orders_row['SymbolConfig'], true);
		$set_config=json_decode($orders_row['SetConfig'], true);
		$orders_price=$set_config['set_cut_stock']>0?$set_config['set_cut_stock']:$orders_row['OpenAmount'];
		$data=array();
		$plan=in_array($orders_row['Symbol'], $c['binance']['main_symbol'])?$c['binance']['default_set_main']['plan']:$c['binance']['default_set']['plan'];
		$plan_type=-1;
		foreach($plan['count'] as $plan_count_key=>$plan_count){
			if($plan['volume'][$plan_count_key]==0 || $plan['open_percent'][$plan_count_key]==0){continue;}
			if($plan_type!=$plan['type'][$plan_count_key]){
				$price=$orders_row['CostPrice'];
				if($plan['type'][$plan_count_key]==0 && $plan['first_offset'][$plan_count_key]>0){
					if(($orders_row['PositionSide']=='LONG' && $plan['open_percent'][$plan_count_key]<0) || ($orders_row['PositionSide']=='SHORT' && $plan['open_percent'][$plan_count_key]>0)){
						$price=$price*(1+$plan['first_offset'][$plan_count_key]/100+$plan['open_percent'][$plan_count_key]/100);
					}else{
						$price=$price*(1-$plan['first_offset'][$plan_count_key]/100-$plan['open_percent'][$plan_count_key]/100); 
					}
				}
				$plan_type=$plan['type'][$plan_count_key];
			}
			for($i=0; $i<$plan_count; $i++){
				$amount=is_int($plan['volume'][$plan_count_key])?$plan['volume'][$plan_count_key]:max(5, intval($orders_price*$plan['volume'][$plan_count_key]));
				if(($orders_row['PositionSide']=='LONG' && $plan['type'][$plan_count_key]==0) || ($orders_row['PositionSide']=='SHORT' && $plan['type'][$plan_count_key]==1)){
					$price_tmp=sprintf($symbol_config['price_precision'], $price*(1-$plan['open_percent'][$plan_count_key]/100));
					$price_tmp==$price && $price_tmp-=$c['market']['tick_zize'][$orders_row['Symbol']];
					$price_type=$plan['open_percent'][$plan_count_key]>0?1:0;
				}else{
					$price_tmp=sprintf($symbol_config['price_precision'], $price*(1+$plan['open_percent'][$plan_count_key]/100));
					$price_tmp==$price && $price_tmp+=$c['market']['tick_zize'][$orders_row['Symbol']];
					$price_type=$plan['open_percent'][$plan_count_key]>0?0:1;
				}
				$price=$price_tmp;
				$data[]=array(
					'Symbol'				=>	$orders_row['Symbol'],
					'OrdersId'				=>	$orders_row['OrdersId'],
					'PlanType'				=>	$plan['type'][$plan_count_key],
					'IsBatAdd'				=>	1,
					'Price'					=>	$price,
					'PriceType'				=>	$price_type,
					'Volume'				=>	$amount,
					'VolumeType'			=>	0,
					'Amount'				=>	$amount,
					'ClosePercent'			=>	$plan['close_percent'][$plan_count_key],
					'IsLoop'				=>	$plan['close_percent'][$plan_count_key]>0?1:0,
					'AccTime'				=>	$c['time'],
					'AccTimeFormat'			=>	$c['time_format'],
					'CompletedTime'			=>	$c['time'],
					'CompletedTimeFormat'	=>	$c['time_format']
				);
			}
		}
		db::delete('plan', "OrdersId='{$orders_row['OrdersId']}'");
		$data && db::insert_bat('plan', $data);
	}
	
	public static function check_lock($lock_name, $time=0){
		global $c;
		db::lock('config write');
		if($c['config'][$lock_name]==1){
			$time=max(30, $time)*1000;
			if($c['config']["{$lock_name}_time"]+$time<$c['microtime']){
				wicker::update_config($lock_name, 0);
				wicker::update_config("{$lock_name}_time", $c['microtime']);
			}
			exit;
		}
		wicker::update_config($lock_name, 1);
		wicker::update_config("{$lock_name}_time", $c['microtime']);
		db::unlock();
	}
	
	public static function get_config(){
		$config=array();
		$config_row=db::get_all('config');
		foreach($config_row as $v){
			$config[$v['Name']]=$v['Value'];
		}
		return $config;
	}
	
	public static function update_config($name, $value){
		db::insert_update('config', "Name='$name'", array(
				'Name'			=>	$name,
				'Value'			=>	$value
			)
		);
	}
	
	public static function update_orders_config($OrdersId, $name, $value){
		global $c;
		$orders_row=db::get_one('orders', "OrdersId='$OrdersId' and OrderStatus=0");
		if(!$orders_row){return;}
		$set_config=json_decode($orders_row['SetConfig'], true);
		$set_config[$name]=$value;
		db::update('orders', "OrdersId='$OrdersId'", array('SetConfig'=>json_encode($set_config)));
	}
	
	public static function update_profit(){
		global $c;
		$profit_logs_row=db::get_one('profit_logs', "AccTime={$c['today']}-86400");
		$profit=db::get_sum('orders', '1', 'FloatProfit');
		db::insert_update('profit_logs', "AccTime='{$c['today']}'", array(
				'Profit'		=>	$profit,
				'FloatProfit'	=>	$profit-$profit_logs_row['Profit'],
				'AccTime'		=>	$c['today'],
				'AccTimeFormat'	=>	date('Y-m-d', $c['today'])
			)
		);
	}
	
	public static function get_market(){
		global $c;
		$market=wicker::get_table_data_to_ary("{$c['db_cfg']['market_db']}.config", '1', 'Name', 'Value');
		foreach($market as $k=>$v){
			json_decode($v)!==null && $market[$k]=json_decode($v, true);
		}
		return $market;
	}
	
	public static function orders_cancelall($OrdersId, $OptCondition=''){
		global $c;
		$w="OrdersId='$OrdersId' and OrderStatus<5 and IsCanceling=0";
		$OptCondition!='' && $w.=" and OptCondition in($OptCondition)";
		$pending_row=db::get_all('orders_list', $w);
		if($pending_row){
			$binance=new binance();
			$cancel_orders_id=array_column($pending_row, 'BinanceOrdersId');
			for($i=0; $i<100; $i+=10){
				$cancel_orders_id_list=array_slice($cancel_orders_id, $i, 10);
				if(!$cancel_orders_id_list){break;}
				$swap_cancel_batch=$binance->swap_cancel_batch($pending_row[0]['Symbol'], $cancel_orders_id_list);
				if($swap_cancel_batch['ret']!=1){return $swap_cancel_batch;}
				$cancel_orders_id_list=implode(',', $cancel_orders_id_list);
				db::update('orders_list', "$w and BinanceOrdersId in($cancel_orders_id_list)", array('IsCanceling'=>1));
			}
			db::update('orders', "OrdersId='$OrdersId'", array('CancelOrdersTime'=>$c['time']));
			return $swap_cancel_batch;
		}else{
			return array('ret'=>2);
		}
	}
	
	public static function percent_list_reverse(){
		global $c;
		$percent_list=array();
		foreach($c['binance']['percent_list'] as $v){
			$v=sprintf('%01.2f', $v);
			$percent_list["$v"]='+'.$v;
		}
		foreach($c['binance']['percent_list'] as $v){
			$v=sprintf('%01.2f', $v);
			$percent_list["-$v"]='-'.$v;
		}
		return $percent_list;
	}
	
	public static function orders_monitor_logs($symbol, $position_side, $logs='', $order_status=0){
		global $c;
		$file="{$c['root_path']}/logs/{$symbol}_{$position_side}.txt";
		$order_status?@unlink($file):@file_put_contents($file, $c['logs'].($logs?str::str_color($logs, 1):''));
	}
	
	public static function orders_auto_open_logs($symbol, $position_side, $logs=''){
		global $c;
		$file="{$c['root_path']}/logs/{$symbol}_{$position_side}_auto_open.txt";
		@file_put_contents($file, $c['logs'].($logs?str::str_color($logs, 1):''));
	}
	
	public static function form_select($data, $name, $selected_value='', $index=0, $index_value='--请选择--', $field='', $key='', $attr='', $opt_attr='', $value_use_key=1, $text_add_pre='', $text_add_end=''){	//生成下拉表单
		$select="<select name='$name' $attr>".($index?"<option value=''>$index_value</option>":'');
		foreach($data as $k=>$v){
			$value=$value_use_key?(($key && array_key_exists($key, $v))?$v[$key]:$k):$v;
			$selected=($selected_value!='' && $value==$selected_value)?'selected':'';
			$text=$text_add_pre.($field?$v[$field]:$v).$text_add_end;
			$opt_attr_value=$opt_attr?@eval($opt_attr):'';
			$select.="<option value='{$value}' $opt_attr_value $selected>{$text}</option>";
		}
		$select.='</select>';
		return $select;
	}
	
	public static function turn_page($row_count, $page, $total_pages, $first_page='<<', $last_page='>>', $base_page=2){	//翻页
		if(!$row_count){return '';}
		$i_start=$page-$base_page>0?$page-$base_page:1;
		$i_end=$page+$base_page>=$total_pages?$total_pages:$page+$base_page;
		($total_pages-$page)<$base_page && $i_start=$i_start-($base_page-($total_pages-$page));
		$page<=$base_page && $i_end=$i_end+($base_page-$page+1);
		$i_start<1 && $i_start=1;
		$i_end>=$total_pages && $i_end=$total_pages;
		$turn_page_str='';
		$turn_page_str.="<a href='javascript:void(0);' page='1' class='page_button'>$first_page</a>";
		for($i=$i_start; $i<=$i_end; $i++){
			$turn_page_str.="<a href='javascript:void(0);' page='$i' class='page_item'>$i</a>";
		}
		$i_end<$total_pages && $turn_page_str.="<font class='page_item'>...</font><a href='javascript:void(0);' page='$total_pages' class='page_item'>$total_pages</a>";
		$turn_page_str.="<a href='javascript:void(0);' page='$total_pages' class='page_button'>$last_page</a>";
		return $turn_page_str;
	}
	
	public static function email($symbol, $subject, $contents){
		global $c;
		db::insert('email', array(
				'Symbol'		=>	$symbol,
				'Subject'		=>	addslashes($subject),
				'Contents'		=>	addslashes($contents),
				'AccTime'		=>	$c['time'],
				'AccTimeFormat'	=>	$c['time_format']
			)
		);
	}
	
	public static function send_email($to, $subject, $contents){
		global $c;
		include($c['root_path'].'/inc/class/phpmailer/phpmailer.php');
		$mail=new PHPMailer\PHPMailer\PHPMailer();
		$mail->Host=$c['mail_smtp']['Host'];
		$mail->Username=$c['mail_smtp']['UserName'];
		$mail->Password=$c['mail_smtp']['Password'];
		$mail->Port=465;
		$mail->SMTPSecure='ssl';
		$mail->setFrom($c['mail_smtp']['UserName'], 'wicker');
		$mail->addAddress($to);
		$mail->addReplyTo($c['mail_smtp']['UserName'], 'wicker');
		$mail->Subject=$subject;
		$mail->Body=$contents;
		return $mail->Send()?1:0;
	}
}




