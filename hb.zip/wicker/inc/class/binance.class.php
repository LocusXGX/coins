<?php
class binance{
	private $api='https://fapi.binance.com';
	private $api_method='';
	private $api_signature_method='';
	private $req_method='';
	
	function account(){	//持仓信息
		wicker::api_limit(5);
		$this->api_method='/fapi/v2/account';
		$this->api_signature_method='USER_DATA';
		$this->req_method='GET';
		$data=$this->create_sign();
		return $this->curl($this->api.$this->api_method, $data);
	}
	
	function swap_order($symbol='BTC', $price, $volume, $side, $position_side, $time_in_force='GTC'){	//合约下单
		wicker::api_limit(1);
		$this->api_method='/fapi/v1/order';
		$this->api_signature_method='TRADE';
		$this->req_method='POST';
		$symbol=strtoupper($symbol);
		$data=array(
			'symbol'		=>	$symbol.'USDT',
			'side'			=>	$side,	//买卖方向 SELL, BUY
			'positionSide'	=>	$position_side,	//双向持仓模式下必填,且仅可选择 LONG 或 SHORT
			'type'			=>	'LIMIT',	//订单类型 LIMIT, MARKET, STOP, TAKE_PROFIT, STOP_MARKET, TAKE_PROFIT_MARKET, TRAILING_STOP_MARKET
			'quantity'		=>	$volume,
			'price'			=>	$price,
			'timeInForce'	=>	$time_in_force
		);
		$data=$this->create_sign($data);
		return $this->curl($this->api.$this->api_method, $data);
	}
	
	function swap_order_batch($orders_data){	//合约批量下单
		wicker::api_limit(5);
		$this->api_method='/fapi/v1/batchOrders';
		$this->api_signature_method='TRADE';
		$this->req_method='POST';
		$data=array('batchOrders'=>json_encode(str::str_code($orders_data, 'strval')));
		$data=$this->create_sign($data);
		return $this->curl($this->api.$this->api_method, $data);
	}
	
	function swap_financial_record($type='FUNDING_FEE'){	//财务记录，收益类型 "TRANSFER"，"WELCOME_BONUS", "REALIZED_PNL"，"FUNDING_FEE", "COMMISSION", and "INSURANCE_CLEAR"
		wicker::api_limit(30);
		$this->api_method='/fapi/v1/income';
		$this->api_signature_method='USER_DATA';
		$this->req_method='GET';
		$data=array(
			'incomeType'=>	$type,
			'startTime'	=>	(strtotime('today')-86400)*1000,
			'limit'		=>	1000
		);
		$data=$this->create_sign($data);
		return $this->curl($this->api.$this->api_method, $data);
	}
	
	function swap_order_info($symbol='BTC', $order_id){	//获取订单信息
		wicker::api_limit(1);
		$this->api_method='/fapi/v1/order';
		$this->api_signature_method='USER_DATA';
		$this->req_method='GET';
		$symbol=strtoupper($symbol);
		$data=array(
			'symbol'	=>	$symbol.'USDT',
			'orderId'	=>	$order_id
		);
		$data=$this->create_sign($data);
		return $this->curl($this->api.$this->api_method, $data);
	}
	
	function swap_all_order_info($symbol='BTC', $order_id){	//获取所有订单信息
		wicker::api_limit(5);
		$this->api_method='/fapi/v1/allOrders';
		$this->api_signature_method='USER_DATA';
		$this->req_method='GET';
		$symbol=strtoupper($symbol);
		$data=array(
			'symbol'	=>	$symbol.'USDT',
			'orderId'	=>	$order_id
		);
		$data=$this->create_sign($data);
		return $this->curl($this->api.$this->api_method, $data);
	}
	
	function swap_cancel($symbol='BTC', $order_id){	//撤消挂单
		wicker::api_limit(1);
		$this->api_method='/fapi/v1/order';
		$this->api_signature_method='TRADE';
		$this->req_method='DELETE';
		$symbol=strtoupper($symbol);
		$data=array(
			'symbol'	=>	$symbol.'USDT',
			'orderId'	=>	$order_id
		);
		$data=$this->create_sign($data);
		return $this->curl($this->api.$this->api_method, $data);
	}
	
	function swap_cancel_batch($symbol='BTC', $order_id){	//批量撤消挂单
		wicker::api_limit(1);
		$this->api_method='/fapi/v1/batchOrders';
		$this->api_signature_method='TRADE';
		$this->req_method='DELETE';
		$symbol=strtoupper($symbol);
		$data=array(
			'symbol'		=>	$symbol.'USDT',
			'orderIdList'	=>	json_encode((array)$order_id)
		);
		$data=$this->create_sign($data);
		return $this->curl($this->api.$this->api_method, $data);
	}
	
	function swap_cancelall($symbol='BTC'){	//撤消全部挂单
		wicker::api_limit(1);
		$this->api_method='/fapi/v1/allOpenOrders';
		$this->api_signature_method='TRADE';
		$this->req_method='DELETE';
		$symbol=strtoupper($symbol);
		$data=array('symbol'=>$symbol.'USDT');
		$data=$this->create_sign($data);
		return $this->curl($this->api.$this->api_method, $data);
	}
	
	function leverage($symbol='BTC', $leverage=10){	//调整开仓杠杆倍数
		wicker::api_limit(1);
		$this->api_method='/fapi/v1/leverage';
		$this->api_signature_method='TRADE';
		$this->req_method='POST';
		$symbol=strtoupper($symbol);
		$data=array(
			'symbol'	=>	$symbol.'USDT',
			'leverage'	=>	$leverage
		);
		$data=$this->create_sign($data);
		return $this->curl($this->api.$this->api_method, $data);
	}
	
	function margin_type($symbol='BTC', $margin_type=1){	//变换逐全仓模式，0：全仓，1：逐仓
		wicker::api_limit(1);
		$this->api_method='/fapi/v1/marginType';
		$this->api_signature_method='TRADE';
		$this->req_method='POST';
		$symbol=strtoupper($symbol);
		$data=array(
			'symbol'	=>	$symbol.'USDT',
			'marginType'=>	$margin_type==0?'CROSSED':'ISOLATED'
		);
		$data=$this->create_sign($data);
		return $this->curl($this->api.$this->api_method, $data);
	}
	
	function leverage_bracket($symbol=''){
		wicker::api_limit(1);
		$this->api_method='/fapi/v1/leverageBracket';
		$this->api_signature_method='USER_DATA';
		$this->req_method='GET';
		$data=array();
		$symbol && $data['symbol']=strtoupper($symbol.'USDT');
		$data=$this->create_sign($data);
		return $this->curl($this->api.$this->api_method, $data);
	}
	
	function listen_key(){	//获取WSS密钥
		wicker::api_limit(1);
		$this->api_method='/fapi/v1/listenKey';
		$this->api_signature_method='USER_STREAM';
		$this->req_method='POST';
		$data=$this->create_sign();
		return $this->curl($this->api.$this->api_method, $data);
	}
	
	//---------------------------------------------------------------------------------------------------------------------------------------------------------------
	function create_sign($data=array()){
		global $c;
		$data['recvWindow']=60000;
		$data['timestamp']=$c['microtime'];
		$data['signature']=hash_hmac('sha256', http_build_query($data), $c['binance_api']['SecretKey']);
		return $data;
	}
	
	function curl($url, $data=array()){
		global $c;
		$header=array('Content-Type: application/json');
		$this->api_signature_method!='NONE' && $header[]="X-MBX-APIKEY: {$c['binance_api']['AccessKey']}";
		$ch=curl_init();
		curl_setopt($ch, CURLOPT_URL, $url.'?'.http_build_query($data));
		switch($this->req_method){
			case 'GET':
				curl_setopt($ch, CURLOPT_HTTPGET, true);
				break;
			case 'POST':
				curl_setopt($ch, CURLOPT_POST, true);
				break;
			case 'PUT':
				curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
				break;  
			case 'DELETE':
				curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
				break;  
		}
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		$result=array();
		$result['msg']=json_decode(curl_exec($ch), true);
		$ch_info=curl_getinfo($ch);
		$result['ch_info']=$ch_info;
		$result['ret']=((int)$ch_info['http_code']==200 && (int)$result['msg']['code']<1000)?1:0;
		curl_close($ch);
		return $result;
	}
}



