<?php
PHP_SAPI!='cli' && exit;
include(dirname(__FILE__).'/../../inc/global.php');

@set_time_limit(0);
$ws_monitor=array();
$binance=new binance();
while(1){
	while($ws_monitor['listen_key_time']+1800<time()){
		$listen_key=$binance->listen_key();
		if($listen_key['ret']==1){
			$listen_key=$listen_key['msg']['listenKey'];
			$ws_monitor['listen_key_time']=time();
		}
		sleep(1);
	}
	while($ws_monitor['ws_time']+1800<time()){
		$ws=new websocket('wss://fstream.binance.com/ws/'.$listen_key);
		$ws->is_construct && $ws_monitor['ws_time']=time();
		sleep(1);
	}
	if($ws_monitor['ws_time']+3600*12<time()){
		$ws_close=$ws->close();
		$ws_close && $ws_monitor=array();
	}
	if($ws->is_construct){
		if($ws_monitor['ws_time']+3600*12+300<time()){
			unset($ws);
			$ws_monitor=array();
		}else{
			$data=$ws->recv();
			$data['playload']=json_decode($data['playload'], true);
			if($data['playload']['e']=='ORDER_TRADE_UPDATE' && $data['playload']['o']['X']!='NEW'){
				$data=array(
					'Symbol'			=>	strtolower(str_replace('USDT', '', $data['playload']['o']['s'])),
					'OrdersId'			=>	db::get_value('orders_list', "BinanceOrdersId='{$data['playload']['o']['i']}'", 'OrdersId'),
					'BinanceOrdersId'	=>	$data['playload']['o']['i'],
					'Data'				=>	array(
												'status'		=>	$data['playload']['o']['X'],
												'avgPrice'		=>	floatval($data['playload']['o']['ap']),
												'executedQty'	=>	floatval($data['playload']['o']['z']),
												'cumQuote'		=>	floatval(sprintf('%01.5f', $data['playload']['o']['ap']*$data['playload']['o']['z'])),
												'fee'			=>	floatval($data['playload']['o']['n'])
											),
					'AccTime'			=>	$data['playload']['E'],
					'AccTimeFormat'		=>	date('Y-m-d H:i:s', floor($data['playload']['E']/1000))
				);
				$data['Data']=json_encode($data['Data']);
				db::insert('orders_trade_update', $data);
			}
		}
	}
	usleep(10000);
}




