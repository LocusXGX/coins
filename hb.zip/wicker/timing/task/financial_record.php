<?php
PHP_SAPI!='cli' && exit;
include(dirname(__FILE__).'/../../inc/global.php');

$lock_name='financial_record';
wicker::check_lock($lock_name, $argv[1]);

$binance=new binance();
$swap_financial_record=$binance->swap_financial_record();

foreach((array)$swap_financial_record['msg'] as $v){
	$time=intval($v['time']/1000);
	$symbol=strtolower(str_replace('USDT', '', $v['symbol']));
	$orders_row=db::get_one('orders', "Symbol='$symbol' and OrderStatus=0 and AccTime<$time", '*', 'OrdersId asc');
	$w="OrdersId='{$orders_row['OrdersId']}'";
	if(!$orders_row || db::get_row_count('orders_list', "$w and OptCondition=0 and AccTime='$time'")){continue;}
	db::insert('orders_list', array(
			'Symbol'				=>	$symbol,
			'OrdersId'				=>	$orders_row['OrdersId'],
			'PlanPriceTxt'			=>	'',
			'OptCondition'			=>	0,
			'OrderStatus'			=>	5,
			'Profit'				=>	sprintf('%01.5f', $v['income']),
			'CompletedTime'			=>	$time,
			'CompletedTimeFormat'	=>	date('Y-m-d H:i:s',$time),
			'AccTime'				=>	$time,
			'AccTimeFormat'			=>	date('Y-m-d H:i:s',$time)
		)
	);
	db::update('orders', $w, array('Profit'=>sprintf('%01.5f', db::get_sum('orders_list', $w, 'Profit'))));
}

wicker::update_profit();
wicker::update_config($lock_name, 0);

