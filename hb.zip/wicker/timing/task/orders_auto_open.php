<?php
PHP_SAPI!='cli' && exit;
include(dirname(__FILE__).'/../../inc/global.php');

$lock_name='orders_auto_open';
wicker::check_lock($lock_name, $argv[1]);

if($c['binance']['is_debug']==0){
	$binance=new binance();
	$auto_open_row=db::get_all('orders_auto_open', 'OpenStatus=0', '*', 'OpenId asc');
	foreach($auto_open_row as $v){
		$open_config=json_decode($v['OpenConfig'], true);
		if(
			db::get_row_count('orders', "OrderStatus=0 and Symbol='{$v['Symbol']}' and PositionSide='{$open_config['auto_open_position_side']}'") ||
			($open_config['auto_open_is_loop']==1 && db::get_row_count('orders', "OpenId='{$v['OpenId']}' and FloatProfit<10"))
		){continue;}
		if($open_config['auto_open_price_type']==0){
			$open_price=sprintf($c['market']['price_precision'][$v['Symbol']], $open_config['auto_open_price']);
		}else{
			$open_price=wicker::get_reference_price($v['Symbol'], str_replace("{$open_config['auto_open_position_side']}_", '', $v['Identification']));
		}
		if(
			$open_price<=0 ||
			($open_config['auto_open_position_side']=='LONG' && $c['market']['ticker_price'][$v['Symbol']]>$open_price) ||
			($open_config['auto_open_position_side']=='SHORT' && $c['market']['ticker_price'][$v['Symbol']]<$open_price)
		){continue;}
		
		$position_side=$open_config['auto_open_position_side'];
		$side=$position_side=='LONG'?'BUY':'SELL';
		$place_price=wicker::place_order_price($position_side=='LONG'?$open_price*1.01:$open_price*0.99, $v['Symbol'], $side);
		$volume=wicker::place_order_volume($open_config['auto_open_amout']/$c['market']['ticker_price'][$v['Symbol']], $v['Symbol']);
		$swap_order=$binance->swap_order($v['Symbol'], $place_price, $volume, $side, $position_side);
		if($swap_order['ret']!=1){
			wicker::orders_auto_open_logs($v['Symbol'], $position_side, $swap_order['msg']['msg']);
			continue;
		}
		
		$default_set=in_array($v['Symbol'], $c['binance']['main_symbol'])?$c['binance']['default_set_main']:$c['binance']['default_set'];
		$open_config['auto_open_stop_win_percent']==0 && $open_config['auto_open_stop_win_percent']=$default_set['win_loss_percent'][0];
		$open_config['auto_open_stop_loss_percent']==0 && $open_config['auto_open_stop_loss_percent']=$default_set['win_loss_percent'][1];
		$set_stop_win_percent=$open_config['auto_open_stop_win_percent'];
		$set_stop_win_price=intval($open_config['auto_open_amout']*$set_stop_win_percent/100);
		$set_stop_loss_percent=$open_config['auto_open_stop_loss_percent'];
		$set_stop_loss_price=max(intval($open_config['auto_open_amout']*$set_stop_loss_percent/100), $c['binance']['price_list'][0]);
		in_array($set_stop_win_price, $c['binance']['price_list'])?$set_stop_win_percent=0:$set_stop_win_price=0;
		in_array($set_stop_loss_price, $c['binance']['price_list'])?$set_stop_loss_percent=0:$set_stop_loss_price=0;
		
		$symbol_config=array(
			'price_precision'		=>	$c['market']['price_precision'][$v['Symbol']],
			'quantity_precision'	=>	$c['market']['quantity_precision'][$v['Symbol']]
		);
		$set_config=array(
			'set_stop_win_percent'		=>	$set_stop_win_percent,
			'set_stop_win_price'		=>	$set_stop_win_price,
			'set_stop_win_ticker_price'	=>	'',
			'set_float_win_percent'		=>	0,
			'set_float_win_price'		=>	0,
			'set_float_win_ticker_price'=>	'',
			'set_stop_loss_percent'		=>	$set_stop_loss_percent,
			'set_stop_loss_price'		=>	$set_stop_loss_price,
			'set_stop_loss_ticker_price'=>	'',
			'set_cut_stock'				=>	(int)$default_set['open_set']['cut_stock']?$open_config['auto_open_amout']:0,
			'set_reset_plan'			=>	(int)$default_set['open_set']['reset_plan'],
			'set_update_time'			=>	0
		);
		db::insert('orders', array(
				'OpenId'				=>	$v['OpenId'],
				'Symbol'				=>	$v['Symbol'],
				'SymbolConfig'			=>	json_encode($symbol_config),
				'SetConfig'				=>	json_encode($set_config),
				'OpenPrice'				=>	$c['market']['ticker_price'][$v['Symbol']],
				'OpenAmount'			=>	$open_config['auto_open_amout'],
				'CostPrice'				=>	$c['market']['ticker_price'][$v['Symbol']],
				'PositionSide'			=>	$position_side,
				'Side'					=>	$side,
				'AccTime'				=>	$c['time'],
				'AccTimeFormat'			=>	$c['time_format'],
				'CompletedTime'			=>	$c['time'],
				'CompletedTimeFormat'	=>	$c['time_format']
			)
		);
		$OrdersId=db::get_insert_id();
		(int)$open_config['auto_open_set_plan'] && wicker::plan_quick_set($OrdersId);
		db::insert('orders_list', array(
				'Symbol'				=>	$v['Symbol'],
				'OrdersId'				=>	$OrdersId,
				'PlanPriceTxt'			=>	'',
				'BinanceOrdersId'		=>	$swap_order['msg']['orderId'],
				'TriggerPrice'			=>	$c['market']['ticker_price'][$v['Symbol']],
				'PendingPrice'			=>	$place_price,
				'PendingRealPrice'		=>	$place_price,
				'Volume'				=>	$volume,
				'Amount'				=>	$open_config['auto_open_amout'],
				'StopWin'				=>	0,
				'Side'					=>	$side,
				'PositionSide'			=>	$position_side,
				'OptCondition'			=>	7,
				'AccTime'				=>	$c['time'],
				'AccTimeFormat'			=>	$c['time_format'],
				'CompletedTime'			=>	$c['time'],
				'CompletedTimeFormat'	=>	$c['time_format']
			)
		);
		db::update('orders_auto_open', "OpenId='{$v['OpenId']}'", array(
				'OpenStatus'		=>	$open_config['auto_open_is_loop']==1?0:1,
				'OpenRunCount'		=>	$v['OpenRunCount']+1,
				'OpenRunTime'		=>	$c['time'],
				'OpenRunTimeFormat'	=>	$c['time_format']
			)
		);
	}
}
wicker::update_config($lock_name, 0);





