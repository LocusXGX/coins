<?php
PHP_SAPI!='cli' && exit;
include(dirname(__FILE__).'/../../inc/global.php');

$lock_name='orders_monitor';
wicker::check_lock($lock_name, $argv[1]);
$binance=new binance();

$all_orders_row=db::get_all('orders', 'OrderStatus=0', '*', 'OrdersId desc');
foreach($all_orders_row as $orders_row){
	//-------------------------------------------------------------------------------------------初始数据-------------------------------------------------------------------------------------------
	$c['logs']='';
	$c['time']=time();
	$set_config=json_decode($orders_row['SetConfig'], true);
	$ticker_price=$c['market']['ticker_price'][$orders_row['Symbol']];
	$price_precision=$c['market']['price_precision'][$orders_row['Symbol']];
	$price_pending=sprintf($price_precision, $ticker_price*($c['binance']['price_pending']/100));
	$default_set=in_array($orders_row['Symbol'], $c['binance']['main_symbol'])?$c['binance']['default_set_main']:$c['binance']['default_set'];
	if($orders_row['OpenPrice']<=0 || $ticker_price<=0 || $c['market']['get_ticker_price_time']+5*1000<$c['microtime']){
		wicker::orders_monitor_logs($orders_row['Symbol'], $orders_row['PositionSide'], '【行情数据不正确】');
		continue;
	}
	
	//-------------------------------------------------------------------------------------------持仓数据-------------------------------------------------------------------------------------------
	$opt_condition=0;
	$orders_volume=sprintf($c['market']['quantity_precision'][$orders_row['Symbol']], $orders_row['OpenVolume']-$orders_row['CloseVolume']);
	$orders_profit_usdt=($orders_row['PositionSide']=='LONG'?($ticker_price-$orders_row['OpenPrice']):($orders_row['OpenPrice']-$ticker_price))*$orders_volume;
	$orders_profit_usdt=$orders_profit_usdt+$orders_row['Profit']+$orders_row['Fee'];
	$orders_hold_usdt=round($orders_volume*$orders_row['CostPrice']/$c['binance']['price_modulo'])*$c['binance']['price_modulo'];
	$share_price=@sprintf('%01.10f', ($orders_row['Profit']+$orders_row['Fee'])/$orders_volume);
	$cost_price=str::number_format(sprintf($price_precision, $orders_row['PositionSide']=='LONG'?$orders_row['OpenPrice']-$share_price:$orders_row['OpenPrice']+$share_price));	//保本价格
	$cost_price_percent=@sprintf('%01.2f', ($orders_row['PositionSide']=='LONG'?($ticker_price-$cost_price):($cost_price-$ticker_price))/$cost_price*100);
	$close_out=str::number_format(@sprintf($price_precision, ($orders_row['PositionSide']=='LONG'?($cost_price-$c['binance']['close_out']/$orders_volume):($cost_price+$c['binance']['close_out']/$orders_volume))));	//强平价格
	$close_out_percent=@sprintf('%01.2f', abs($close_out-$ticker_price)/$ticker_price*100);
	$side=$orders_row['PositionSide']=='LONG'?'SELL':'BUY';
	$position_side=$orders_row['PositionSide'];
	if($orders_volume>0){
		$orders_data=array();
		sprintf('%01.5f', $orders_profit_usdt)!=sprintf('%01.5f', $orders_row['FloatProfit']) && $orders_data['FloatProfit']=sprintf('%01.5f', $orders_profit_usdt);
		sprintf($price_precision, $cost_price)!=sprintf($price_precision, $orders_row['CostPrice']) && $orders_data['CostPrice']=sprintf($price_precision, $cost_price);
		sprintf('%01.5f', $orders_profit_usdt)>sprintf('%01.5f', $orders_row['MaxWinPrice']) && $orders_data['MaxWinPrice']=sprintf('%01.5f', $orders_profit_usdt);
		sprintf('%01.5f', $orders_profit_usdt)<sprintf('%01.5f', $orders_row['MaxLossPrice']) && $orders_data['MaxLossPrice']=sprintf('%01.5f', $orders_profit_usdt);
		($ticker_price>$orders_row['MonitorMaxPrice'] || $orders_row['MonitorMaxPrice']==0) && $orders_data['MonitorMaxPrice']=$ticker_price;
		($ticker_price<$orders_row['MonitorMinPrice'] || $orders_row['MonitorMinPrice']==0) && $orders_data['MonitorMinPrice']=$ticker_price;
		$orders_data && db::update('orders', "OrdersId='{$orders_row['OrdersId']}'", $orders_data);
		if($default_set['float_win_set'][0]>0 && $cost_price_percent>$default_set['float_win_set'][0] && $set_config['set_float_win_percent']==0){	//浮盈
			wicker::update_orders_config($orders_row['OrdersId'], 'set_float_win_percent', $default_set['float_win_set'][1]);
		}
		if($default_set['win_percent_reset'][0]<0 && $default_set['win_percent_reset'][1]>0 && $cost_price_percent<$default_set['win_percent_reset'][0] && $set_config['set_stop_win_percent']!=$default_set['win_percent_reset'][1]){	//止盈点数重置
			$orders_cancelall=wicker::orders_cancelall($orders_row['OrdersId']);
			!$orders_cancelall['ret'] && wicker::orders_monitor_logs($orders_row['Symbol'], $orders_row['PositionSide'], "【撤单失败：{$orders_cancelall['msg']['msg']}】");
			wicker::update_orders_config($orders_row['OrdersId'], 'set_stop_win_percent', $default_set['win_percent_reset'][1]);
			wicker::update_orders_config($orders_row['OrdersId'], 'set_stop_win_price', 0);
			continue;
		}
	}
	
	$c['logs'].=sprintf("【持仓：<font class='%s'>%s，%s个，%sU</font>】【盈亏：<font class='%s'>%s</font>】\n",
		$orders_row['PositionSide']=='LONG'?'fc_green':'fc_red',
		$c['order_position_side'][$orders_row['PositionSide']],
		str::number_format($orders_volume),
		$orders_hold_usdt,
		$orders_profit_usdt>=0?'fc_green':'fc_red',
		sprintf('%01.2f', $orders_profit_usdt)
	);
	$logs_item=array(sprintf("【保本：<font class='%s'>%s</font>】", ($cost_price_percent>=0 || $cost_price<=0)?'fc_green':'fc_red', $orders_volume>0?$cost_price.'，'.$cost_price_percent.'%':'∞'));
	$c['binance']['close_out']>0 && $logs_item[]=sprintf("【强平：<font class='%s'>%s</font>】", ($close_out_percent>0.5 || $close_out_percent<0 || $orders_volume<=0)?'fc_green':'fc_red', $orders_volume>0?$close_out.'，'.$close_out_percent.'%':'∞');
	if($set_config['set_stop_win_percent']>0 || $set_config['set_stop_win_price']>0 || $set_config['set_stop_win_ticker_price']>0){
		if($orders_volume>0){
			$stop_win_price_ary=array(
				$set_config['set_stop_win_percent']>0?($orders_row['PositionSide']=='LONG'?$cost_price*(1+$set_config['set_stop_win_percent']/100):$cost_price*(1-$set_config['set_stop_win_percent']/100)):0,
				$set_config['set_stop_win_price']>0?($orders_row['PositionSide']=='LONG'?$cost_price+$set_config['set_stop_win_price']/$orders_volume:$cost_price-$set_config['set_stop_win_price']/$orders_volume):0,
				$set_config['set_stop_win_ticker_price']
			);
			$stop_win_price_ary=array_filter($stop_win_price_ary);
			$stop_win_price=$orders_row['PositionSide']=='LONG'?min($stop_win_price_ary):max($stop_win_price_ary);
			array_search($stop_win_price, $stop_win_price_ary)<=1 && $stop_win_price*=$orders_row['PositionSide']=='LONG'?1+$c['binance']['trade_fee'][0]:1-$c['binance']['trade_fee'][0];	//不是直接指定价格的
			$stop_win_price=str::number_format(sprintf($price_precision, $stop_win_price));
			$stop_win_price==$cost_price && $stop_win_price=str::number_format(sprintf($price_precision, $orders_row['PositionSide']=='LONG'?$stop_win_price+$c['market']['tick_zize'][$orders_row['Symbol']]:$stop_win_price-$c['market']['tick_zize'][$orders_row['Symbol']]));
		}else{
			$stop_win_price='∞';
		}
		$logs_item_tmp=array();
		$set_config['set_stop_win_percent']>0 && $logs_item_tmp[]=$set_config['set_stop_win_percent'].'%';
		$set_config['set_stop_win_price']>0 && $logs_item_tmp[]=$set_config['set_stop_win_price'].'U';
		$set_config['set_stop_win_ticker_price']>0 && $logs_item_tmp[]='$'.$set_config['set_stop_win_ticker_price'];
		$logs_item[]=sprintf("【止盈：%s，%s】", implode('-', $logs_item_tmp), $stop_win_price);
	}
	if($set_config['set_float_win_percent']>0 || $set_config['set_float_win_price']>0 || $set_config['set_float_win_ticker_price']>0){
		if($orders_volume>0){
			$float_win_price_ary=array(
				$set_config['set_float_win_percent']>0?($orders_row['PositionSide']=='LONG'?$cost_price*(1+$set_config['set_float_win_percent']/100):$cost_price*(1-$set_config['set_float_win_percent']/100)):0,
				$set_config['set_float_win_price']>0?($orders_row['PositionSide']=='LONG'?$cost_price+$set_config['set_float_win_price']/$orders_volume:$cost_price-$set_config['set_float_win_price']/$orders_volume):0,
				$set_config['set_float_win_ticker_price']
			);
			$float_win_price_ary=array_filter($float_win_price_ary);
			$float_win_price=str::number_format(sprintf($price_precision, $orders_row['PositionSide']=='LONG'?min($float_win_price_ary):max($float_win_price_ary)));
		}else{
			$float_win_price='∞';
		}
		$logs_item_tmp=array();
		$set_config['set_float_win_percent']>0 && $logs_item_tmp[]=$set_config['set_float_win_percent'].'%';
		$set_config['set_float_win_price']>0 && $logs_item_tmp[]=$set_config['set_float_win_price'].'U';
		$set_config['set_float_win_ticker_price']>0 && $logs_item_tmp[]='$'.$set_config['set_float_win_ticker_price'];
		$logs_item[]=sprintf("【浮盈：%s，%s】", implode('-', $logs_item_tmp), $float_win_price);
	}
	if($set_config['set_stop_loss_percent']>0 || $set_config['set_stop_loss_price']>0 || $set_config['set_stop_loss_ticker_price']>0){
		if($orders_volume>0){
			$stop_loss_price_ary=array(
				$set_config['set_stop_loss_percent']>0?($orders_row['PositionSide']=='LONG'?$cost_price*(1-$set_config['set_stop_loss_percent']/100):$cost_price*(1+$set_config['set_stop_loss_percent']/100)):0,
				$set_config['set_stop_loss_price']>0?($orders_row['PositionSide']=='LONG'?$cost_price-$set_config['set_stop_loss_price']/$orders_volume:$cost_price+$set_config['set_stop_loss_price']/$orders_volume):0,
				$set_config['set_stop_loss_ticker_price']
			);
			$stop_loss_price_ary=array_filter($stop_loss_price_ary);
			$stop_loss_price=str::number_format(sprintf($price_precision, $orders_row['PositionSide']=='LONG'?max($stop_loss_price_ary):min($stop_loss_price_ary)));
		}else{
			$stop_loss_price='∞';
		}
		$logs_item_tmp=array();
		$set_config['set_stop_loss_percent']>0 && $logs_item_tmp[]=$set_config['set_stop_loss_percent'].'%';
		$set_config['set_stop_loss_price']>0 && $logs_item_tmp[]=$set_config['set_stop_loss_price'].'U';
		$set_config['set_stop_loss_ticker_price']>0 && $logs_item_tmp[]='$'.$set_config['set_stop_loss_ticker_price'];
		$logs_item[]=sprintf("【止损：%s，%s】", implode('-', $logs_item_tmp), $stop_loss_price);
	}
	$set_config['set_cut_stock']>0 && $logs_item[]=sprintf("【持仓：%sU，计划重置：%s】", $set_config['set_cut_stock'], $c['n_y'][(int)$set_config['set_reset_plan']]);
	foreach($logs_item as $k=>$v){
		$c['logs'].=$v;
		($k && ($k+1)%2==0) && $c['logs'].="\n";
	}
	$c['logs'].=count($logs_item)%2==1?"\n":'';
	$c['logs'].="\n";
	
	if($orders_volume>0){
		if($c['binance']['close_out']>0 && $orders_profit_usdt<-$c['binance']['close_out']){	//强平
			$opt_condition=1;
		}elseif(	//止损
			$cost_price>0 &&
			($set_config['set_stop_loss_percent']>0 || $set_config['set_stop_loss_price']>0 || $set_config['set_stop_loss_ticker_price']>0) &&
			(($orders_row['PositionSide']=='LONG' && $ticker_price<=$stop_loss_price) || ($orders_row['PositionSide']=='SHORT' && $ticker_price>=$stop_loss_price))
		){
			$opt_condition=2;
		}elseif(	//浮盈
			$cost_price>0 &&
			($set_config['set_float_win_percent']>0 || $set_config['set_float_win_price']>0 || $set_config['set_float_win_ticker_price']>0) &&
			(($orders_row['PositionSide']=='LONG' && $ticker_price<=$float_win_price) || ($orders_row['PositionSide']=='SHORT' && $ticker_price>=$float_win_price))
		){
			$opt_condition=3;
		}elseif(	//减仓
			$set_config['set_cut_stock']>0 &&
			$orders_hold_usdt>$set_config['set_cut_stock']*1.05 &&
			$orders_volume>$set_config['set_cut_stock']/$orders_row['OpenPrice'] &&
			(
				($orders_row['PositionSide']=='LONG' && $ticker_price>=$cost_price-$price_pending) ||
				($orders_row['PositionSide']=='SHORT' && $ticker_price<=$cost_price+$price_pending)
			)
		){
			$opt_condition=4;
			$pending_price=$cost_price;
			$orders_volume=$orders_volume-$set_config['set_cut_stock']/$orders_row['OpenPrice'];
		}elseif(	//止盈
			($set_config['set_stop_win_percent']>0 || $set_config['set_stop_win_price']>0 || $set_config['set_stop_win_ticker_price']>0) &&
			(($orders_row['PositionSide']=='LONG' && $ticker_price>=$stop_win_price-$price_pending) || ($orders_row['PositionSide']=='SHORT' && $ticker_price<=$stop_win_price+$price_pending)) &&
			!db::get_row_count('orders_list', "OrdersId='{$orders_row['OrdersId']}' and OrderStatus<5 and OptCondition in(6,10) and ((PositionSide='LONG' and Side='SELL' and PendingPrice<$stop_win_price) or (PositionSide='SHORT' and Side='BUY' and PendingPrice>$stop_win_price))")
		){
			$opt_condition=5;
			$pending_price=$stop_win_price;
		}
		if($opt_condition==0 && !db::get_row_count('orders_list', "OrdersId='{$orders_row['OrdersId']}' and OrderStatus<5 and OptCondition in(1,2,3,4,5)")){
			$pending_close_volume=db::get_sum('orders_list', "OrdersId='{$orders_row['OrdersId']}' and OrderStatus<5 and ((PositionSide='LONG' and Side='SELL') or (PositionSide='SHORT' and Side='BUY'))", 'Volume');
			$pending_close_volume=sprintf($c['market']['quantity_precision'][$orders_row['Symbol']], $pending_close_volume);
			$plan_data=array();
			$plan_row=db::get_all('plan', "OrdersId='{$orders_row['OrdersId']}' and Status=0 and (FromPlanId>0 or AccTime+2<{$c['time']})", '*', 'PlanType desc,PlanId asc');
			foreach($plan_row as $v){
				$plan_side=(($orders_row['PositionSide']=='LONG' && $v['PlanType']==0) || ($orders_row['PositionSide']=='SHORT' && $v['PlanType']==1))?'BUY':'SELL';
				$PlanId=$v['PlanId'];
				if($v['VolumeType']==2){
					$v['Volume']=$orders_volume*$v['Volume'];
					$v['VolumeType']=1;
				}
				$price=$v['PriceTxt']==''?$v['Price']:wicker::get_reference_price($orders_row['Symbol'], $v['PriceTxt']);
				if($price<=0){continue;}
				if($v['PlanType']==0){
					$plan_volume=$v['VolumeType']==0?$v['Volume']/$price:$v['Volume'];
				}else{
					$plan_volume=min($orders_volume-$pending_close_volume-$c['market']['step_size'][$orders_row['Symbol']], $v['VolumeType']==0?$v['Volume']/$price:$v['Volume']);
					if($plan_volume<=0){continue;}
				}
				$plan_volume=wicker::place_order_volume($plan_volume, $orders_row['Symbol'], $price);
				$limit_order_condition=array(
					'LONG_BUY'	=>	($orders_row['PositionSide']=='LONG' && $v['PlanType']==0 && $v['PriceType']==0)?1:0,	//做多，加仓
					'LONG_SELL'	=>	($orders_row['PositionSide']=='LONG' && $v['PlanType']==1 && $v['PriceType']==1)?1:0,	//做多，减仓
					'SHORT_SELL'=>	($orders_row['PositionSide']=='SHORT' && $v['PlanType']==0 && $v['PriceType']==1)?1:0,	//做空，加仓
					'SHORT_BUY'	=>	($orders_row['PositionSide']=='SHORT' && $v['PlanType']==1 && $v['PriceType']==0)?1:0	//做空，减仓
				);
				if($v['Price']>0 && array_sum($limit_order_condition)){
					if(
						(($limit_order_condition['LONG_BUY'] || $limit_order_condition['SHORT_BUY']) && $ticker_price>=$price) ||
						(($limit_order_condition['LONG_SELL'] || $limit_order_condition['SHORT_SELL']) && $ticker_price<=$price)
					){
						$plan_price=wicker::place_order_price($plan_side=='BUY'?$ticker_price*1.01:$ticker_price*0.99, $orders_row['Symbol'], $plan_side);
						if($v['PlanType']==0){
							$plan_data[]=array(
								'side'				=>	$plan_side,
								'position_side'		=>	$orders_row['PositionSide'],
								'orders_volume'		=>	$plan_volume,
								'place_price'		=>	$plan_price,
								'PendingRealPrice'	=>	$plan_price,
								'PlanRow'			=>	$v
							);
						}else{
							$pending_close_volume+=$plan_volume;
							$plan_data[]=array(
								'side'				=>	$plan_side,
								'position_side'		=>	$orders_row['PositionSide'],
								'orders_volume'		=>	$plan_volume,
								'place_price'		=>	$plan_price,
								'PendingRealPrice'	=>	$plan_price,
								'PlanRow'			=>	$v
							);
						}
					}
				}else{
					$plan_price=$v['IsBatAdd']?wicker::place_order_maker_price($price, $orders_row['Symbol'], $plan_side):wicker::place_order_price($price, $orders_row['Symbol'], $plan_side);
					if(
						($v['PlanType']==0 && $orders_row['PositionSide']=='LONG' && $ticker_price<=$price+$price_pending*$default_set['plan']['pending_multi']) ||
						($v['PlanType']==0 && $orders_row['PositionSide']=='SHORT' && $ticker_price>=$price-$price_pending*$default_set['plan']['pending_multi'])
					){
						$plan_data[]=array(
							'side'				=>	$plan_side,
							'position_side'		=>	$orders_row['PositionSide'],
							'orders_volume'		=>	$plan_volume,
							'place_price'		=>	$plan_price,
							'PendingRealPrice'	=>	$price,
							'PlanRow'			=>	$v
						);
					}elseif(
						($v['PlanType']==1 && $orders_row['PositionSide']=='LONG' && $ticker_price>=$price-$price_pending*$default_set['plan']['pending_multi']) ||
						($v['PlanType']==1 && $orders_row['PositionSide']=='SHORT' && $ticker_price<=$price+$price_pending*$default_set['plan']['pending_multi'])
					){
						$pending_close_volume+=$plan_volume;
						$plan_data[]=array(
							'side'				=>	$plan_side,
							'position_side'		=>	$orders_row['PositionSide'],
							'orders_volume'		=>	$plan_volume,
							'place_price'		=>	$plan_price,
							'PendingRealPrice'	=>	$price,
							'PlanRow'			=>	$v
						);
					}
				}
				if($plan_data && $pending_close_volume>=$orders_volume){continue;}
			}
			$plan_data && $opt_condition=6;
		}
	}
	
	//-------------------------------------------------------------------------------------------挂单处理-------------------------------------------------------------------------------------------
	$all_swap_order_info=$cancel_orders_id=$cancel_ing_orders_id=$orders_data=array();
	$all_pending_row=db::get_all('orders_list l left join plan p on l.PlanId=p.PlanId', "l.OrdersId='{$orders_row['OrdersId']}' and l.OrderStatus<5", 'l.*,p.PriceTxt', 'l.PendingPrice desc,l.ListId asc');
	foreach($all_pending_row as $pending_row){
		$orders_trade_update_row=db::get_one('orders_trade_update', "Symbol='{$pending_row['Symbol']}' and BinanceOrdersId='{$pending_row['BinanceOrdersId']}'", '*', 'AccTime desc,UpdateId desc');
		if($orders_trade_update_row && ($orders_trade_update_row['IsSync']==0 || $pending_row['OrderStatus']==0)){
			$all_swap_order_info['msg'][$pending_row['BinanceOrdersId']]=json_decode($orders_trade_update_row['Data'], true);
			db::update('orders_trade_update', "BinanceOrdersId='{$pending_row['BinanceOrdersId']}' and UpdateId<='{$orders_trade_update_row['UpdateId']}' and IsSync=0", array('IsSync'=>1));
			$need_monitor=1;
		}
	}
	if(!$all_swap_order_info['msg']){
		if(
			$all_pending_row &&
			(
				$orders_row['MonitorTime']+120<$c['time'] ||
				($orders_row['MonitorTime']+5<$c['time'] && wicker::deep_in_array(array(1,2,3,4,5,7,10), array_column($all_pending_row, 'OptCondition'))) ||
				array_sum(array_column($all_pending_row, 'IsCanceling'))
			)
		){
			$need_monitor=1;
		}else{
			$need_monitor=0;
			foreach($all_pending_row as $pending_row){
				if(
					($orders_row['PositionSide']=='LONG' && $pending_row['Side']=='BUY' && $orders_row['MonitorMinPrice']<=$pending_row['PendingPrice']) ||
					($orders_row['PositionSide']=='LONG' && $pending_row['Side']=='SELL' && $orders_row['MonitorMaxPrice']>=$pending_row['PendingPrice']) ||
					($orders_row['PositionSide']=='SHORT' && $pending_row['Side']=='BUY' && $orders_row['MonitorMinPrice']<=$pending_row['PendingPrice']) ||
					($orders_row['PositionSide']=='SHORT' && $pending_row['Side']=='SELL' && $orders_row['MonitorMaxPrice']>=$pending_row['PendingPrice'])
				){
					$need_monitor=1;
					break;
				}
			}
		}
		if($need_monitor){
			$binance_orders_id=array_column($all_pending_row, 'BinanceOrdersId');
			$all_swap_order_info=$binance->swap_all_order_info($orders_row['Symbol'], min($binance_orders_id));
			if($all_swap_order_info['ret']!=1){
				wicker::orders_monitor_logs($orders_row['Symbol'], $orders_row['PositionSide'], "【获取挂单信息失败：{$all_swap_order_info['msg']['msg']}】");
				continue;
			}
			$all_swap_order_info['msg']=array_combine(array_column($all_swap_order_info['msg'], 'orderId'), $all_swap_order_info['msg']);
			db::update('orders', "OrdersId='{$orders_row['OrdersId']}'", array(
					'MonitorTime'		=>	$c['time'],
					'MonitorMaxPrice'	=>	$ticker_price,
					'MonitorMinPrice'	=>	$ticker_price
				)
			);
		}
	}
	foreach($all_pending_row as $pending_row){
		if($orders_row['PositionSide']=='LONG'){
			$w=array("OrdersId='{$pending_row['OrdersId']}'", "OrdersId='{$pending_row['OrdersId']}' and Side='BUY'", "OrdersId='{$pending_row['OrdersId']}' and Side='SELL'");
			$is_open_order=$pending_row['Side']=='BUY';
		}else{
			$w=array("OrdersId='{$pending_row['OrdersId']}'", "OrdersId='{$pending_row['OrdersId']}' and Side='SELL'", "OrdersId='{$pending_row['OrdersId']}' and Side='BUY'");
			$is_open_order=$pending_row['Side']=='SELL';
		}
		$c['logs'].=sprintf("【<font class='%s'>%s，%s</font>，%s，%sU，%s%%，%s秒，<a href='javascript:void(0);' class='cancel_list_orders' rel='%s'>撤单</a>】\n",
			$is_open_order?'fc_red':'fc_green',
			$c['opt_condition'][$pending_row['OptCondition']],
			$c['order_position_side'][$pending_row['PositionSide'].'-'.$pending_row['Side']],
			sprintf($price_precision, $pending_row['PendingPrice']),
			round($pending_row['PendingPrice']*$pending_row['Volume']/$c['binance']['price_modulo'])*$c['binance']['price_modulo'],
			sprintf('%01.2f', abs($ticker_price-$pending_row['PendingPrice'])/$ticker_price*100),
			$c['time']-$pending_row['AccTime'],
			$pending_row['ListId']
		);
		$swap_order_info=$all_swap_order_info['msg'][$pending_row['BinanceOrdersId']];
		if($swap_order_info['status']=='NEW'){	//0=>新订单NEW，4=>部分成交PARTIALLY_FILLED，5=>全部成交FILLED，6=>部分成交已撤单，7=>已撤单CANCELED，8=>订单被拒绝REJECTED，9=>过期订单EXPIRED
			$swap_order_info['status']=0;
		}elseif($swap_order_info['status']=='PARTIALLY_FILLED'){
			$swap_order_info['status']=4;
		}elseif($swap_order_info['status']=='FILLED'){
			$swap_order_info['status']=5;
		}elseif($swap_order_info['status']=='CANCELED'){
			$swap_order_info['status']=$swap_order_info['executedQty']>0?6:7;
		}elseif($swap_order_info['status']=='REJECTED'){
			$swap_order_info['status']=8;
		}elseif($swap_order_info['status']=='EXPIRED'){
			$swap_order_info['status']=9;
		}
		if(
			$pending_row['OptCondition']!=10 &&
			$pending_row['IsCanceling']==0 &&
			(!$swap_order_info || $pending_row['OrderStatus']==$swap_order_info['status']) &&
			$pending_row['AccTime']+5<$c['time'] &&
			(
				($pending_row['OptCondition']!=6 && abs($pending_row['PendingPrice']-$ticker_price)>$price_pending*2) ||
				($pending_row['OptCondition']==6 && $pending_row['PriceTxt']!='' && $pending_row['AccTime']+600<$c['time']) ||
				($pending_row['OptCondition']==6 && abs($pending_row['PendingPrice']-$ticker_price)>$price_pending*($default_set['plan']['pending_multi']+1) && $orders_row['CancelOrdersTime']+60<$c['time']) ||
				($pending_row['OptCondition']==6 && abs($pending_row['PendingPrice']-$ticker_price)>$price_pending && $swap_order_info['status']==4) ||
				(
					sprintf($price_precision, $pending_row['PendingPrice'])!=sprintf($price_precision, $pending_row['PendingRealPrice']) &&
					abs($pending_row['PendingPrice']-$ticker_price)>$c['market']['tick_zize'][$orders_row['Symbol']]*2
				)
			)
		){
			$cancel_orders_id[]=$pending_row['BinanceOrdersId'];
		}else{
			if(!$need_monitor || !$swap_order_info){continue;}
			$trade_fee=sprintf($price_precision, $pending_row['PendingPrice'])==sprintf($price_precision, $swap_order_info['avgPrice'])?$c['binance']['trade_fee'][0]:$c['binance']['trade_fee'][1];
			$orders_list_data=array(
				'TradePrice'			=>	sprintf($price_precision, $swap_order_info['avgPrice']),
				'TradeVolume'			=>	$swap_order_info['executedQty'],
				'TradeTurnover'			=>	$swap_order_info['cumQuote'],
				'OrderStatus'			=>	$swap_order_info['status'],
				'Fee'					=>	-$swap_order_info['cumQuote']*$trade_fee,
				'IsCanceling'			=>	$swap_order_info['status']>=5?0:$pending_row['IsCanceling'],
				'CompletedTime'			=>	$c['time'],
				'CompletedTimeFormat'	=>	$c['time_format']
			);
			$orders_list_data['IsCanceling'] && $cancel_ing_orders_id[]=$pending_row['ListId'];
			if(!$is_open_order && in_array($swap_order_info['status'], array(5,6))){
				if($orders_row['PositionSide']=='LONG'){
					$orders_list_data['Profit']=($swap_order_info['avgPrice']-$orders_row['OpenPrice'])*$swap_order_info['executedQty'];
				}else{
					$orders_list_data['Profit']=($orders_row['OpenPrice']-$swap_order_info['avgPrice'])*$swap_order_info['executedQty'];
				}
				$orders_list_data['Profit']=sprintf('%01.15f', $orders_list_data['Profit']);
			}
			db::update('orders_list', "ListId='{$pending_row['ListId']}'", $orders_list_data);
			if($pending_row['OrderStatus']==$swap_order_info['status']){continue;}
			if($swap_order_info['status']>=5){
				$open_volume=sprintf($c['market']['quantity_precision'][$orders_row['Symbol']], db::get_sum('orders_list', $w[1], 'TradeVolume'));
				$close_volume=sprintf($c['market']['quantity_precision'][$orders_row['Symbol']], db::get_sum('orders_list', $w[2], 'TradeVolume'));
				$profit=sprintf('%01.5f', db::get_sum('orders_list', $w[0], 'Profit'));
				$fee=sprintf('%01.5f', db::get_sum('orders_list', $w[0], 'Fee'));
				$orders_data=array(
					'OpenVolume'			=>	$open_volume,
					'CloseVolume'			=>	$close_volume,
					'Profit'				=>	$profit,
					'Fee'					=>	$fee,
					'CompletedTime'			=>	$c['time'],
					'CompletedTimeFormat'	=>	$c['time_format']
				);
				if(($open_volume>0 && $open_volume==$close_volume) || $open_volume+$close_volume==0){
					if(db::get_row_count('orders_list', "{$w[0]} and OrderStatus<5")){
						$orders_cancelall=wicker::orders_cancelall($orders_row['OrdersId'], 6);
						!$orders_cancelall['ret'] && wicker::orders_monitor_logs($orders_row['Symbol'], $orders_row['PositionSide'], "【撤单失败：{$orders_cancelall['msg']['msg']}】");
						continue 2;
					}elseif($open_volume>0 && $open_volume==$close_volume){
						$orders_data['CostPrice']=$orders_row['OpenPrice'];
						$orders_data['OrderStatus']=1;
						$orders_data['FloatProfit']=sprintf('%01.5f', $profit+$fee);
					}elseif($open_volume+$close_volume==0){
						$orders_data['OrderStatus']=2;
					}
					db::query("replace into orders_list_history select * from orders_list where {$w[0]} and OrderStatus!=7 order by ListId asc");
					foreach(array('plan', 'orders_list', 'orders_trade_update') as $tb){
						db::delete($tb, $w[0]);
						db::query("optimize table $tb");
					}
				}
				if(in_array($swap_order_info['status'], array(5,6))){
					if($is_open_order){
						$account_info=$binance->account();
						if($account_info['ret']!=1){
							wicker::orders_monitor_logs($orders_row['Symbol'], $orders_row['PositionSide'], "【获取仓位信息失败：{$account_info['msg']['msg']}】");
							continue 2;
						}
						foreach($account_info['msg']['positions'] as $v){
							if($v['positionSide']==$orders_row['PositionSide'] && $v['symbol']==strtoupper($orders_row['Symbol']).'USDT' && $v['entryPrice']>0){
								$orders_data['OpenPrice']=$v['entryPrice'];
								break;
							}
						}
					}
					$plan_base_data=array(
						'Symbol'				=>	$orders_row['Symbol'],
						'OrdersId'				=>	$orders_row['OrdersId'],
						'VolumeType'			=>	1,
						'AccTime'				=>	$c['time'],
						'AccTimeFormat'			=>	$c['time_format'],
						'CompletedTime'			=>	$c['time'],
						'CompletedTimeFormat'	=>	$c['time_format']
					);
					if($pending_row['OptCondition']==2 && $set_config['set_reset_plan']==1){
						wicker::plan_quick_set($orders_row['OrdersId']);
					}elseif($pending_row['StopWin']>0){
						if($is_open_order){
							$plan_type=1;
							$plan_price=$orders_list_data['TradePrice']*($orders_row['PositionSide']=='LONG'?(1+$pending_row['StopWin']/100):(1-$pending_row['StopWin']/100));
							$plan_price_type=$orders_row['PositionSide']=='LONG'?0:1;
						}else{
							$plan_type=0;
							$plan_price=$orders_list_data['TradePrice']*($orders_row['PositionSide']=='SHORT'?(1+$pending_row['StopWin']/100):(1-$pending_row['StopWin']/100));
							$plan_price_type=$orders_row['PositionSide']=='SHORT'?0:1;
						}
						db::insert('plan', array_merge($plan_base_data, array(
									'PlanType'		=>	$plan_type,
									'FromListId'	=>	$pending_row['ListId'],
									'IsBatAdd'		=>	$pending_row['PlanIsBatAdd'],
									'Price'			=>	$plan_price,
									'PriceType'		=>	$plan_price_type,
									//'Volume'		=>	$pending_row['Amount'],
									//'Amount'		=>	$pending_row['Amount']
									'Volume'		=>	$orders_list_data['TradeVolume'],
									'Amount'		=>	$orders_list_data['TradeTurnover']
								)
							)
						);
					}elseif($pending_row['OptCondition']==6){
						$plan_row=db::get_one('plan', "PlanId='{$pending_row['PlanId']}'");
						!db::get_row_count('orders_list', "PlanId='{$plan_row['PlanId']}' and OrderStatus<5") && db::update('plan', "PlanId='{$plan_row['PlanId']}'", array('Status'=>$plan_row['IsLoop']==1?2:3));
						if($plan_row['FromPlanId']){
							$from_plan_row=db::get_one('plan', "PlanId='{$plan_row['FromPlanId']}'");
							db::update('plan', "PlanId='{$plan_row['FromPlanId']}'", array(
									'Status'	=>	($from_plan_row['ClosePercent']>0 && $from_plan_row['IsLoop']==1)?0:3,
									'RunCount'	=>	$from_plan_row['RunCount']+1
								)
							);
							if(!$is_open_order && $from_plan_row['PlanType']==0){
								$orders_data['PlanRunCountAdd']=db::get_value('orders', $w[0], 'PlanRunCountAdd')+1;
							}elseif($is_open_order && $from_plan_row['PlanType']==1){
								$orders_data['PlanRunCountCut']=db::get_value('orders', $w[0], 'PlanRunCountCut')+1;
							}
						}elseif($plan_row['ClosePercent']>0){
							$plan_row['Price']==0 && $plan_row['Price']=$orders_list_data['TradePrice'];
							if($plan_row['PlanType']==0){
								$plan_type=1;
								$plan_price=sprintf($price_precision, $orders_row['PositionSide']=='LONG'?$plan_row['Price']*(1+$plan_row['ClosePercent']/100):$plan_row['Price']*(1-$plan_row['ClosePercent']/100));
							}else{
								$plan_type=0;
								$plan_price=sprintf($price_precision, $orders_row['PositionSide']=='LONG'?$plan_row['Price']*(1-$plan_row['ClosePercent']/100):$plan_row['Price']*(1+$plan_row['ClosePercent']/100));
							}
							db::lock('plan write');
							!db::get_row_count('plan', "FromListId='{$pending_row['ListId']}'") && db::insert('plan', array_merge($plan_base_data, array(
										'PlanType'	=>	$plan_type,
										'FromPlanId'=>	$plan_row['PlanId'],
										'FromListId'=>	$pending_row['ListId'],
										'IsBatAdd'	=>	$pending_row['PlanIsBatAdd'],
										'Price'		=>	$plan_price,
										'PriceTxt'	=>	'',
										'PriceType'	=>	$plan_price>=$orders_list_data['TradePrice']?0:1,
										//'Volume'	=>	$swap_order_info['status']==5?$plan_row['Amount']:round($orders_list_data['TradeTurnover']/$c['binance']['price_modulo'])*$c['binance']['price_modulo'],
										//'Amount'	=>	$swap_order_info['status']==5?$plan_row['Amount']:round($orders_list_data['TradeTurnover']/$c['binance']['price_modulo'])*$c['binance']['price_modulo']
										'Volume'	=>	$orders_list_data['TradeVolume'],
										'Amount'	=>	$plan_row['Amount']
									)
								)
							);
							db::unlock();
						}
					}
					$pending_row['PlanIsBatAdd']!=1 && wicker::email($orders_row['Symbol'], sprintf("【%s%s】【%s】【%s】", strtoupper($orders_row['Symbol']), $c['opt_condition'][$pending_row['OptCondition']], $c['order_position_side'][$pending_row['PositionSide'].'-'.$pending_row['Side']], $orders_list_data['TradePrice']), "成交价：{$orders_list_data['TradePrice']}");
				}else{
					$pending_row['OptCondition']==6 && db::update('plan', "PlanId='{$pending_row['PlanId']}'", array('Status'=>0));
				}
				$orders_data && db::update('orders', $w[0], $orders_data);
			}
		}
	}
	if($cancel_orders_id){
		$update_cancel_orders_time=count($cancel_orders_id)>10?0:1;
		$cancel_orders_id=array_slice($cancel_orders_id, 0, 10);
		$swap_cancel_batch=$binance->swap_cancel_batch($orders_row['Symbol'], $cancel_orders_id);
		if($swap_cancel_batch['ret']!=1){
			wicker::orders_monitor_logs($orders_row['Symbol'], $orders_row['PositionSide'], "【撤单失败：{$swap_cancel_batch['msg']['msg']}】");
			continue;
		}
		$cancel_orders_id_list=implode(',', $cancel_orders_id);
		db::update('orders_list', "OrdersId='{$orders_row['OrdersId']}' and BinanceOrdersId in($cancel_orders_id_list)", array('IsCanceling'=>1));
		$update_cancel_orders_time && db::update('orders', "OrdersId='{$orders_row['OrdersId']}'", array('CancelOrdersTime'=>$c['time']));
	}
	if($cancel_orders_id || $cancel_ing_orders_id){
		wicker::orders_monitor_logs($orders_row['Symbol'], $orders_row['PositionSide'], '【挂单撤消中】');
		continue;
	}
	
	//-------------------------------------------------------------------------------------------提交订单-------------------------------------------------------------------------------------------
	if($opt_condition>0 && $orders_data['OrderStatus']==0 && (($opt_condition==6 && count($all_pending_row)<100) || ($opt_condition!=6 && !in_array($opt_condition, array_column($all_pending_row, 'OptCondition'))))){
		if($set_config['set_update_time']+60>$c['time']){
			$t=60-($c['time']-$set_config['set_update_time']);
			wicker::orders_monitor_logs($orders_row['Symbol'], $orders_row['PositionSide'], "【{$c['opt_condition'][$opt_condition]}，倒时：{$t}秒】");
			continue;
		}
		if($c['binance']['is_debug']==1){
			wicker::orders_monitor_logs($orders_row['Symbol'], $orders_row['PositionSide'], "【{$c['opt_condition'][$opt_condition]}，调试模式不能下单】");
			continue;
		}
		if($opt_condition==6){
			foreach($plan_data as $v){
				$swap_order=$binance->swap_order($orders_row['Symbol'], $v['place_price'], $v['orders_volume'], $v['side'], $v['position_side'], $v['PlanRow']['IsBatAdd']?'GTX':'GTC');
				if($swap_order['ret']!=1){
					wicker::orders_monitor_logs($orders_row['Symbol'], $orders_row['PositionSide'], "【{$c['opt_condition'][$opt_condition]}，下单失败：{$swap_order['msg']['msg']}，价格：{$v['place_price']}，数量：{$v['orders_volume']}个】");
					continue 2;
				}
				db::update('plan', "PlanId='{$v['PlanRow']['PlanId']}'", array('Status'=>1));
				db::insert('orders_list', array(
						'Symbol'				=>	$orders_row['Symbol'],
						'OrdersId'				=>	$orders_row['OrdersId'],
						'PlanId'				=>	$v['PlanRow']['PlanId'],
						'PlanPrice'				=>	$v['PlanRow']['Price'],
						'PlanPriceTxt'			=>	$v['PlanRow']['PriceTxt'],
						'PlanPriceType'			=>	$v['PlanRow']['PriceType'],
						'PlanFromPlanId'		=>	$v['PlanRow']['FromPlanId'],
						'PlanFromListId'		=>	$v['PlanRow']['FromListId'],
						'PlanIsBatAdd'			=>	$v['PlanRow']['IsBatAdd'],
						'BinanceOrdersId'		=>	$swap_order['msg']['orderId'],
						'TriggerPrice'			=>	$ticker_price,
						'PendingPrice'			=>	$v['place_price'],
						'PendingRealPrice'		=>	$v['PendingRealPrice'],
						'Volume'				=>	$v['orders_volume'],
						'Amount'				=>	$v['PlanRow']['Amount'],
						'Side'					=>	$v['side'],
						'PositionSide'			=>	$v['position_side'],
						'OptCondition'			=>	$opt_condition,
						'AccTime'				=>	$c['time'],
						'AccTimeFormat'			=>	$c['time_format'],
						'CompletedTime'			=>	$c['time'],
						'CompletedTimeFormat'	=>	$c['time_format']
					)
				);
			}
		}else{
			$orders_cancelall=wicker::orders_cancelall($orders_row['OrdersId']);
			if(!$orders_cancelall['ret']){
				wicker::orders_monitor_logs($orders_row['Symbol'], $orders_row['PositionSide'], "【撤单失败：{$orders_cancelall['msg']['msg']}】");
			}elseif($orders_cancelall['ret']==1){
				continue;
			}
			$place_price=in_array($opt_condition, array(4,5))?$pending_price:($position_side=='SHORT'?$ticker_price*1.01:$ticker_price*0.99);
			$place_price=wicker::place_order_price($place_price, $orders_row['Symbol'], $side);
			$orders_volume=wicker::place_order_volume($orders_volume, $orders_row['Symbol'], $place_price);
			$swap_order=$binance->swap_order($orders_row['Symbol'], $place_price, $orders_volume, $side, $position_side);
			if($swap_order['ret']!=1){
				wicker::orders_monitor_logs($orders_row['Symbol'], $orders_row['PositionSide'], "【{$c['opt_condition'][$opt_condition]}，下单失败：{$swap_order['msg']['msg']}，价格：{$place_price}，数量：{$orders_volume}个】");
				continue;
			}
			db::insert('orders_list', array(
					'Symbol'				=>	$orders_row['Symbol'],
					'OrdersId'				=>	$orders_row['OrdersId'],
					'PlanPriceTxt'			=>	'',
					'BinanceOrdersId'		=>	$swap_order['msg']['orderId'],
					'TriggerPrice'			=>	$ticker_price,
					'PendingPrice'			=>	$place_price,
					'PendingRealPrice'		=>	$pending_price,
					'Volume'				=>	$orders_volume,
					'Amount'				=>	round($ticker_price*$orders_volume/$c['binance']['price_modulo'])*$c['binance']['price_modulo'],
					'Side'					=>	$side,
					'PositionSide'			=>	$position_side,
					'OptCondition'			=>	$opt_condition,
					'AccTime'				=>	$c['time'],
					'AccTimeFormat'			=>	$c['time_format'],
					'CompletedTime'			=>	$c['time'],
					'CompletedTimeFormat'	=>	$c['time_format']
				)
			);
		}
	}
	wicker::orders_monitor_logs($orders_row['Symbol'], $orders_row['PositionSide'], '', $orders_data['OrderStatus']);
}
wicker::update_config($lock_name, 0);








