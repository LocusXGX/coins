<?php
PHP_SAPI!='cli' && exit;
include(dirname(__FILE__).'/../../inc/global.php');

$lock_name='send_email';
wicker::check_lock($lock_name, $argv[1]);

$email_row=db::get_one('email', 'SendStatus=0', '*', 'EmailId asc');
if($email_row){
	db::update('email', "EmailId='{$email_row['EmailId']}'", array('SendStatus'=>1));
	$result=wicker::send_email($c['mail_to'], $email_row['Subject'], $email_row['Contents']);
	db::update('email', "EmailId='{$email_row['EmailId']}'", array('SendStatus'=>$result?2:0));
}
wicker::update_config($lock_name, 0);




