<?php
include('inc/global.php');
wicker::do_action();
?>
<!DOCTYPE HTML>
<html lang="cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="black" />
<meta content="telephone=no" name="format-detection" />
<title>wicker</title>
<link rel='shortcut icon' href='/stc/images/ico.ico' />
<link href='/stc/css/global.css?t=<?=$c['time'];?>' rel='stylesheet' type='text/css' />
<link href='/stc/css/main.css?t=<?=$c['time'];?>' rel='stylesheet' type='text/css' />
<script type='text/javascript' src='/stc/js/jquery-1.10.2.js'></script>
<script type='text/javascript' src='/stc/js/echarts-5.4.0.js'></script>
<script type='text/javascript' src='/stc/js/wicker.js?t=<?=$c['time'];?>'></script>
<script type='text/javascript' src='/stc/js/main.js?t=<?=$c['time'];?>'></script>
<script language="javascript">var query_string='<?=str::query_string();?>'; $(document).ready(main_obj.page_init);</script>
</head>

<body class="<?=!(int)$_SESSION['Binance']['UserId']?'login':'page';?>">
<?php
if(!(int)$_SESSION['Binance']['UserId']){
	include($c['root_path'].'/inc/html/login_form.php');
}else{
	include($c['root_path'].'/inc/html/auto_open_form.php');
	include($c['root_path'].'/inc/html/set_form.php');
	include($c['root_path'].'/inc/html/plan_form.php');
	include($c['root_path'].'/inc/html/profit.php');
	include($c['root_path'].'/inc/html/contents.php');
}
?>
</body>
</html>