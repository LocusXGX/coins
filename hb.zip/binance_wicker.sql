-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 2023-03-07 11:00:59
-- 服务器版本： 5.7.16-log
-- PHP Version: 5.6.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `binance_wicker`
--

-- --------------------------------------------------------

--
-- 表的结构 `config`
--

CREATE TABLE `config` (
  `ConfigId` int(10) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Value` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `email`
--

CREATE TABLE `email` (
  `EmailId` int(10) NOT NULL,
  `Symbol` varchar(5) DEFAULT NULL,
  `Subject` varchar(100) DEFAULT NULL,
  `Contents` varchar(100) DEFAULT NULL,
  `SendStatus` tinyint(1) DEFAULT '0',
  `AccTime` int(10) DEFAULT '0',
  `AccTimeFormat` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `orders`
--

CREATE TABLE `orders` (
  `OrdersId` int(10) NOT NULL,
  `OpenId` int(10) DEFAULT '0',
  `Symbol` varchar(10) DEFAULT NULL,
  `SymbolConfig` varchar(500) DEFAULT NULL,
  `SetConfig` varchar(500) DEFAULT NULL,
  `OpenVolume` decimal(15,5) DEFAULT '0.00000',
  `CloseVolume` decimal(15,5) DEFAULT '0.00000',
  `OpenPrice` decimal(15,8) DEFAULT '0.00000000',
  `OpenAmount` int(10) DEFAULT '0',
  `CostPrice` decimal(15,8) DEFAULT '0.00000000',
  `MonitorTime` int(10) DEFAULT '0',
  `MonitorMaxPrice` decimal(15,8) DEFAULT '0.00000000',
  `MonitorMinPrice` decimal(15,8) DEFAULT '0.00000000',
  `MaxWinPrice` decimal(10,5) DEFAULT '0.00000',
  `MaxLossPrice` decimal(10,5) DEFAULT '0.00000',
  `PositionSide` varchar(5) DEFAULT NULL,
  `Side` varchar(5) DEFAULT NULL,
  `OrderStatus` tinyint(1) DEFAULT '0',
  `PlanRunCountAdd` smallint(5) DEFAULT '0',
  `PlanRunCountCut` smallint(5) DEFAULT '0',
  `FloatProfit` decimal(10,5) DEFAULT '0.00000',
  `Profit` decimal(10,5) DEFAULT '0.00000',
  `Fee` decimal(10,5) DEFAULT '0.00000',
  `GetOpenPriceTime` int(10) DEFAULT '0',
  `CancelOrdersTime` int(10) DEFAULT '0',
  `CompletedTime` int(10) DEFAULT '0',
  `CompletedTimeFormat` varchar(20) DEFAULT NULL,
  `AccTime` int(10) DEFAULT '0',
  `AccTimeFormat` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `orders_auto_open`
--

CREATE TABLE `orders_auto_open` (
  `OpenId` int(10) NOT NULL,
  `Symbol` varchar(10) DEFAULT NULL,
  `Identification` varchar(20) DEFAULT NULL,
  `OpenConfig` varchar(500) DEFAULT NULL,
  `OpenStatus` tinyint(1) DEFAULT '0',
  `OpenRunCount` smallint(5) DEFAULT '0',
  `OpenRunTime` int(10) DEFAULT '0',
  `OpenRunTimeFormat` varchar(20) DEFAULT NULL,
  `AccTime` int(10) DEFAULT '0',
  `AccTimeFormat` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `orders_list`
--

CREATE TABLE `orders_list` (
  `ListId` int(10) NOT NULL,
  `Symbol` varchar(10) DEFAULT NULL,
  `OrdersId` int(10) DEFAULT '0',
  `BinanceOrdersId` bigint(10) DEFAULT '0',
  `PlanId` int(10) DEFAULT '0',
  `PlanPrice` decimal(15,8) DEFAULT '0.00000000',
  `PlanPriceTxt` varchar(20) DEFAULT NULL,
  `PlanPriceType` tinyint(1) DEFAULT '0',
  `PlanFromPlanId` int(10) DEFAULT '0',
  `PlanFromListId` int(10) DEFAULT '0',
  `PlanIsBatAdd` tinyint(1) DEFAULT '0',
  `TriggerPrice` decimal(15,8) DEFAULT '0.00000000',
  `PendingPrice` decimal(15,8) DEFAULT '0.00000000',
  `PendingRealPrice` decimal(15,8) DEFAULT '0.00000000',
  `TradePrice` decimal(15,8) DEFAULT '0.00000000',
  `Volume` decimal(15,5) DEFAULT '0.00000',
  `TradeVolume` decimal(15,5) DEFAULT '0.00000',
  `TradeTurnover` decimal(15,5) DEFAULT '0.00000',
  `Amount` int(10) DEFAULT '0',
  `StopWin` decimal(10,2) DEFAULT '0.00',
  `PositionSide` varchar(5) DEFAULT NULL,
  `Side` varchar(5) DEFAULT NULL,
  `OptCondition` tinyint(1) DEFAULT '0',
  `OrderStatus` tinyint(1) DEFAULT '0',
  `Profit` decimal(20,15) DEFAULT '0.000000000000000',
  `Fee` decimal(15,10) DEFAULT '0.0000000000',
  `IsCanceling` tinyint(1) DEFAULT '0',
  `CompletedTime` int(10) DEFAULT '0',
  `CompletedTimeFormat` varchar(20) DEFAULT NULL,
  `AccTime` int(10) DEFAULT '0',
  `AccTimeFormat` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `orders_list_history`
--

CREATE TABLE `orders_list_history` (
  `ListId` int(10) NOT NULL,
  `Symbol` varchar(10) DEFAULT NULL,
  `OrdersId` int(10) DEFAULT '0',
  `BinanceOrdersId` bigint(10) DEFAULT '0',
  `PlanId` int(10) DEFAULT '0',
  `PlanPrice` decimal(15,8) DEFAULT '0.00000000',
  `PlanPriceTxt` varchar(20) DEFAULT NULL,
  `PlanPriceType` tinyint(1) DEFAULT '0',
  `PlanFromPlanId` int(10) DEFAULT '0',
  `PlanFromListId` int(10) DEFAULT '0',
  `PlanIsBatAdd` tinyint(1) DEFAULT '0',
  `TriggerPrice` decimal(15,8) DEFAULT '0.00000000',
  `PendingPrice` decimal(15,8) DEFAULT '0.00000000',
  `PendingRealPrice` decimal(15,8) DEFAULT '0.00000000',
  `TradePrice` decimal(15,8) DEFAULT '0.00000000',
  `Volume` decimal(15,5) DEFAULT '0.00000',
  `TradeVolume` decimal(15,5) DEFAULT '0.00000',
  `TradeTurnover` decimal(15,5) DEFAULT '0.00000',
  `Amount` int(10) DEFAULT '0',
  `StopWin` decimal(10,2) DEFAULT '0.00',
  `PositionSide` varchar(5) DEFAULT NULL,
  `Side` varchar(5) DEFAULT NULL,
  `OptCondition` tinyint(1) DEFAULT '0',
  `OrderStatus` tinyint(1) DEFAULT '0',
  `Profit` decimal(20,15) DEFAULT '0.000000000000000',
  `Fee` decimal(15,10) DEFAULT '0.0000000000',
  `IsCanceling` tinyint(1) DEFAULT '0',
  `CompletedTime` int(10) DEFAULT '0',
  `CompletedTimeFormat` varchar(20) DEFAULT NULL,
  `AccTime` int(10) DEFAULT '0',
  `AccTimeFormat` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `orders_trade_update`
--

CREATE TABLE `orders_trade_update` (
  `UpdateId` int(10) NOT NULL,
  `Symbol` varchar(10) DEFAULT NULL,
  `OrdersId` int(10) DEFAULT '0',
  `BinanceOrdersId` bigint(10) DEFAULT '0',
  `Data` text,
  `IsSync` tinyint(1) DEFAULT '0',
  `AccTime` bigint(10) DEFAULT '0',
  `AccTimeFormat` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `plan`
--

CREATE TABLE `plan` (
  `PlanId` int(10) NOT NULL,
  `Symbol` varchar(10) DEFAULT NULL,
  `OrdersId` int(10) DEFAULT '0',
  `PlanType` tinyint(1) DEFAULT '0',
  `FromPlanId` int(10) DEFAULT '0',
  `FromListId` int(10) DEFAULT '0',
  `IsBatAdd` tinyint(1) DEFAULT '0',
  `Price` decimal(15,8) DEFAULT '0.00000000',
  `PriceTxt` varchar(20) DEFAULT NULL,
  `PriceType` tinyint(1) NOT NULL DEFAULT '0',
  `Volume` decimal(15,5) DEFAULT '0.00000',
  `VolumeType` tinyint(1) DEFAULT '0',
  `Amount` int(10) DEFAULT '0',
  `ClosePercent` decimal(10,3) DEFAULT '0.000',
  `IsLoop` tinyint(1) DEFAULT '0',
  `RunCount` smallint(10) DEFAULT '0',
  `Status` tinyint(1) DEFAULT '0',
  `AccTime` int(10) DEFAULT '0',
  `AccTimeFormat` varchar(20) DEFAULT NULL,
  `CompletedTime` int(10) DEFAULT '0',
  `CompletedTimeFormat` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `profit_logs`
--

CREATE TABLE `profit_logs` (
  `LogsId` int(10) NOT NULL,
  `Profit` int(10) DEFAULT '0',
  `FloatProfit` int(10) DEFAULT '0',
  `AccTime` int(10) DEFAULT '0',
  `AccTimeFormat` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`ConfigId`),
  ADD KEY `Name` (`Name`);

--
-- Indexes for table `email`
--
ALTER TABLE `email`
  ADD PRIMARY KEY (`EmailId`),
  ADD KEY `Symbol` (`Symbol`),
  ADD KEY `SendStatus` (`SendStatus`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrdersId`),
  ADD KEY `OpenId` (`OpenId`),
  ADD KEY `Symbol` (`Symbol`),
  ADD KEY `OrderStatus` (`OrderStatus`);

--
-- Indexes for table `orders_auto_open`
--
ALTER TABLE `orders_auto_open`
  ADD PRIMARY KEY (`OpenId`),
  ADD KEY `Symbol` (`Symbol`),
  ADD KEY `Identification` (`Identification`),
  ADD KEY `OpenStatus` (`OpenStatus`);

--
-- Indexes for table `orders_list`
--
ALTER TABLE `orders_list`
  ADD PRIMARY KEY (`ListId`),
  ADD KEY `Symbol` (`Symbol`),
  ADD KEY `OrdersId` (`OrdersId`),
  ADD KEY `BinanceOrdersId` (`BinanceOrdersId`),
  ADD KEY `OptCondition` (`OptCondition`),
  ADD KEY `OrderStatus` (`OrderStatus`);

--
-- Indexes for table `orders_list_history`
--
ALTER TABLE `orders_list_history`
  ADD PRIMARY KEY (`ListId`),
  ADD KEY `Symbol` (`Symbol`),
  ADD KEY `OrdersId` (`OrdersId`),
  ADD KEY `BinanceOrdersId` (`BinanceOrdersId`),
  ADD KEY `OptCondition` (`OptCondition`),
  ADD KEY `OrderStatus` (`OrderStatus`);

--
-- Indexes for table `orders_trade_update`
--
ALTER TABLE `orders_trade_update`
  ADD PRIMARY KEY (`UpdateId`),
  ADD KEY `Symbol` (`Symbol`),
  ADD KEY `OrdersId` (`OrdersId`),
  ADD KEY `BinanceOrdersId` (`BinanceOrdersId`);

--
-- Indexes for table `plan`
--
ALTER TABLE `plan`
  ADD PRIMARY KEY (`PlanId`),
  ADD KEY `Symbol` (`Symbol`),
  ADD KEY `OrdersId` (`OrdersId`),
  ADD KEY `PlanType` (`PlanType`);

--
-- Indexes for table `profit_logs`
--
ALTER TABLE `profit_logs`
  ADD PRIMARY KEY (`LogsId`),
  ADD KEY `AccTime` (`AccTime`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `config`
--
ALTER TABLE `config`
  MODIFY `ConfigId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;
--
-- 使用表AUTO_INCREMENT `email`
--
ALTER TABLE `email`
  MODIFY `EmailId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;
--
-- 使用表AUTO_INCREMENT `orders`
--
ALTER TABLE `orders`
  MODIFY `OrdersId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;
--
-- 使用表AUTO_INCREMENT `orders_auto_open`
--
ALTER TABLE `orders_auto_open`
  MODIFY `OpenId` int(10) NOT NULL AUTO_INCREMENT;
--
-- 使用表AUTO_INCREMENT `orders_list`
--
ALTER TABLE `orders_list`
  MODIFY `ListId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;
--
-- 使用表AUTO_INCREMENT `orders_list_history`
--
ALTER TABLE `orders_list_history`
  MODIFY `ListId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;
--
-- 使用表AUTO_INCREMENT `orders_trade_update`
--
ALTER TABLE `orders_trade_update`
  MODIFY `UpdateId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;
--
-- 使用表AUTO_INCREMENT `plan`
--
ALTER TABLE `plan`
  MODIFY `PlanId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;
--
-- 使用表AUTO_INCREMENT `profit_logs`
--
ALTER TABLE `profit_logs`
  MODIFY `LogsId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=0;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
